module.exports = {
  apps: [
    {
      name: 'ead-developer-system',
      script: './build/server.js',
      cwd: './', // 当前工作路径
      watch: [
        // 监控变化的目录，一旦变化，自动重启
        'src',
        'build',
        'public'
      ],
      ignore_watch: [
        // 从监控目录中排除
        'node_modules',
        'logs'
      ],
      node_args: '--harmony',
      env: {
        NODE_ENV: 'development',
        NODE_HOST: 'qt101x.corp.youdao.com',
        NODE_PORT: 5666,
        JAVA_HOST: 'nc110x.corp.youdao.com:12333'
      },
      env_production: {
        NODE_ENV: 'production',
        NODE_HOST: 'zhixuan.youdao.com',
        NODE_PORT: 5000,
        JAVA_HOST: 'pishon.inner.youdao.com' // 线上后台HOST
      },
      out_file: './logs/out.log', // 普通日志路径
      error_file: './logs/err.log', // 错误日志路径
      merge_logs: true,
      log_date_format: 'YYYY-MM-DD HH:mm Z' // 设置日志的日期格式
    }
  ]
};
