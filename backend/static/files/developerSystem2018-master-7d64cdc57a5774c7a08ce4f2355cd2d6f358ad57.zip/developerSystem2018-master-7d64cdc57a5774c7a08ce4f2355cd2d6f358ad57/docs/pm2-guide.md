## PM2 使用手册

### 背景

对于线上项目，如果直接通过 node app 来启动，如果报错了可能直接停止导致整个服务崩溃，一般监控 node 有几种方案。

* supervisor: 一般用作开发环境的使用。
* forever: 管理多个站点，一般每个站点的访问量不大的情况，不需要监控。
* PM2: 网站的访问量比较大，需要完整的监控页面。

> 新智选采用的是 forever 的形式，不过如果 node 出现问题的时候，没有办法获取到有效的监控数据，因此新开发者系统准备采用 pm2 的形式进行前端以及 node 层的监控。

### PM2 的主要特性

* 内建负载均衡（使用 Node cluster 集群模块）
* 后台运行
* 0 秒停机重载，我理解大概意思是维护升级的时候不需要停机.
* 具有 Ubuntu 和 CentOS 的启动脚本
* 停止不稳定的进程（避免无限循环）
* 控制台检测
* 提供 HTTP API
* 远程控制和实时的接口 API ( Nodejs 模块,允许和 PM2 进程管理器交互 )

### 安装

```
// 全局安装pm2，依赖node和npm
npm install -g pm2
```

### 用法

* 基本启动命令

> pm2 start

```
// start命令启动对应的node server文件
$ pm2 start ./build/server.js
```

* 通过配置文件进行启动稍后详细讲解

启动之后，控制台会看到如下消息：

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2ba717997b20?w=1566&h=252&f=png&s=70813)

> 如上图所示，可以看到项目`kafazhe`成功启动,id 是 0，并且状态时 online.

* 查看详细状态信息

> pm2 show (appname|id)

```
$ pm2 show kaifazhe
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2bae6ed0fb41?w=1488&h=1116&f=png&s=250471)

> 如上图所示，可以查看到 kaifazhe 进程的详细信息

* 查看所有启动的进程列表

> pm2 list

```
$ pm2 list
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2ba717997b20?w=1566&h=252&f=png&s=70813)

* 监控每个 node 进程的 cpu 和内存使用情况
  > pm2 monit

```
$ pm2 monit
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b9519339ad1?w=2114&h=1218&f=png&s=360537)

> 可以使用 pm2 monit 功能监控所有 node 进程的运行情况，包括各种响应，错误信息。

* 显示所有进程的日志信息

> pm2 logs

```
$ pm2 logs
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b95198103f3?w=2102&h=1212&f=png&s=605345)

* 监控运行这些进程的机器的状态

> pm2 web

```
$ pm2 web
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b95199a77a9?w=1732&h=310&f=png&s=93867)
![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b958eb14dc3?w=700&h=1199&f=png&s=137352)
![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b95194d9f80?w=774&h=1054&f=png&s=147630)

> 我只能说，这也太 NB 了吧，不仅可以监控这些进程，还能监控运行这些进程的机器的状态，逆天了。然后它会自动起一个服务在指定端口，如图在 9615 启动了一个服务，我们可以访问。虽然我看不太懂，但是对于测试运维同学来说，应该挺有用的吧。

* 停止 指定/所有 进程

> pm2 stop (id|all)

```
// 停止id为0的进程
$ pm2 stop 0
// 停止所有进程
$ pm2 stop all
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b95514f5929?w=1838&h=902&f=png&s=269690)

> 如图，我们运行了两个服务状态都是 online，使用 stop 0 之后，kaifazhe 的服务变成了 stopped，然后使用 stop all，所有进程状态全变成了 stopped。

* 重启 指定/所有 进程

> pm2 restart (id|all)

```
// 重启id为0的进程
$ pm2 restart 0
// 重启所有进程
$ pm2 restart all
```

* 杀死 指定/所有 进程

> pm2 delete (id|all)

```
// 杀死id为0的进程
$ pm2 delete 0
// 杀死所有进程
$ pm2 delete all
```

![](https://user-gold-cdn.xitu.io/2018/11/8/166f2b9552c23eaa?w=1814&h=926&f=png&s=255302)

> 从上图我们可以看出，restart 0 之后，0 进程从 stopped 状态变成了 online，然后我们使用 delete 0,进程 0 就消失不见了，我们再 delete all,可以看到现在没有任何进程在运行。

### 配置 PM2 启动文件

pm2 启动的方式可以进行很多的扩展，比如设置环境，设置错误信息打印，设置输入信息打印等等高级功能。那么一条命令就不能完成这些任务，所有 pm2 提供了配置文件的方式来启动～

#### pm.config.js

```
// 名称任意，按照个人习惯来
module.exports = {
  apps: [
    {
      name: 'developer-system', // 应用名称
      script: './build/server.js', // 启动文件地址
      cwd: './', // 当前工作路径
      watch: [
        // 监控变化的目录，一旦变化，自动重启
        'src',
        'build',
      ],
      ignore_watch: [
        // 忽视这些目录的变化
        'node_modules',
        'logs',
        'public',
      ],
      node_args: '--harmony', // node的启动模式
      env: {
        NODE_ENV: 'development', // 设置运行环境，此时process.env.NODE_ENV的值就是development
        ORIGIN_ADDR: 'http://www.yoduao.com'
      },
      env_production: {
        NODE_ENV: 'production',
      },
      out_file: './logs/out.log', // 普通日志路径
      error_file: './logs/err.log', // 错误日志路径
      merge_logs: true,
      log_date_format: 'YYYY-MM-DD HH:mm Z',
    },
  ],
};
```

> 对于上面的 env，我们可以在内部添加很多个参数变量，这样我们所使用的 process.env.XXX 就会对应发生变化,例如上面，我们 process.env.ORIGIN_ADDR 的值就是`http://www.youdao.com`～

### 负载均衡

最 666 的功能来了～自动给你做负载均衡，只需要一条命令，以前那些复杂的概念懂不懂无所谓。

> pm2 start server.js -i (number|max)

```
# 开启三个进程运行项目
pm2 start app.js -i 3
# 根据机器CPU核数，开启对应数目的进程运行项目
pm2 start app.js -i max
```

> 配置文件里对应的：`"instance": (number|max)`

```
// pm2.config.js
"instances": 2,  // 启动两个实例
```
