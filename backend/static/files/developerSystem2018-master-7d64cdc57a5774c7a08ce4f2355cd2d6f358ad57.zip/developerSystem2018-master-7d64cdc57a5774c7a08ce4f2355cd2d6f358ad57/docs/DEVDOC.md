## 有道智选开发者系统开发文档

### 开发规范

#### 所有开发人员基于 master 分支新开分支进行开发

#### 上线之前对分支进行 commit 的合并

```
 git rebase -i commit-version

 // 出现冲突, 解决
 git rebase --continue

 // 放弃合并
 git rebase --abort
```

#### 基于开发分支进行上线，上线完成之后合并 master 并通知其他人进行 rebase master 操作

```
git rebase master
```

#### 上线完成合并到 master 之后，进行打 tag 操作

```
git tag -a 版本号 -m '版本描述' commit-version

git push origin 版本号
```

> 大版本上线保留分支，小版本上线合并到 master 进行 merge 时自动删除分支，避免过多分支污染远程仓库

#### 版本号规则

* 版本号采用`va.b.c`的形式
* 开发者未全部开发完成之前采用小版本。如 v0.1.0, v0.2.1
* 新功能版本修改 b, 优化、bug fix 修改 c
* 开发者正式对外，v1.0.0

### 开发注意

新开发者与新智选同为网易有道智选下的同一系列系统，新开发者并不是新智选的子系统，二者拥有共同父域名`https://zhixuan.youdao.com`，新智选由于一些原因采用的是`https://xinzhixuan.youdao.com`，新开发者则采用更为合理的`https://zhixuan.youdao.com/developer`作为入口地址，因为这样导致项目工程需要进行一些必要的调整才可以完成产品需求。

* 调整前端路由

在 UniversalRouter 配置文件里，新增`baseUrl: '/developer'`属性，这样做可以避免修改所有的路由路径，会自动为所有的路由前面添加 developer。

```
// router.js
export default new UniversalRouter(routes, {
 baseUrl: '/developer', // 新增路由根路径
 resolveRoute(context, params) {
 if (typeof context.route.load === 'function') {
 return context.route
 .load()
 .then(action => action.default(context, params));
 }
 if (typeof context.route.action === 'function') {
 return context.route.action(context, params);
 }
 return undefined;
 }
});
```

* 修改所有的 history 路由

系统内部除了进行了路由跳转，还有很多场景进行了 history 跳转，这种情况就需要全局匹配

```
history.push(originPath) =====> history.push('/developer' + originPath)
```

* 修改 Nginx 服务器指向

```
https://zhixuan.youdao.com/developer
指向所部署的服务器
xxxxx.corp.youdao.com:5000
```

* 修改所有后端路由

Nginx 指向配置完成后，所有的请求都会自动打到`xxxxx.corp.youdao.com:5000/developer`，注意后面会有 developer，这就意味着 node 端所有的请求前面也需要带上`/developer`。

```
app.use('/api', apiHandler); =====> app.use('/developer/api', apiHandler);
```

### [v0.1.0] —— 应用管理

```
Date: 2018-12-17
Author: zhoudy
content:
 - 新建应用
 - 新建广告位(七种类型广告位)
 - 新建样式(图片、文字、视频、自定义)
 - 提交审核(上传图片、上传安装包、预览图片、下载安装包)
 - 编辑广告位
 - 自测设备管理
```
