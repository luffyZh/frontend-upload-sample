# 有道智选开发者系统 developerSystem2018_Change_Log

记录有道智选开发者系统开发过程的版本变化情况，方便了解更能详情以及进行版本控制。

## [v0.1.0]

```
Date: 2018-11-03
Author: zhoudy
Frontend: zhoudy
Backend: wangmo、lishengle
Test: shifj、haozh、wangm
Product: zhaopy
```

#### 应用管理

* 应用模块
* 广告位模块

#### 账户管理

* 设备管理模块

> 需求文档地址：[v0.1.0 PRD 文档](https://mjiac1.axshare.com/#g=1&p=%E6%9B%B4%E6%96%B0%E5%8A%9F%E8%83%BD%E8%AE%B0%E5%BD%95)

## [v0.1.1]

```
Date: 2018-11-05
Author: zhoudy
Frontend: zhoudy
Backend: wangmo
Test: shifj、haozh、wangm
Product: zhaopy
```

#### 修复线上下载安装包出错的 Bug

## [v0.2.0]

```
Date: 2018-01-02
Author: zhoudy
Frontend: zhoudy、xuyang
Backend: lishengle
Test: shifj、haozhihui
Product: zhaopy
```

#### 帮助中心

* 入门指南
* 对接文档
* 常见问题
* SDK 下载

#### 账户管理

* 账户信息
* 消息中心
* 重构自测设备管理

```
[亮点]：重构自测设备管理，老版本的自测设备管理无论是设计还是使用都及其的不合理，从开发的角度对设备管理进行了
重构，最终实现了逻辑清晰，使用简单并且功能更强大的自测设备管理模块。
```

> 需求文档地址：[v0.2.0 PRD 文档](https://mjiac1.axshare.com/#g=1&p=%E6%9B%B4%E6%96%B0%E5%8A%9F%E8%83%BD%E8%AE%B0%E5%BD%95)

## [v0.3.0]

#### 数据报表

* 账户报表 && 下载
* 应用报表 && 下载
* 广告位报表 && 下载
* 样式报表 && 下载

```
[亮点]：通过合理的设计，四个页面，所有的数据展示是通过一个组件一个路由一个请求的形式呈现的。代码做到了最精简化并且思路清晰，对接入的其他人没有任何负担，其中可复用的图表以及左右可选择tab抽离成组件，在其他模块直接无缝使用。
```

#### 应用管理

* 为了运营能够更加便捷的进行验证，在编辑广告位页面增加样式截图以及安装包下载

> 需求文档地址：[v0.3.0 PRD 文档](https://mjiac1.axshare.com/#g=1&p=%E6%9B%B4%E6%96%B0%E5%8A%9F%E8%83%BD%E8%AE%B0%E5%BD%95)

## [v0.3.1]

#### 内测二期优化

* 旧系统数据兼容性，解决线上崩溃问题
* 保留自定义广告位类型，取消自定义样式逻辑
* 隐藏未被开发的首页，将应用管理作为系统入口

> 需求文档地址：[v0.3.1 PRD 文档](https://mjiac1.axshare.com/#g=1&p=%E5%8F%96%E6%B6%88%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E7%B4%A0%E5%85%A5%E5%8F%A3)

## [v0.3.2]

```
Date: 2019-04-15
Author: zhoudy
Frontend: zhoudy
Backend: lishengle
Test: shifj、haozhihui
Product: zhaopy
```

#### 内测三期优化

* 开发者注册逻辑整合到开发者前端中
* 广告位页面新增应用和应用包类型
* 交换广告位页面按钮位置
* 正式对外上线

> 需求文档地址：[v0.3.2 PRD 文档](https://mjiac1.axshare.com/#g=1&p=new_page_1)

## [v0.4.0]

#### 聚合 SDK 上线

* 开发者白名单功能 —— 聚合 SDK 上线
* 开发者相关 bug fix
