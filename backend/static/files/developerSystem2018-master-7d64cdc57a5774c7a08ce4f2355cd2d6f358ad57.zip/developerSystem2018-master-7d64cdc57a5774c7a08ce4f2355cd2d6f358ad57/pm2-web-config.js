module.exports = {
  www: {
    host: 'localhost',
    address: '0.0.0.0',
    port: 6688
  }
};
