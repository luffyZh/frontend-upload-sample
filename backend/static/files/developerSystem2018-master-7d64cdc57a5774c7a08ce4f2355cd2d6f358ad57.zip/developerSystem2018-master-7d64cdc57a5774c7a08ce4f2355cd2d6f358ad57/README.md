## KAIFAZHE 2018 — Youdao DSP Publish System 2018

有道智选开发者系统是网易有道推出的为媒体提供基于用户场景的内容广告样式。目前该系统使用 java web 技术开发的，系统比较老旧，易用性和用户体验低，且开发维护成本较高。为了解决以上的问题，决定使用前后端分离将现有系统进行重构，重新设计 UI 和用户交互，改善系统易用性，提高用户体验。该项目使用 [React Starter Kit](https://github.com/kriasoft/react-starter-kit/tree/feature/redux) 生成，里面包含了诸多当前较新的技术。

### 当前版本功能

#### [v1.0.0] 应用管理

> 注：更详细的功能详见[CHANGELOG](./docs/CHANGELOG.md)

### 部署说明

服务部署在 三台 服务器上，分别是

> th084、th085、th086，磁盘 /disk2

【上线域名】: https://zhixuan.youdao.com/developer。

#### 部署前的准备

部署前确保系统中已安装以下环境：

* node: >= v6.14.0 || >= v8.10.0 (开发者环境 node 版本为 v6.14.0, v8.12.0, v8.14.0)
* npm: 跟随 node 的版本变化
* yarn
* git

将`node`和`npm`路径添加到全局环境变量中，建议使用`n`进行 node 的多版本管理，[n 文档](https://www.npmjs.com/package/n)。

另外，建议将 npm 源设置为 taobao npm 镜像，加快访问速度。命令如下：

```shell
npm config set registry=https://registry.npm.taobao.org
```

安装 yarn

```shell
npm install -g yarn
```

#### 准备项目

如果是第一次部署工程，执行下面命令：

```shell
$ git clone https://gitlab.corp.youdao.com/webfront-ad/developerSystem2018.git
$ cd developerSystem2018
$ yarn config set cache-folder /disk2/eadop/yarn 修改yarn缓存目录(线上部署时才需要)
$ yarn install
```

#### 准备文件夹及权限

**在项目根目录创建 uploads 文件夹以及 downloads 文件夹，同时保证系统有写入此文件夹的权限。**

> 注意：这个地方如果使用 pm2 部署上线的时候如果出现报错，提示找不到 uploads 或 downloads 文件夹，按照提示在对应位置新建文件夹即可，该文件夹用于缓存中间文件，一般缓存完会自动删除，程序出现故障可能会出现脏数据，可以使用脚本定期清理文件夹。(建议每天 0 点清空文件夹)

#### 如何构建上线

由于开发者系统采用功能更为强大的 pm2 进行部署，所有配置项单独成一个 pm2 文件，因此测试和上线部署配置与新智选有所不同。配置文件为`./pm2.config.js`,测试与上线配置下面分两种情况讲解：

* 测试环境下

**测试环境没有单独给出一个配置参数，与 dev 共用一套配置，也就是`env`下的配置：**

```
// pm2.config.js
...
// 开发及测试环境修改 env 的配置项
env: {
  NODE_ENV: 'development', // 开发环境与测试环境同用development
  NODE_HOST: 'qt101x.corp.youdao.com', // 前端+node端HOST
  NODE_PORT: 5666, // 前端+node端端口号
  JAVA_HOST: 'qt101x.corp.youdao.com:10017' // 后端接口HOST
},
...
```

**测试环境的启动命令为：**

```
# 1. 安装依赖
$ yarn install
# 2. 打包文件
$ yarn build
# 3. pm2运行监控
$ pm2 start pm2.config.js
```

* 生产环境部署上线

**生产环境环境使用的是`env_production`下的配置：**

```
// pm2.config.js
...
// 生产环境修改 env_production 的配置项
env_production: {
  NODE_ENV: 'production', // 开发环境与测试环境同用development
  NODE_HOST: 'zhixuan.youdao.com', // 前端+node端HOST
  NODE_PORT: 5000, // 前端+node端端口号
  JAVA_HOST: 'pishon.inner.youdao.com' // 后端接口HOST
},
...
```

**生产环境上线命令为：**

```
shell
# 1. 安装依赖
$ yarn install
# 2. 打包文件
$ yarn build-stats
# 3. pm2运行监控
$ pm2 start pm2.config.js --env production -e /disk2/eadop/developer/logs -o /disk2/eadop/developer/logs
```

```
参数说明
  |     --env production       |   设置NODE_ENV为生产环境 production
  |  -----------------------   |    -----------------
  |          -o                |   标准输出日志文件的路径
  |          -e                |   错误输出日志文件的路径
```

### 启停方式

```
启动: pm2 start pm2.config.js --env production -e /disk2/eadop/developer/logs -o /disk2/eadop/developer/logs
停止: pm2 stop ead-developer-system
```

> 注：日志需要保存到项目的根目录 logs 文件夹下。若根目录下无该路径，则需手动创建 logs 文件夹 mkdir logs （项目根目录是指 package.json 所在目录）

然后配置下域名`zhixuan.youdao.com/developer`。

如果上线多台服务，nginx 需要按照 ip 分流，即某 ip 要固定分流到某台 server 上。

浏览器中访问 [https://zhixuan.youdao.com/developer](https://zhixuan.youdao.com/developer)。

### PM2 更多使用功能

详情请看[PM2 手册](./docs/pm2-guide.md)

### CHANGELOG

版本更新说明：[Change log](./docs/CHANGELOG.md)

### 开发文档

更详细的开发相关说明参见 [Dev Doc](./docs/DEVDOC.md)
