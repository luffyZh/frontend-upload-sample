/**
 * 开发者系统server端文件
 */
import path from 'path';
import express from 'express';
import cookieParser from 'cookie-parser';
import bodyParser from 'body-parser';
import React from 'react';
import ReactDOM from 'react-dom/server';
import PrettyError from 'pretty-error';
import { LocaleProvider } from 'antd';
import zh_CN from 'antd/lib/locale-provider/zh_CN';
import debounce from 'debounce';
import { access, response } from './middlewares/log';
import accessId from './middlewares/accessId';
import App from './components/App';
import Html from './components/Html';
import { ErrorPageWithoutStyle } from './routes/error/ErrorPage';
import errorPageStyle from './routes/error/ErrorPage.css';
import router from './router';
import chunks from './chunk-manifest.json'; // eslint-disable-line import/no-unresolved
import configureStore from './store/configureStore';
import { setRuntimeVariable } from './actions/runtime';
import config from './config';
import login from './middlewares/login';
import specialLogin from './middlewares/specialLogin';
import logoutHandler from './middlewares/logoutHandler';
import { getLocalIP } from './core/serverUtils';
import apiHandler from './api';
import auth from './middlewares/auth';
import { loginSuccess } from './actions/Auth';
import downloadFile from './middlewares/downloadFile';
import errorHandler from './middlewares/errorHandler';
import registerHandler from './middlewares/register';

process.on('unhandledRejection', (reason, p) => {
  console.error('Unhandled Rejection at:', p, 'reason:', reason);
  // send entire app down. Process manager will restart it
  process.exit(1);
});

//
// Tell any CSS tooling (such as Material UI) to use all vendor prefixes if the
// user agent is not known.
// -----------------------------------------------------------------------------
global.navigator = global.navigator || {};
global.navigator.userAgent = global.navigator.userAgent || 'all';

const app = express();

/**
 * heart beat api for maintainer to test node alive
 */
app.get('/developer/youdao-ead-developer-heartbeat', (req, res) => {
  res.status(200).send('I am fine ~');
});

/**
 * Register log middleware
 */
app.use(accessId);
app.use(access);
app.use(response);

//
// If you are using proxy from external machine, you can set TRUST_PROXY env
// Default is to trust proxy headers only from loopback interface.
// -----------------------------------------------------------------------------
app.set('trust proxy', config.trustProxy);

//
// Register Node.js middleware
// -----------------------------------------------------------------------------
app.use(express.static(path.resolve(__dirname, 'public')));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

/**
 * Register API middleware
 */
app.use('/developer/register', registerHandler);

/**
 * Register special login and logout
 */
app.get('/developer/login', login); // 首页登录
app.get('/developer/specialLogin', specialLogin); // crm系统登录
app.get('/developer/logout', logoutHandler); // 系统登出

// 下载文件，避免触发多次下载
app.get('/developer/downloadFile/:slotUdid', debounce(downloadFile, 1000));

/**
 * Other API middleware
 */
app.use('/developer/api', auth.api, apiHandler);

//
// Register server-side rendering middleware
// -----------------------------------------------------------------------------
app.get('*', auth.server, async (req, res, next) => {
  try {
    const css = new Set();

    // Enables critical path CSS rendering
    // https://github.com/kriasoft/isomorphic-style-loader
    const insertCss = (...styles) => {
      // eslint-disable-next-line no-underscore-dangle
      styles.forEach(style => css.add(style._getCss()));
    };

    const store = configureStore();

    // 登录成功user存入state
    store.dispatch(loginSuccess({
      user: {
        developerId: req.cookies.KFZID,
        email: req.cookies.KFZEMAIL,
        token: req.cookies.KFZTK,
        permissionList: req.cookies.PERMISSION_LIST
      }
    }));

    store.dispatch(
      setRuntimeVariable({
        name: 'initialNow',
        value: Date.now()
      }),
    );

    // Global (context) variables that can be easily accessed from any React component
    // https://facebook.github.io/react/docs/context.html
    const context = {
      insertCss,
      // The twins below are wild, be careful!
      pathname: req.path,
      query: req.query,
      // You can access redux through react-redux connect
      store,
      storeSubscription: null
    };

    const route = await router.resolve(context);

    if (
      route.redirect &&
      context.pathname !== route.redirect &&
      route.redirect.indexOf(context.pathname) > -1
    ) {
      res.redirect(route.status || 302, route.redirect);
      return;
    }

    if (route.beforeEnter && route.beforeEnter[0].length) {
      route.beforeEnter.forEach(fn => fn());
    }

    const data = { ...route };
    data.children = ReactDOM.renderToString(
      <LocaleProvider locale={zh_CN}>
        <App context={context}>{route.component}</App>
      </LocaleProvider>,
    );
    data.styles = [{ id: 'css', cssText: [...css].join('') }];

    const scripts = new Set();
    const addChunk = chunk => {
      if (chunks[chunk]) {
        chunks[chunk].forEach(asset => scripts.add(asset));
      } else if (__DEV__) {
        throw new Error(`Chunk with name '${chunk}' cannot be found`);
      }
    };
    addChunk('client');
    /* 为什么要加这个不太理解，注释掉没有任何影响，还减少了js数量 */
    if (route.chunk) addChunk(route.chunk);
    if (route.chunks) route.chunks.forEach(addChunk);

    data.scripts = Array.from(scripts);
    data.app = {
      apiUrl: config.api.clientUrl,
      state: context.store.getState()
    };

    const html = ReactDOM.renderToStaticMarkup(<Html {...data} />);
    res.status(route.status || 200);
    res.send(`<!doctype html>${html}`);
  } catch (err) {
    next(err);
  }
});
/**
 * Register custom error handler middleware last
 */
app.use(errorHandler);
//
// Error handling
// -----------------------------------------------------------------------------
const pe = new PrettyError();
pe.skipNodeFiles();
pe.skipPackage('express');

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(pe.render(err));
  const html = ReactDOM.renderToStaticMarkup(
    <Html
      title="Internal Server Error"
      description={err.message}
      styles={[{ id: 'css', cssText: errorPageStyle._getCss() }]} // eslint-disable-line no-underscore-dangle
    >
      {ReactDOM.renderToString(<ErrorPageWithoutStyle error={err} />)}
    </Html>,
  );

  res.status(err.code || err.status || 500);
  res.send(`<!doctype html>${html}`);
});

//
// Launch the server
// -----------------------------------------------------------------------------
if (!module.hot) {
  app.listen(config.port, () => {
    const ips = getLocalIP();
    const ipstr = ips.map(ip => `http://${ip}:${config.port}/`);
    console.info(
      `The server is running at ${ipstr}, now is ${new Date().toLocaleString()}, pid = ${
        process.pid
      }`,
    );
  });
}

//
// Hot Module Replacement
// -----------------------------------------------------------------------------
if (module.hot) {
  app.hot = module.hot;
  module.hot.accept('./router');
}

export default app;
