/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import Layout from '../../containers/Layout';
import HelpCenter from '../../pages/helpCenter';

const pathToTitle = {
  startGuide: '入门指南',
  dockingDocs: '对接文档',
  faq: '常见问题',
  sdkDownload: 'SDK下载'
};

function action({ params }) {
  const type = params[0] || 'startGuide';
  return {
    chunks: ['helpCenter'],
    title: `${pathToTitle[type]} - 帮助中心`,
    redirect: '/developer/helpCenter/startGuide',
    component: (
      <Layout>
        <HelpCenter type={type} />
      </Layout>
    )
  };
}

export default action;
