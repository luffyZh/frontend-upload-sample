import React from 'react';
import Layout from '../../containers/Layout';
import UpdateRecord from '../../pages/helpCenter/sdkDownload/UpdateRecord';

function action({ params }) {
  const type = params[0];
  return {
    chunks: ['sdkDownload'],
    title: 'SDK下载 - 帮助中心',
    component: (
      <Layout>
        <UpdateRecord type={type} />
      </Layout>
    )
  };
}

export default action;
