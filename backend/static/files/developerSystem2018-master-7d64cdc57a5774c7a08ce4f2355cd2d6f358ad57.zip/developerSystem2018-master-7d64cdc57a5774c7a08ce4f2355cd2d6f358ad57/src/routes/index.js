/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

/* eslint-disable global-require */

// The top-level (parent) route
const routes = {
  path: '',

  // Keep in mind, routes are evaluated in order
  children: [
    {
      path: '',
      // load: () => import(/* webpackChunkName: 'home' */ './home')
      load: () => import(/* webpackChunkName: 'appManagement' */ './appManagement/list')
    },
    {
      path: new RegExp('^/(home)?$'),
      load: () => import(/* webpackChunkName: 'home' */ './home')
    },
    {
      // 比如/app、/2323/adSlot、/adSlot
      path: new RegExp('^/appManagement/?(app|([0-9]+/)?adSlot)?$'),
      load: () =>
        import(/* webpackChunkName: 'appManagement' */ './appManagement/list')
    },
    {
      // 比如：/appManagement/app/new、/appManagement/232323/adSlot/new
      path: new RegExp('^/appManagement/(app|([0-9]+)/adSlot)/new$'),
      load: () =>
        import(/* webpackChunkName: 'appManagement' */ './appManagement/new')
    },
    {
      path: new RegExp('^/appManagement/((([0-9]|[a-z])+)/adSlot)/edit$'),
      load: () =>
        import(/* webpackChunkName: 'appManagement' */ './appManagement/edit')
    },
    /* 数据报表 */
    // 入口路由
    {
      path: '/dataReport',
      load: () =>
      import(/* webpackChunkName: 'dataReport' */ './dataReport')
    },
    // 匹配其他路由
    {
      path: new RegExp('^/dataReport/?(account|apps|slots|schemas)/?(([0-9]|([0-9]|[a-z]))+)?$'),
      load: () =>
        import(/* webpackChunkName: 'dataReport' */ './dataReport')
    },
    {
      path: new RegExp('^/helpCenter/?(startGuide|dockingDocs|faq|sdkDownload)?$'),
      load: () => import(/* webpackChunkName: 'helpCenter' */ './helpCenter')
    },
    {
      path: new RegExp('^/helpCenter/sdkDownload/updateRecord/?(ios|android)?$'),
      load: () => import(/* webpackChunkName: 'sdkDownload' */ './helpCenter/sdkDownload')
    },
    /* 账户管理 */
    {
      path: new RegExp('^/accountManagement/?(accountInfo|systemInfo|deviceInfo)?$'),
      load: () =>
        import(/* webpackChunkName: 'accountManagement' */ './accountManagement')
    },
    {
      path: new RegExp('^/aggregateSDK/?(adManagement/?([0-9a-z]+)?/?([0-9a-z]+)?|description)?$'),
      load: () =>
        import(/* webpackChunkName: 'aggregateSDK' */ './aggregateSDK')
    },
    // Wildcard routes, e.g. { path: '(.*)', ... } (must go last)
    {
      path: '(.*)',
      load: () => import(/* webpackChunkName: 'not-found' */ './not-found')
    }
  ],

  async action({ next }) {
    // Execute each child route until one of them return the result
    const route = await next();

    // Provide default values for title, description etc.
    route.title = `${route.title || '无标题页'} - 有道智选开发者平台`;
    route.description = route.description || '';

    return route;
  }
};

// The error page is available by permanent url for development mode
if (__DEV__) {
  routes.children.unshift({
    path: '/error',
    action: require('./error').default
  });
}

export default routes;
