/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import Layout from '../../containers/Layout';
import New from '../../containers/appManagement/New';
import {
  resetAppItem,
  resetAdPosItem,
  editApp,
  editAdPos,
  editSelfTest,
  editToAudit,
  setAdPosIsEdit,
  adPosDataChange,
  getAppCategories,
  getStandardTemplates,
  getStandardElements,
  resetAuditData
} from '../../actions/AppManagement/new';
import { AppTabTypes } from '../../constants/MenuTypes';

const title = '应用管理';
const editingPageType = {
  app: 'app',
  adSlot: 'adSlot',
  selfTest: 'selfTest',
  toAudit: 'toAudit'
};
const { app, adSlot, selfTest, toAudit } = editingPageType;
const editingPageTitle = {
  app: '新建应用',
  adSlot: '新建广告位',
  selfTest: '集成与自测',
  toAudit: '提交审核'
};

const editingActions = {
  [app]: editApp,
  [adSlot]: editAdPos,
  [selfTest]: editSelfTest,
  [toAudit]: editToAudit
};

async function action({ store, params }) {
  const params0 = params['0'];
  const appId = params['1'];
  const type = appId ? params0.replace(/(\d+\/)/, '') : params0;
  const subTitle = editingPageTitle[type];
  const tabType = type === 'app' ? AppTabTypes.appTab : AppTabTypes.appAdPosTab;
  return {
    chunks: ['appManagement'],
    title: `${subTitle} - ${title}`,
    component: (
      <Layout>
        <New tabType={tabType} isEdit={false} />
      </Layout>
    ),
    beforeEnter: [
      () => {
        /**
         * 新建应用组件
         * 重置应用state
         * 重置广告位state, 否则保存并继续会出现bug
         * 获取应用的分类级别，也可以放在componentDidMount内获取
         */
        if (type === app) {
          store.dispatch(resetAdPosItem()); // 修复保存并继续的bug
          store.dispatch(resetAppItem());
          store.dispatch(getAppCategories());
        }
        /**
         * 新建广告位组件
         * 设置用户正处在广告位编辑的状态，因为左侧slideBar在监听目前进行到第几步了
         * 重置广告位state, 否则保存并继续会出现bug
         * 新建广告位需要拿到appId来进行应用名称的获取
         */
        if (type === adSlot) {
          store.dispatch(setAdPosIsEdit(true));
          store.dispatch(resetAdPosItem());
          store.dispatch(adPosDataChange('adPosSetting', 'appId', parseInt(appId, 10)));
        }
        /**
         * 样式信息全部存在数据库，进入新建页面必须获取
         * 也可以在componentDidMount执行
         */
        store.dispatch(getStandardTemplates());
        store.dispatch(getStandardElements());
        /**
         * 重置提交审核的state
         */
        store.dispatch(resetAuditData());
        /**
         * 传递当前用户进行的步骤，用户状态保存以及每一步组件状态的获取
         */
        store.dispatch(editingActions[type]());
      }
    ]
  };
}

export default action;
