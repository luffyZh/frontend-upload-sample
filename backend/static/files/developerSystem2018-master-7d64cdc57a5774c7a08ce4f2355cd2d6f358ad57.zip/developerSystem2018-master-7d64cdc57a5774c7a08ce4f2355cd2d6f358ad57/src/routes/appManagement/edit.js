/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import Layout from '../../containers/Layout';
import New from '../../containers/appManagement/New';
import { AppTabTypes } from '../../constants/MenuTypes';
import {
  getAdSlotInfo,
  adPosDataChange,
  getStandardElements,
  getStandardTemplates,
  resetAdPosItem,
  resetAuditData
} from '../../actions/AppManagement/new';
 
const title = '编辑广告位';

async function action({ store, params, query }) {
  const slotUdid = params['1'];
  const { appId, slotOpStatus } = query;
  return {
    chunks: ['appManagement'],
    title,
    component: (
      <Layout>
        <New
          tabType={AppTabTypes.appAdPosTab}
          isEdit
        />
      </Layout>
    ),
    beforeEnter: [
      () => {
        store.dispatch(resetAdPosItem());
        store.dispatch(getStandardTemplates());
        store.dispatch(getStandardElements());
        store.dispatch(adPosDataChange('adPosSetting', 'appId', parseInt(appId, 10)));
        store.dispatch(adPosDataChange('adPosSetting', 'slotOpStatus', parseInt(slotOpStatus, 10)));
        store.dispatch(adPosDataChange('adPosSetting', 'adPosId', slotUdid));
        store.dispatch(getAdSlotInfo(slotUdid));
        store.dispatch(resetAuditData());
      }
    ]
  };
}

export default action;
