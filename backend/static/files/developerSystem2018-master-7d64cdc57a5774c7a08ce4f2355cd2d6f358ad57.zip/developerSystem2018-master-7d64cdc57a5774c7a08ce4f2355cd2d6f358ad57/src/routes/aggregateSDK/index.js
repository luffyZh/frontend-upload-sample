/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import Layout from '../../containers/Layout';
import AggregateSDK from '../../pages/aggregateSDK';
import { 
  aggregateSDKTabs, 
  PathToTitle,
  priorityList
} from '../../constants/MenuTypes';
import { 
  getAdSlotList,
  getAdvertisingList,
  enterEdit,
  enterAdd,
  enterCreatePriority,
  getPriorityList,
  getDetailsInfo
} from '../../actions/AggregateSDK';

function action({ store, params, query }) {
  const selectType = params[0] || 'adManagement';
  const type = selectType.split('/');
  const { mediationSdkSlotName } = query;
  return {
    chunks: ['aggregateSDK'],
    title: `${PathToTitle[type[0]]} - 智选聚合SDK`,
    redirect: '/developer/aggregateSDK/adManagement',
    component: (
      <Layout>
        <AggregateSDK type={type} />
      </Layout>
    ),
    beforeEnter: [
      () => {
        if (type.length === 1 && type[0] === aggregateSDKTabs.adManagement) {
          store.dispatch(getAdSlotList());
        }
        if (type.length === 2) {
          if (type[1] === aggregateSDKTabs.newslot) {
            store.dispatch(enterAdd());
          } else {
            store.dispatch(enterEdit());
            store.dispatch(getAdvertisingList(type[1]));
          }
        }
        if (type.length === 3) {
          store.dispatch(getDetailsInfo(type[1]));
          if (type[2] !== aggregateSDKTabs.newedit) {
            setTimeout(() => store.dispatch(getPriorityList(type[1], type[2])), 200);
          } else {
            store.dispatch(enterCreatePriority(priorityList, mediationSdkSlotName, type[1]));
          }
        }
        else {
          console.log('获取文档说明');
        }
      }
    ]
  };
}

export default action;
