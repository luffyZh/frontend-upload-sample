import React from 'react';
import Layout from '../../containers/Layout';
import DataReport from '../../containers/dataReport';
import {
  dataReportTabChange,
  resetQueryCondition,
  queryConditionChange,
  getSelectedMenuList,
  selectedMenuListChange
} from '../../actions/DataReport';
import {
  DataReportPath2Title,
  DataReportTabs
} from '../../constants/MenuTypes';

function action(context) {
  const { store, params, query: { appId } } = context;
  const type = params[0] || 'account';
  const targetId = params[1];
  return {
    chunks: ['dataReport'],
    title: `${DataReportPath2Title[type]} - 账户管理`,
    redirect: '/dataReport/account',
    component: (
      <Layout>
        <DataReport />
      </Layout>
    ),
    beforeEnter: [
      () => {
        // tab变化
        store.dispatch(dataReportTabChange(type, targetId));
        if (!targetId) {
          // 子层级不重置查询条件，重置查询条件
          store.dispatch(resetQueryCondition(type));
        }
        if (type === DataReportTabs.样式) {
          // 样式的时候需要多传一个appId, 否则无法获取到自定义已选列表
          store.dispatch(
            queryConditionChange(type, {
              type: 'id',
              id: (appId || '')
            })
          );
          store.dispatch(
            queryConditionChange(type, {
              type: 'ids',
              ids: (targetId || '')
            })
          );
        } else if (type === DataReportTabs.账户报表) {
          store.dispatch(selectedMenuListChange(type, []));
        } else {
          store.dispatch(
            queryConditionChange(type, {
              type: 'id',
              id: (targetId || '')
            })
          );
        }
        // 如果存在，获取已选择的列表数据
        (targetId || appId)
          ? store.dispatch(
            getSelectedMenuList(type, type === DataReportTabs.样式 ? appId : targetId)
          )
          : null;
      }
    ]
  };
}

export default action;
