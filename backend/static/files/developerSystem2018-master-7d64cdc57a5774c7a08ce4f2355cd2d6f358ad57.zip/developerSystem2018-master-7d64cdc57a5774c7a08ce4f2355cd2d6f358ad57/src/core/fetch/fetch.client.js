/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import 'whatwg-fetch';

// eslint-disable-line
export default self.fetch.bind(self);// eslint-disable-line
export const Headers = self.Headers;// eslint-disable-line
export const Request = self.Request;// eslint-disable-line
export const Response = self.Response;// eslint-disable-line
