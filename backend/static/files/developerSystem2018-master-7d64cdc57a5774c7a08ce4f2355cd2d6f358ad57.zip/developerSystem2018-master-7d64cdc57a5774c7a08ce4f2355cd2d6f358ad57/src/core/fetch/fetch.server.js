import Fetch, { Response, Request, Headers } from 'node-fetch';

export { Fetch as default, Response, Request, Headers };
