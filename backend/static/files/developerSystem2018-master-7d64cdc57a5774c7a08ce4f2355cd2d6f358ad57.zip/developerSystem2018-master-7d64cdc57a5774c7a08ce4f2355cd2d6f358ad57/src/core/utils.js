import _ from 'lodash';
import {
  SlotStyleAuditStatusForBE,
  PostBodyUrl,
  imageElemsMapKey,
  videoElemsMapKey,
  textElemsMapKey,
  getCustomDefaultElem,
  SpecialDealRouteArr,
  AppTabTypes,
  DataReportTabs,
  DataReportAggregateType,
  listType
} from '../constants/MenuTypes';

// ====================================== 其他部分_Start ==================================

// 根据指定 key 来更新 component 的 state
export function updateComponentStateByKeys(keys) {
  return function updateComponentStateByProps(nextProps) {
    const nextState = {};
    keys.forEach(key => {
      if (key in nextProps) {
        nextState[key] = nextProps[key];
      }
    });
    this.setState(nextState);
  };
}

// 使用 === 判断 state 和 nextState 是否相等，来决定组件是否应该更新
export function componentUpdateByState(nextProps, nextState) {
  const s = this.state;
  return _.keys(s).some(key => s[key] !== nextState[key]);
}

/**
 * 传入多class
 * @param {传入的class} args
 */
export function classnames(...args) {
  const ret = [];
  args.forEach(item => {
    switch (typeof item) {
      case 'string':
        ret.push(item);
        break;
      case 'object': {
        _.keys(item).forEach(key => {
          if (item[key]) {
            ret.push(key);
          }
        });
        break;
      }
      default:
        if (item) {
          ret.push(String(item));
        }
    }
  });
  return ret.join(' ');
}

export const checkIsSpecialRefreshRoute = path =>
  SpecialDealRouteArr.findIndex(item => item.test(path));

const dateRe = /^\d{4}-\d{2}-\d{2}$/;
export const isValidDate = dateStr => dateRe.test(dateStr) && !_.isNaN(Date.parse(dateStr));

/**
 * 获取两个日期之间的间隔
 * @param {String} begin 开始日期
 * @param {String} end 结束日期
 */
Date.prototype.format = function() {
  var s = '';
  var mouth = (this.getMonth() + 1) >= 10 ? (this.getMonth() + 1) : ('0' + (this.getMonth() + 1));
  var day = this.getDate() >= 10 ? this.getDate() : ('0' + this.getDate());
  s += this.getFullYear() + '-'; // 获取年份。
  s += mouth + '-'; // 获取月份。
  s += day; // 获取日。
  return (s); // 返回日期。
};

export function getDateAll(begin, end) {
  var ab = begin.split('-');
  var ae = end.split('-');
  var db = new Date();
  db.setUTCFullYear(ab[0], ab[1] - 1, ab[2]);
  var de = new Date();
  de.setUTCFullYear(ae[0], ae[1] - 1, ae[2]);
  var unixDb = db.getTime();
  var unixDe = de.getTime();
  let dateArr = [];
  for (var k = unixDb; k <= unixDe;) {
    dateArr.push((new Date(parseInt(k))).format());
    k = k + 24 * 60 * 60 * 1000;
  }
  return dateArr;
}
// ====================================== 其他部分_End ==================================

/**
 * 判断是否是post body类型的url，example：新建/编辑广告位
 * 这种类型的URL需要重设content-type，并且data不可以序列化
 * @param {String} method
 * @param {String} url
 * */
export const checkIsPostBodyUrl = (method, url) => {
  if (method !== 'post' && method !== 'put') {
    return false;
  }
  const targetUrl = url.substring(url.indexOf('v1.0.0/') + 6, url.length);
  let flag = false;
  PostBodyUrl.map(item => {
    if (item.test(targetUrl)) {
      flag = true;
    }
  });
  return flag;
};

/**
 * 判断请求是否是下载文件流的请求
 * @param {String} method
 * @param {String} path
 */
export const isDowloadFileStream = (method, path) =>
  method === 'get' && path.indexOf('/audit-info/app-package') > -1;

// 是否是正整数
export const isPositiveInteger = n => {
  const num = typeof n === 'number' ? n : Number(n);
  return Number.isInteger(num) && num > 0;
};

// similar function as array.filter
export const filterObject = (o, filter) => {
  const r = {};
  _.keys(o).forEach(k => {
    if (filter(o[k], k)) {
      r[k] = o[k];
    }
  });
  return r;
};

// 从req中获取用户信息
export const fetchUserInfo = req => {
  return {
    developerId: req.cookies.KFZID,
    email: req.cookies.KFZEMAIL,
    token: req.cookies.KFZTK
  };
};

// 登出移除cookie
export const removeCookies = (Cookies, params) => {
  params.forEach(t => (Cookies.remove(t)));
};

/**
 * 格式化数字为财务格式，保留2位小数
 *
 * @example
 * numberFormat(2)(23283.892) => 23,283.89
 */
export const numberFormat = fractionDigits => {
  if (fractionDigits < 0 || fractionDigits > 20) {
    throw new RangeError(
      'digits argument fractionDigits must be between 0 and 20',
    );
  }
  const that = typeof window === 'undefined' ? global : window;
  const sysFormater =
    that.Intl &&
    that.Intl.NumberFormat &&
    new that.Intl.NumberFormat('zh-Hans-CN', {
      minimumFractionDigits: fractionDigits,
      maximumFractionDigits: fractionDigits
    });
  return sysFormater
    ? sysFormater.format
    : function format(n) {
      if (
        typeof n !== 'number' ||
          (typeof n === 'string' && isNaN(parseFloat(n)))
      ) {
        return 'NaN';
      }
      const numberArr = Number(n)
        .toFixed(fractionDigits)
        .split('');
      const indexBeforeDot =
          numberArr.length -
          1 -
          (fractionDigits === 0 ? 0 : fractionDigits + 1);
      for (let i = indexBeforeDot, cnt = 0; i >= 0; i -= 1) {
        if (
          ++cnt % 3 === 0 && // eslint-disable-line no-plusplus
            i - 1 >= 0 &&
            numberArr[i - 1] !== '-' // 当前位的前一位不是负号
        ) {
          numberArr.splice(i, 0, ',');
        }
      }
      return numberArr.join('');
    };
};

/**
 * app hierarchy ( app level ) 与  app tabtype 的转化
 */
export const getAppLevelFromAppTabType = type => {
  switch (type) {
    case AppTabTypes.appTab:
      return 'app';
    case AppTabTypes.adPosTab:
    case AppTabTypes.appAdPosTab:
      return 'adPos';
    default:
      throw new Error(`无效的 AdTabTypes:${type}`);
  }
};

/**
 * 应用管理列表页 导航路由
 */
export const getAppAdPosPath = tabType => {
  switch (tabType.key) {
    case AppTabTypes.appTab:
      return '/developer/appManagement/app';
    case AppTabTypes.adPosTab:
      return '/developer/appManagement/adSlot';
    default:
      return;
  }
};

/**
 * 应用管理列表页 表格项点击路由跳转
 * tabType: 被点击项所在导航tab；
 * id：被点击项的id
 */
export const getAppEntityPath = (tabType, appId, slotUdid, slotOpStatus) => {
  switch (tabType) {
    case AppTabTypes.appTab:
      return `/developer/appManagement/${appId}/adSlot`;
    case AppTabTypes.adPosTab:
    case AppTabTypes.appAdPosTab:
      return `/developer/appManagement/${slotUdid}/adSlot/edit?appId=${appId}&slotOpStatus=${slotOpStatus}`;
    default:
      return;
  }
};

/**
 * 应用管理列表页 新建应用/新建广告位
 */
export const createNewEntityPath = (tabType, id) => {
  switch (tabType) {
    case AppTabTypes.appTab:
      return '/developer/appManagement/app/new';
    case AppTabTypes.appAdPosTab:
      return `/developer/appManagement/${id}/adSlot/new`;
    default:
      break;
  }
};

// 英文字母和数字算半个字符，其他的都算1个字符
export const checkTextLength = (value, minLength, maxLength) => {
  if (typeof value !== 'string') {
    return false;
  }
  const halfCharReg = /[0-9a-zA-Z]/g;
  let halfCharLen = 0;
  let oneCharLen = 0;
  let realLen = 0;
  if (!value.match(halfCharReg)) {
    // 全是整个字符
    oneCharLen = value.length;
  } else {
    halfCharLen = value.match(halfCharReg).length / 2;
    oneCharLen = value.length - (halfCharLen * 2);
  }
  realLen = oneCharLen + halfCharLen;
  if (realLen < minLength) {
    return false;
  }
  return (realLen <= maxLength);
};

/**
 * 应用、广告位名称长度范围
 */
export const appAdPosEntityNameLengthRange = [0.5, 15];

export const isValidAppAdPosEntityName = (name = '') => {
  return checkTextLength(
    name.trim(),
    appAdPosEntityNameLengthRange[0],
    appAdPosEntityNameLengthRange[1],
  );
};

// 求最大公约数
export const gcd = (a, b) => {
  let r;
  while (b > 0) {
    r = a % b;
    a = b; // eslint-disable-line no-param-reassign
    b = r; // eslint-disable-line no-param-reassign
  }
  return a;
};

// 获取应用管理多维度新建项 -- 应用和广告位列表的path
export const getAppEntityListPath = (tabType, appId, appName) => {
  switch (tabType) {
    case 'adPos':
      return (appId !== -1)
        ? `/developer/appManagement/${appId}/adSlot${appName ? '?appName=' + appName : ''}`
        : '/developer/appManagement/app';
    case 'app':
      return '/developer/appManagement/app';
  }
};

// 新建广告位，styleInfo转换styleList
export const generateStyleList = styleInfo => {
  let styleList = [];
  styleInfo.map(item => {
    const {
      minSupportVersion,
      styleAuditStatus,
      styleStandardTemplateId,
      styleType,
      styleId,
      schemaStandardTemplateName,
      styleName,
      imageElements,
      textElements,
      videoElements
    } = item;
    const listEle = {
      minSupportVersion,
      styleAuditStatus: SlotStyleAuditStatusForBE[styleAuditStatus],
      styleName: schemaStandardTemplateName || styleName,
      styleType,
      styleId,
      styleStandardTemplateId,
      imageElements,
      textElements,
      videoElements
    };
    styleList.push(listEle);
  });
  return styleList;
};

/**
 * 添加样式信息
 */
const restElemsItems = (styleInfo, elemsMapKey, elemType) => {
  const newElemsItems = [..._.values(elemsMapKey)];
  styleInfo &&
    styleInfo[elemType] &&
    styleInfo[elemType].forEach(t => {
      newElemsItems.findIndex(s => s === t) > -1 &&
        newElemsItems.splice(newElemsItems.findIndex(s => s === t), 1);
    });
  return newElemsItems;
};

// 生成初始化的新建广告位数据
export const generateDetailInfo = (presetObj, index = 1) => {
  const { standardTemplates } = presetObj;

  const styleInfo = {
    key: 0,
    minSupportVersion: '0.0.0',
    styleAuditStatus: '-1',
    styleType: 0,
    styleNameValid: true,
    styleNameRepeat: false,
    versionValid: true,
    ...JSON.parse(JSON.stringify(standardTemplates[index]))
  };
  
  styleInfo.styleStandardTemplateId = styleInfo.schemaStandardTemplateId;
  delete styleInfo.schemaStandardTemplateId;
  styleInfo.imageElemsList = styleInfo.imageElements &&
  styleInfo.imageElements.map(item => item = item.elementKey);
  styleInfo.imageElemsList = restElemsItems(styleInfo, imageElemsMapKey, 'imageElemsList');
  styleInfo.textElemsList = styleInfo.textElements &&
  styleInfo.textElements.map(item => item = item.elementKey);
  styleInfo.textElemsList = restElemsItems(styleInfo, textElemsMapKey, 'textElemsList');
  styleInfo.videoElemsList = styleInfo.videoElements &&
  styleInfo.videoElements.map(item => item = item.elementKey);
  styleInfo.videoElemsList = restElemsItems(styleInfo, videoElemsMapKey, 'videoElemsList');
  // 初始化所有文本内容都合法
  styleInfo.imageElements && styleInfo.imageElements.forEach(item => {
    item.attr = { width: item.width, height: item.height };
    item.isStandard = true;
    item.nameValid = true;
    item.keyValid = true;
  });
  styleInfo.textElements && styleInfo.textElements.forEach(item => {
    item.isStandard = true;
    item.nameValid = true;
    item.keyValid = true;
  });
  return styleInfo;
};

export const initialEditAdSlotStyleInfo = styleList => {
  styleList.forEach(item => {
    item.styleType = parseInt(item.styleType, 10);
    item.styleNameValid = true;
    item.styleNameRepeat = false;
    item.versionValid = true;
    // 初始化所有文本内容都合法
    item.imageElements.forEach(item => {
      item.attr = { width: item.width, height: item.height };
      item.nameValid = true;
      item.keyValid = true;
    });
    item.textElements.forEach(item => {
      item.nameValid = true;
      item.keyValid = true;
    });
    item.imageElemsList = item.imageElements &&
      item.imageElements.map(ele => ele = ele.elementKey);
    item.imageElemsList = restElemsItems(item, imageElemsMapKey, 'imageElemsList');
    item.textElemsList = item.textElements &&
      item.textElements.map(ele => ele = ele.elementKey);
    item.textElemsList = restElemsItems(item, textElemsMapKey, 'textElemsList');
    item.videoElemsList = item.videoElements &&
      item.videoElements.map(ele => ele = ele.elementKey);
    item.videoElemsList = restElemsItems(item, videoElemsMapKey, 'videoElemsList');
  });
  return styleList;
};

// 前端对应的是attr，后台对应的没有attr需要一个转换
export const transtfromStyleElement = (itemIndex, itemType, itemValue) => {
  switch(itemType) {
    case 'imageElements': {
      itemValue.map(item => {
        const { width, height, sizeMonitor } = item.attr;
        item.width = parseInt(width, 10) || '';
        item.height = parseInt(height, 10) || '';
        item.sizeMonitor = sizeMonitor;
      });
      return itemValue;
    }
    case 'textElements': {
      itemValue.map(item => {
        delete item.attr;
      });
      return itemValue;
    }
    case 'videoElements': {
      itemValue.map(item => {
        delete item.attr;
      });
      return itemValue;
    }
    default: 
      return itemValue;
  }
};

// 动态生成广告位样式的Select Ratio内容
export const generatePictureRadioSelect = (elementKey, imageElements) => {
  let pictureElemRatio = {};
  imageElements.sort(
    (a, b) => parseInt(a.ratio.split(':')[0], 10) - parseInt(b.ratio.split(':')[0], 10))
    .map(item => {
      if (item.elementKey === elementKey) {
        pictureElemRatio[item.ratio] = [item.width, item.height];
      }
    });
  return pictureElemRatio;
};

// 动态替换广告位图片元素样式，因为ratio变化后对应的元素名称也会发生变化
export const changePictureRatioElem = (elementKey, ratio, imageElements) =>
  imageElements.find(
    item => item.elementKey === elementKey && item.ratio === ratio
  );

// 动态替换广告位文字元素样式，因为length变化后对应的元素名称也会发生变化
export const changeTextLengthElem = (elementKey, length, textElements) =>
  textElements.find(
    item => item.elementKey === elementKey && item.length === length
  );

// 增加广告位样式的item
export const addDefaultStyleItem = (elemType, elementKey, standrdElements) => {
  const { imageElements, textElements, videoElements } = standrdElements;
  switch(elemType) {
    case '图片元素': {
      if (elementKey === '自定义') {
        return getCustomDefaultElem('image');
      }
      const resElem = imageElements.find(
        item => item.elementKey === elementKey
      );
      resElem.nameValid = true;
      resElem.keyValid = true;
      resElem.isStandard = true;
      return resElem;
    }
    case '文字元素': {
      if (elementKey === '自定义') {
        return getCustomDefaultElem('text');
      }
      const resElem = textElements.find(
        item => item.elementKey === elementKey
      );
      resElem.nameValid = true;
      resElem.keyValid = true;
      resElem.isStandard = true;
      return resElem;
    }
    case '视频元素': {
      const resElem = videoElements.find(
        item => item.elementKey === elementKey
      );
      resElem.nameValid = true;
      resElem.keyValid = true;
      resElem.isStandard = true;
      return resElem;
    }
    default:
      break;
  }
};

// 每次增加完元素需要重制列表
export const resetStyleElemsList = (originList, elemValue) => {
  const resArr = [...originList];
  elemValue.map(item => {
    const keyIndex = resArr.findIndex(ele => ele === item.elementKey);
    if (keyIndex !== -1) {
      resArr.splice(keyIndex, 1);
    }
  });
  return resArr;
};

/**
 * 判断新增样式是否重复,返回true重复，返回false不重复
 * @param {Array} styleInfo
 * @param {String} newStyleName 
 */
export const checkStyleInfoNameIsRepeat = (styleInfo, newStyleName) =>
  styleInfo.some(item =>
    (item.styleName || item.schemaStandardTemplateName) === newStyleName);

// 广告位提交审核的时候生成post数据
export const getneratePostAuditData = styleInfo => {
  let resArr = [];
  styleInfo.map(item => {
    let obj = {};
    obj.styleId = item.styleId;
    obj.styleScreenshot = item.styleScreenshot[0].value;
    resArr.push(obj);
  });
  return resArr;
};

/**
 * 获取广告位真实审核状态，需要根据广告位列表来判断。
 * @param Array styleList
 */
export const getRealSlotAuditStatus = styleList => {
  const realStatusMap = {
    0: 9999,
    1: 999,
    2: 99
  };
  const resStatus = {
    9999: 0,
    999: 1,
    99: 2
  };
  let realStatus = -1;
  styleList.map(item => {
    const { styleAuditStatus } = item;
    if (styleAuditStatus === SlotStyleAuditStatusForBE.草稿) return;
    if (realStatusMap[styleAuditStatus] > realStatus) {
      realStatus = realStatusMap[styleAuditStatus];
    }
  });
  return typeof resStatus[realStatus] !== 'undefined' ? resStatus[realStatus] : -1;
};

/**
 * 生成自定义元素的ratio
 * @param {Number} value 宽高值
 * @param {Number} type 类型
 * @param {String} ratio 元素的比例
 */
export const generateCustomRatio = (value, type, ratio) => 
  type === 'width'
    ? `${value}:${parseInt(ratio.split(':')[1], 10)}`
    : `${parseInt(ratio.split(':')[0], 10)}:${value}`;

/**
 * 自定义元素ratio变化对应宽高也需要改变
 * @param {Object} elem 改变的元素 
 */
export const changeCustomHeight = elem =>
  parseInt(
    elem.width *
    (parseInt(elem.ratio.split(':')[1], 10) / parseInt(elem.ratio.split(':')[0], 10)),
    10
  );

/**
 * 重命名
 * @param {Array} styleInfo 原有样式列表
 * @param {Object} newStyle 新增样式元素 
 */
export const renameAddStyleInfo = (styleInfo, newStyle) => {
  let index = 0;
  const { styleStandardTemplateId } = newStyle;
  styleInfo.map(item => {
    if (item.styleStandardTemplateId === styleStandardTemplateId) {
      index += 1;
    }
  });
  newStyle.schemaStandardTemplateName += (index === 0 ? '' : index);
  return newStyle;
};
/**
 * 生成所有元素的key，避免重复
 * @param {Array} imageElements 
 * @param {Array} textElements
 * @param {Array} videoElements
 */
export const generateStyleTotalKeyMap = (imageElements, textElements, videoElements) => {
  let keyArr = [];
  imageElements.map(item => keyArr.push(item.elementKey));
  textElements.map(item => keyArr.push(item.elementKey));
  videoElements.map(item => keyArr.push(item.elementKey));
  return keyArr;
};
/**
 * 检验新增的自定义元素名称是否合法
 * @param {Object} addItem
 * @param {Array[Object]} elems 
 */
export const reNewAddItem = (addItem, totalKeyMap) => {
  const keyRepeat = _.includes(totalKeyMap, addItem.elementKey);
  if (keyRepeat) {
    addItem.keyValid = false;
  }
  return addItem;
};
/**
 * 正则验证是否包含中文字符
 * @param {String} value 
 */
export const checkCustomStyleValueValid = value => /^[a-zA-Z][a-zA-Z0-9_]*$/.test(value);

/**
 * 校验版本号是否合法
 * @param {String} version 
 */
export const checkVersionIsValid = version => {
  /**
   * 合法的版本号：0.0.0, v1.0.0, 1.0.0v, V1.0.0, 1.0.0V
   */
  const versionReg = new RegExp('(^v?(\\d+\\.){0,3}\\d+$)|(^(\\d+\\.){0,3}\\d+v?$)', 'i');
  return versionReg.test(version);
};

// =============== 账户管理 ================== //

/**
 * 自测设备信息
 */

// 是否是合法的设备号
export const isValidDeviceId = deviceId => {
  const checkReg = /^[0-9a-zA-Z-]{1,}$/;
  return checkReg.test(deviceId) && deviceId.length <= 100 && deviceId.trim().length > 0;
};

// 是否是重复的设备号
export const isRepeatDeviceId = (deviceId, targetArray) => {
  let flag = false;
  targetArray.map(item => {
    if (item.deviceId === deviceId) {
      flag = true;
    }
  });
  return flag;
};

// 设备更新成功重构state
export const changeDeviceListStatus = (list, ids, status) => (
  list.map(item => {
    if (_.includes(ids, item.id)) {
      item.status = status;
    }
    return item;
  })
);

/**
 * 判断联系人填写的联系电话是否合法
 * 支持11位数字手机号，9位数字座机号，12位数字座机号
 * @param {String} value
 */
export const checkPhoneIsValid = (value = '') => {
  const callExp = {
    regCell: /^0\d{2}-?\d{8}$/, // 010-68889999
    regCell2: /^0\d{3}-?\d{7}$/, // 0429-4589765
    regFour: /^400-[0-9]{4}-[0-9]{3}$/,
    regSpeCell: /^400-[0-9]{3}-[0-9]{4}$/,
    regTelphone: /^1[34578]\d{9}$/
  };
  return _.values(callExp).some(item => item.test(value.trim()));
};

/**
 * 判断联系人姓名是否合法
 * 规则：2～6个字符必须是中文
 * @param {String} value 
 */
export const checkUsernameIsValid = (value = '') => /^[\u4e00-\u9fa5]{2,6}$/.test(value.trim());

/**
 * 验证是否是合法的邮箱
 * 规则：正常的邮箱校验规则
 * @param {String} value
 */
export const checkEmailIsValid = (value = '') =>
  /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(value.trim());

/**
 * 验证是否是合法的地址
 * 规则：0 < address.length < 100
 * @param {String} value 
 */
export const checkAddressIsValid = (value = '') => (value && value.trim().length > 0) && value.trim().length < 100;

// ================ 账户报表 =================== //
export const generateDeveloperReportQuery = (tabType, query) => {
  if (query.startDate === query.endDate &&
    query.aggregate === DataReportAggregateType.按天) {
    query.aggregate = DataReportAggregateType.按小时;
  }
  switch(tabType) {
    case DataReportTabs.账户报表: {
      return {
        pageCapacity: query.pageSize,
        pageNo: query.pageNo,
        aggregate: query.aggregate,
        startDate: query.startDate,
        endDate: query.endDate
      };
    }
    case DataReportTabs.应用: {
      return {
        pageCapacity: query.pageSize,
        pageNo: query.pageNo,
        aggregate: query.aggregate,
        startDate: query.startDate,
        endDate: query.endDate,
        appIds: query.ids
      };
    }
    case DataReportTabs.广告位: {
      return {
        pageCapacity: query.pageSize,
        pageNo: query.pageNo,
        aggregate: query.aggregate,
        startDate: query.startDate,
        endDate: query.endDate,
        appId: query.id,
        slotUdids: query.ids
      };
    }
    case DataReportTabs.样式: {
      return {
        pageCapacity: query.pageSize,
        pageNo: query.pageNo,
        aggregate: query.aggregate,
        startDate: query.startDate,
        endDate: query.endDate,
        slotUdids: query.ids || ''
      };
    }
    default:
      break;
  }
};

/**
 * 处理图表展示的响应的数据
 * @param {Array} data 
 */
export const handleChartReportResData = (list, isDayData) =>
  _.cloneDeep(list).map(item => {
    item.date = !isDayData ? item.date : `${item.date}时`;
    item.bidRate = parseFloat(item.bidRate, 10);
    item.clickRate = parseFloat(item.clickRate, 10);
    item.imprRate = parseFloat(item.imprRate, 10);
    return item;
  });

/**
 * 处理Table展示的响应的数据
 * @param {Array} list
 * @param {Object} totalObj
 * @param {String} dateRange
 */
export const handleTableReportResData = (list, totalObj, dateRange) => {
  if (list.length === 0) {
    return [];
  }
  
  return dateRange
    ? [totalObj, ..._.cloneDeep(list).map(item => { item.date = dateRange; return item; })]
    : [totalObj, ...list];
};

/**
 * 生成数据报表下载部分的url
 * @param {Object} payload
 */
export const generateDataReportDownloadUrl = payload => {
  const {
    startDate,
    endDate,
    aggregate,
    type,
    id,
    ids
  } = payload;
  let reqUrl = '';
  if (type === DataReportTabs.账户报表) {
    // eslint-disable-next-line
    reqUrl = `/developer/api/dataReport/downloadReportData?startDate=${startDate}&endDate=${endDate}&aggregate=${aggregate}&type=${type}`;
  } else if (type === DataReportTabs.应用) {
    // eslint-disable-next-line
    reqUrl = `/developer/api/dataReport/downloadReportData?startDate=${startDate}&endDate=${endDate}&aggregate=${aggregate}&type=${type}&appIds=${ids}`;
  } else if (type === DataReportTabs.广告位) {
    // eslint-disable-next-line
    reqUrl = `/developer/api/dataReport/downloadReportData?startDate=${startDate}&endDate=${endDate}&aggregate=${aggregate}&type=${type}&appId=${id}&slotUdids=${ids}`;
  } else if (type === DataReportTabs.样式) {
    // eslint-disable-next-line
    reqUrl = `/developer/api/dataReport/downloadReportData?startDate=${startDate}&endDate=${endDate}&aggregate=${aggregate}&type=${type}&slotUdids=${ids}`;
  }
  return reqUrl;
};

/**
 * 生成下载的数据报表的tableHeader
 * @param {String} type
 */
export const generateDataReportTableHeader = type => {
  const commonHeader = ['展示数', '点击数', '点击率'];
  const accountHeader = ['时间', '请求广告数', '返回广告数', '填充率', '展示率'];
  const appHeader = ['时间', '应用名称', '请求广告数', '返回广告数', '填充率', '展示率'];
  const slotHeader = ['时间', '广告位名称', '应用名称', '请求广告数', '返回广告数', '填充率', '展示率'];
  const styleHeader = ['时间', '样式名称', '广告位名称', '应用名称'];
  switch (type) {
    case DataReportTabs.账户报表: {
      return [...accountHeader, ...commonHeader];
    }
    case DataReportTabs.应用: {
      return [...appHeader, ...commonHeader];
    }
    case DataReportTabs.广告位: {
      return [...slotHeader, ...commonHeader];
    }
    case DataReportTabs.样式: {
      return [...styleHeader, ...commonHeader];
    }
    default:
      break;
  }
};

/**
 * 生成数据报表下载的body内容
 * @param {Object} ret
 */
export const generateDataReportTableBody = (type, ret, aggregate = DataReportAggregateType.按天, dateRange) => {
  const commonTotalItem = [
    ret.totalRequestAdNum && ret.totalRequestAdNum.toString(),
    ret.totalBid && ret.totalBid.toString(),
    ret.totalBidRate,
    ret.totalImprRate,
    ret.totalImpr.toString(),
    ret.totalClick.toString(),
    ret.totalClickRate
  ];
  const commonItem = item => [
    item.requestAdNum && item.requestAdNum.toString(),
    item.bid && item.bid,
    item.bidRate,
    item.imprRate,
    item.impr.toString(),
    item.click.toString(),
    item.clickRate
  ];
  switch (type) {
    case DataReportTabs.账户报表: {
      const totalItem = [
        '合计',
        ...commonTotalItem
      ];
      let elementArr = [];
      ret.allList.map(item => {
        elementArr.push([
          aggregate === DataReportAggregateType.按天 ? item.date : dateRange,
          ...commonItem(item)
        ]);
      });
      return [totalItem, ...elementArr];
    }
    case DataReportTabs.应用: {
      const totalItem = [
        '合计',
        '--',
        ...commonTotalItem
      ];
      let elementArr = [];
      ret.allList.map(item => {
        elementArr.push([
          aggregate === DataReportAggregateType.按天 ? item.date : dateRange,
          item.appName,
          ...commonItem(item)
        ]);
      });
      return [totalItem, ...elementArr];
    }
    case DataReportTabs.广告位: {
      const totalItem = [
        '合计',
        '--',
        '--',
        ...commonTotalItem
      ];
      let elementArr = [];
      ret.allList.map(item => {
        elementArr.push([
          aggregate === DataReportAggregateType.按天 ? item.date : dateRange,
          item.slotName,
          item.appName,
          ...commonItem(item)
        ]);
      });
      return [totalItem, ...elementArr];
    }
    case DataReportTabs.样式: {
      const totalItem = [
        '合计',
        '--',
        '--',
        '--',
        ret.totalImpr.toString(),
        ret.totalClick.toString(),
        ret.totalClickRate
      ];
      let elementArr = [];
      ret.allList.map(item => {
        elementArr.push([
          aggregate === DataReportAggregateType.按天 ? item.date : dateRange,
          item.schemaName,
          item.slotName,
          item.appName,
          item.impr.toString(),
          item.click.toString(),
          item.clickRate
        ]);
      });
      return [totalItem, ...elementArr];
    }
    default:
      break;
  }
};

const dealOriginMenuchildren = list => {
  let resList = [];
  list.map((item, index) => {
    let tempObj = {};
    tempObj.sortKey = index;
    tempObj.id = item.slotUdid;
    tempObj.name = item.slotName;
    tempObj.value = `${item.slotName}${item.slotUdid}`;
    resList.push(tempObj);
  });
  return resList;
};

// 生成cascading menu list
export const generateOriginMenuList = (list, type) => {
  let resList = [];
  switch (type) {
    case DataReportTabs.应用: {
      list.map(item => {
        let tempObj = {};
        tempObj.sortKey = item.appId;
        tempObj.id = item.appId;
        tempObj.name = item.appName;
        tempObj.value = `${item.appName}${item.appId}`;
        tempObj.children = [];
        resList.push(tempObj);
      });
      return resList;
    }
    case DataReportTabs.样式:
    case DataReportTabs.广告位: {
      list.map(item => {
        let tempObj = {};
        tempObj.sortKey = item.appId;
        tempObj.id = item.appId;
        tempObj.name = item.appName;
        tempObj.value = `${item.appName}${item.appId}`;
        tempObj.children = dealOriginMenuchildren(item.slots);
        resList.push(tempObj);
      });
      return resList;
    }
    default:
      break;
  }
};

/**
 * 根据已选list，生成查询的ids
 * @param {String} type 类型
 * @param {Array} list 已选数组
 */
export const generateDataReportQueryIds = (type, list) => {
  switch (type) {
    case DataReportTabs.应用: {
      return list.map(item => item.id).join(',');
    }
    case DataReportTabs.样式:
    case DataReportTabs.广告位: {
      return list.map(item => item.children.map(ele => ele.id)).join(',');
    }
    default:
      break;
  }
};

/**
 * 初始化生成selectedMenuList
 * @param {String} type 
 * @param {Array} list 
 * @param {String|undefined} slotUdid 
 */
export const generateSelectedMenuList = (type, list, slotUdid) => {
  switch (type) {
    case DataReportTabs.广告位:
      return generateOriginMenuList(list, type);
    case DataReportTabs.样式:
      list[0].slots = list[0].slots.filter(item => item.slotUdid === slotUdid);
      return generateOriginMenuList(list, type);
    default:
      return [];
  }
};

export const generateSelectedCount = (type, list) => {
  if (type === DataReportTabs.应用) {
    return list.length;
  }
  let result = 0;
  list.map(item => result += item.children.length);
  return result;
};

// =============== 聚合SDK ================== //

// 生成cascading menu list
export const generateOriginMenuListSDK = (list, style) => {
  let resList = [];
  switch (style) {
    case listType.osVersionIds: 
    case listType.appVersionIds: 
    case listType.channelNoIds: {
      list.map(item => {
        let tempObj = {};
        tempObj.sortKey = item.id;
        tempObj.id = item.id;
        tempObj.name = item.name;
        tempObj.value = item.name;
        tempObj.children = [];
        tempObj.isEdit = false;
        tempObj.style = style;
        resList.push(tempObj);
      });
      return resList;
    }
    case listType.countryIds:
    case listType.sysLanguageIds: {
      list.map(item => {
        let tempObj = {};
        tempObj.sortKey = item.id;
        tempObj.id = item.id;
        tempObj.name = item.name;
        tempObj.value = item.name;
        tempObj.children = [];
        tempObj.style = style;
        resList.push(tempObj);
      });
      return resList;
    }
    default:
      break;
  }
};

// 检查表单元素是否合法
export const checkForm = formItem => {
  const judge1 = 
    Object.values(formItem)[0] === '' || 
    Object.values(formItem)[0] === undefined || 
    Object.values(formItem)[0].length > 25 ? false : true;
  const judge2 = formItem.platformPriorityId === 0 || formItem.platformPriorityId === undefined ? false : true;
  const judge3 = Object.values(formItem)[0] === 1 ? false : true;
  switch(Object.keys(formItem)[0]) {
    case 'settingName': {
      return {settingName: judge1};
    }
    case 'platformPriorityId': {
      return {platformPriorityId: judge2};
    }
    case 'osVersionSettingMode': {
      return {osVersionSettingMode: judge3};
    }
    case 'appVersionSettingMode': {
      return {appVersionSettingMode: judge3};
    }
    case 'channelNoSettingMode': {
      return {channelNoSettingMode: judge3};
    }
    case 'countrySettingMode': {
      return {countrySettingMode: judge3};
    }
    case 'sysLanguageSettingMode': {
      return {sysLanguageSettingMode: judge3};
    }
    default:
      break;
  }
};

/**
 *  检验是否是合法的广告位id
 */
export const isValidSlotUdid = id => /^[a-z0-9]{32}$/.test(id.trim());