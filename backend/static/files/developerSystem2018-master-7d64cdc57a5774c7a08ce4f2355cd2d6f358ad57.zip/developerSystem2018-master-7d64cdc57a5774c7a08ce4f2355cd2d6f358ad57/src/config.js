/**
 * 开发者系统相关配置内容
 */
const fs = require('fs');
const path = require('path');

const pro = 'production';
const dev = 'development';
const env = process.env.NODE_ENV || pro;

// 上传文件目录，为 server.js 的所在目录的同级目录 uploads（即根目录下的 uploads）
const uploadDir = path.resolve(__dirname, '../uploads');

// 下载文件目录，为 server.js 的所在目录的同级目录 downloads（即根目录下的 downloads）
const downloadDir = path.resolve(__dirname, '../downloads');

if (!fs.existsSync(uploadDir)) {
  try {
    fs.mkdirSync(uploadDir);
  } catch (e) {
    throw new Error(
      `no upload directory ${uploadDir}, make it first before start service`,
    );
  }
}

if (!fs.existsSync(downloadDir)) {
  try {
    fs.mkdirSync(downloadDir);
  } catch (e) {
    throw new Error(
      `no upload directory ${downloadDir}, make it first before start service`,
    );
  }
}

/* eslint-disable max-len */

if (process.env.BROWSER) {
  throw new Error(
    'Do not import `config.js` from inside the client-side code.',
  );
}

/**
 * 参数说明：
 * nodeHost:
 *   本服务在公网访问的域(hostname + port)
 *   如果端口是80，则不写
 *   如果端口不是80，需要写全
 *
 * nodePort:
 *   node 服务的启动端口
 *
 * javaHost:
 *   java 服务在内网访问的域(hostname + port)
 *   如果端口是80，则不写
 *   如果端口不是80，需要写全
 */
const environment = {
  [dev]: {
    nodeHost: process.env.NODE_HOST || 'zhixuan.youdao.com/developer',
    nodePort: process.env.NODE_PORT,
    javaHost: process.env.JAVA_HOST || 'nc110x.corp.youdao.com:12028'
  },
  [pro]: {
    nodeHost: process.env.NODE_HOST,
    nodePort: process.env.NODE_PORT,
    javaHost: process.env.JAVA_HOST
  }
}[env];

const testUsers = {
  kevin: {
    email: 'yodao_kevin@163.com',
    token: 'eyJhbGciOiJIUzUxMiJ9.eyJjcmVhdGVkIjoxNTMyMzEyMzM4Mjg2LCJpZCI6MSwiZXhwIjoxNTMyMzQ4MzM4Mjg2fQ.Yne0J6JSo1J-L17Ifdnr703v4jdgPxlcVfngIzkj14kp21ahgJ5Xm7t8KgZYjy_widnjdtOvyWKmQfcYQJCN6g',
    developerId: 2,
    pw: '362e8149121ba6f7e517f72d92c3fe66'
  },
  dsp: {
    email: 'yodao_dsp_test@163.com',
    token: 'eyJhbGciOiJIUzUxMiJ9.eyJjcmVhdGVkIjoxNTE1MDU3NTE2ODI0LCJpZCI6MSwiZXhwIjoxNTE1MDkzNTE2ODI0fQ.U7Abu6RWdW7l4Wf5I_C7SNqpg3_ECZuE_ftAzyglgFICCr025xEgWQZqBAiIPpDzXj3wIOfaYyqikrQT-g0_1g111',
    developerId: 259158,
    pw: '95ec3e41a4bde83af10b5e26cf93f18f'
  }
};

module.exports = {
  // Node.js app
  hotPort: 3003,
  port: environment.nodePort,
  nodeHost: environment.nodeHost,
  javaHost: environment.javaHost,

  uploadDir: uploadDir,

  downloadDir: downloadDir,

  testUser: testUsers.kevin,

  // https://expressjs.com/en/guide/behind-proxies.html
  trustProxy: process.env.TRUST_PROXY || 'loopback',

  // API Gateway
  api: {
    // API URL to be used in the client-side code
    clientUrl: process.env.API_CLIENT_URL || '',
    // API URL to be used in the server-side code
    serverUrl: process.env.API_SERVER_URL || `http://${environment.javaHost}`
  },

  // Database
  databaseUrl: process.env.DATABASE_URL || 'sqlite:database.sqlite',

  // Web analytics
  analytics: {
    // https://analytics.google.com/
    googleTrackingId: process.env.GOOGLE_TRACKING_ID // UA-XXXXX-X
  },

  // Authentication
  auth: {
    jwt: { secret: process.env.JWT_SECRET || 'jwt校验用' }
  }
};
