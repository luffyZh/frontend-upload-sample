import _ from 'lodash';
// ====================================== 首页 --START ============================================//
/**
 * 系统功能列表
 */
const systemFuncsKey = {
  首页: 'home',
  应用管理: 'appManagement',
  数据报表: 'dataReport',
  帮助中心: 'helpCenter',
  账户管理: 'accountMangement',
  聚合SDK: 'meditationSdk'
};
/**
 * 系统白名单功能
 */
const systemWhiteFuncs = ['meditationSdk'];
/**
 * 用于页面和 node 通信的参数传递
 */
const dateRangeValues = {
  今天: 'today',
  昨天: 'yesterday',
  过去7天: 'last7',
  过去30天: 'last30'
};
/**
 * 首页查询日期菜单
 */
const DateRangeItems = [{
  name: '今天',
  range: [0, 0]
}, {
  name: '昨天',
  range: [-1, -1]
}, {
  name: '过去7天',
  range: [-7, -1]
}, {
  name: '过去30天',
  range: [-30, -1]
}].map(item => ({
  ...item,
  key: dateRangeValues[item.name],
  value: dateRangeValues[item.name]
}));

// ====================================== 首页 --END ============================================//

// ======================================= 其他 -- START ==========================================//

/**
 * 所有操作的状态值
 */
const OperationStatus = {
  initial: 'initial',
  loading: 'loading',
  load_success: 'load_success',
  load_fail: 'load_fail',
  editing: 'editing',
  saving: 'saving',
  save_success: 'save_success',
  save_fail: 'save_fail'
};
// ======================================= 其他 -- END ==========================================//

// ====================================== 应用管理 --START =========================================//
/**
 * 列表页各tab的层级关系类型
 */
const AppTabTypes = {
  appTab: 'appTab',
  adPosTab: 'adPosTab',
  appAdPosTab: 'appAdPosTab'
};

/**
 * 列表页不同层级的 tabs
 */
const AppTabItems = {
  [AppTabTypes.appTab]: [
    {
      key: AppTabTypes.appTab,
      name: '应用'
    },
    {
      key: AppTabTypes.adPosTab,
      name: '广告位'
    }
  ],
  [AppTabTypes.adPosTab]: [
    {
      key: AppTabTypes.appTab,
      name: '应用'
    },
    {
      key: AppTabTypes.adPosTab,
      name: '广告位'
    }
  ],
  [AppTabTypes.appAdPosTab]: [
    {
      key: AppTabTypes.appAdPosTab,
      name: '广告位'
    }
  ]
};

/**
 * 应用和广告位列表页 查询条件前端对应关系
 */
const AppAdposListMapForFE = {
  不限: 'all',
  暂停: 'pause',
  开启: 'open',
  删除: 'delete',
  未删除: 'notDeleted',
  已删除: 'deleted',
  iOS: 'ios',
  Android: 'android',
  安卓: 'android',
  有效: 'effect',
  审核中: 'onaudit',
  审核不通过: 'unpass',
  草稿: 'draft',
  信息流: 'infoFlow',
  开屏: 'openScreen',
  插屏: 'insertScreen',
  焦点图: 'focusImg',
  激励视频: 'enVideo',
  横幅: 'banner',
  自定义: 'custom'
};

const AdPosTypeForFE = {
  1: 'smallImage',
  2: 'bigImage',
  3: 'exImage',
  4: 'video',
  5: 'openScreen',
  6: 'insertScreen',
  7: 'banner',
  8: 'focusImg',
  9: 'enVideo',
  0: 'custom'
};

const AdPosTypeForBE = {
  infoFlow: 1,
  smallImage: 1,
  bigImage: 2,
  exImage: 3,
  video: 4,
  openScreen: 5,
  insertScreen: 6,
  banner: 7,
  focusImg: 8,
  enVideo: 9,
  custom: 0
};

export const AppOsForBE = {
  all: '',
  ios: 0,
  android: 1,
  web: 2
};

export const AppOsForFE = {
  0: 'iOS',
  1: 'Android',
  2: 'Web'
};

export const AppStatusForFE = {
  0: 'open',
  1: 'pause',
  2: 'deleted',
  3: 'notDeleted'
};

export const AppStatusForBE = {
  all: '',
  open: 0,
  pause: 1,
  deleted: 2,
  notDeleted: 3
};

export const AppOpStatusForFE = {
  0: 'open',
  1: 'pause',
  2: 'delete'
};

export const AppOpStatusForBE = {
  open: 0,
  pause: 1,
  delete: 2
};

export const SlotOpStatusForBE = {
  all: '',
  open: 0,
  pause: 1,
  deleted: 2,
  delete: 2,
  notDeleted: 3
};

export const SlotOpStatusMapForFE = {
  开启: 0,
  暂停: 1,
  已删除: 2,
  未删除: 3,
  不限: ''
};

export const SlotOpStatusForFE = {
  0: 'open',
  1: 'pause',
  2: 'delete' 
};

export const SlotAuditStatusForBE = {
  all: '',
  effect: 0,
  onaudit: 1,
  unpass: 2,
  draft: -1
};

export const SlotAuditStatusForFE = {
  '-1': '草稿',
  0: '有效',
  1: '审核中',
  2: '审核不通过'
};

// 0#审核通过 1#待审核 2#审核不通过 -1#草稿
export const SlotStyleAuditStatusForBE = {
  草稿: -1,
  有效: 0,
  审核中: 1,
  审核不通过: 2
};

export const SlotStyleForBE = {
  all: '',
  custom: 0,
  banner: 1,
  insertScreen: 2,
  openScreen: 3,
  infoFlow: 4,
  enVideo: 5,
  focusImg: 7
};

export const SlotStyleForFE = {
  0: '自定义',
  1: '横幅',
  2: '插屏',
  3: '开屏',
  4: '信息流',
  5: '激励视频',
  6: '文字链',
  7: '焦点图'
};

const SlotStyleBE2FE = {
  '信息流': 'infoFlow',
  '开屏': 'openScreen',
  '插屏': 'insertScreen',
  '激励视频': 'enVideo',
  '焦点图': 'focusImg',
  '横幅': 'banner',
  '自定义': 'custom'
};

const SlotStyleFE2BE = {
  'infoFlow': '信息流',
  'openScreen': '开屏',
  'insertScreen': '插屏',
  'enVideo': '激励视频',
  'focusImg': '焦点图',
  'banner': '横幅',
  'custom': '自定义'
};

const NewAppClassify = {
  一级分类: '一级分类',
  二级分类: '二级分类'
};

/**
 * 应用管理 状态(or操作状态)的前端对照关系
 */
const AppEntitySwitchStatusMapForFE = {
  已开启: 'open',
  已暂停: 'pause',
  已禁用: 'delete'
};

/**
 * 查询条件应用和广告位列表 状态或操作状态 菜单
 */
const AppAdposStatus = ['不限', '暂停', '开启', '未删除', '已删除'].map(t => ({
  name: t,
  value: AppAdposListMapForFE[t]
}));

/**
 * 查询条件应用和广告位列表页 批量操作 菜单
 */
const TrackMultipleOperationItems = ['开启', '暂停', '删除'].map(t => ({
  name: t,
  value: AppAdposListMapForFE[t]
}));

/**
 * 查询条件中应用列表页 平台 菜单
 */
const AppOsTypes = ['不限', 'iOS', 'Android'].map(t => ({
  name: t,
  value: AppAdposListMapForFE[t]
}));

/**
 * 查询条件广告位列表页 审核状态 菜单
 */
const AdPosAuditStatus = ['不限', '草稿', '审核中', '有效', '审核不通过'].map(
  t => ({
    name: t,
    value: AppAdposListMapForFE[t]
  }),
);

/**
 * 查询条件广告位列表页 广告位类型 菜单
 */
const AdPosObject = [
  '不限',
  '信息流',
  '开屏',
  '插屏',
  '焦点图',
  '激励视频',
  '横幅',
  '自定义'
].map(t => ({
  name: t,
  value: AppAdposListMapForFE[t]
}));

const SlotAndStyleStatusText = {
  草稿: '草稿',
  审核中: '审核中',
  有效: '有效',
  审核不通过: '审核不通过',
  已审核: '已审核',
  提交审核: '提交审核'
};

/**
 * 每页显示条数
 */
const PageSizeOptions = ['10', '20', '50', '100'];

/**
 * 应用管理新建页面中子设置项
 */
const NewAppSettingItems = [
  {
    name: '新建应用',
    value: 'newApp'
  }
];
const NewAdPosSettingItems = [
  {
    name: '广告位信息',
    value: 'adPosSetting'
  },
  {
    name: '样式信息',
    value: 'styleSetting'
  }
];
const NewSelfTestSettingItems = [
  {
    name: '集成',
    value: 'integration'
  },
  {
    name: '确认自测设备',
    value: 'selfTestDevice'
  },
  {
    name: '获取自测物料',
    value: 'selfTestMaterial'
  }
];
const NewToAuditSettingItems = [
  {
    name: '上传截图',
    value: 'uploadScreenShot'
  },
  {
    name: '上传安装包',
    value: 'uploadInstallPackage'
  }
];

/**
 * 新建应用 平台
 */
const AppOsTypeZH = ['Android', 'iOS'].map(t => ({
  name: t,
  value: AppAdposListMapForFE[t]
}));

/**
 * 类型与显示label
 */
const AppOs2Label = {
  '-1': '应用包类型',
  0: 'iTunes链接',
  1: 'Android包名'
};

/**
 * 新建页面 保存与保存并继续按钮
 */
const saveButtonText = ['保存', '保存并继续'];

/**
 * 新建页面，各项与前端对应关系
 */
const AppAdposNewMapForFE = {
  不限: 'all',
  大图: 'bigImage',
  小图: 'smallImage',
  组图: 'exImage',
  视频: 'video',
  落地页型: 'landingPage',
  应用下载型: 'appDownload'
};

// 0-小图 1-大图 2-组图 3-视频
const AppAdInfoMapForBE = {
  smallImage: 0,
  bigImage: 1,
  exImage: 2,
  video: 3
};

// 0-小图 1-大图 2-组图 3-视频
const AppAdInfoMapForFE = {
  1: 'smallImage',
  2: 'bigImage',
  3: 'exImage',
  4: 'video'
};

const AppAdposNewMapForBE = {
  all: 0,
  appDownload: 2,
  landingPage: 1
};

const AppAdposStyleNewMapForFE = {
  0: 'all',
  2: 'appDownload',
  1: 'landingPage'
};

/**
 * 信息流样式
 */
const flowStyleItems = ['小图', '大图', '组图', '视频'].map(t => ({
  name: t,
  value: AppAdposNewMapForFE[t]
}));

/**
 * 新建样式推广标的类型
 */
const objectTypeItems = ['不限', '落地页型', '应用下载型'].map(t => ({
  name: t,
  value: AppAdposNewMapForFE[t]
}));

/**
 * 样式信息：文字、图片、视频样式
 */
const imageElemsMapKey = {
  主图片: 'mainimage',
  主图片1: 'mainimage1',
  主图片2: 'mainimage2',
  主图片3: 'mainimage3',
  主图片4: 'mainimage4',
  图标: 'iconimage',
  封面配图: 'coverimage',
  自定义: ''
};

const imageElemsListArray = _.values(imageElemsMapKey);

const textElemsMapKey = {
  标题: 'title',
  描述: 'text',
  '行动号召文案（如：立即下载、免费体验等）': 'ctaText',
  '企业/品牌/应用名（如网易有道、有道词典等）': 'appName',
  自定义: ''
};

const textElemsListArray = _.values(textElemsMapKey);

const videoElemsMapKey = {
  视频链接: 'videourl'
};

const videoElemsListArray = ['videourl'];

/**
 * 样式信息表格元素类型
 */
const styleElemName = ['图片元素', '文字元素', '视频元素'];

/**
 * 图片元素比例对应尺寸，除iconimage外
 */
const pictureElemRatio = {
  '1:2': [480, 960],
  '9:16': [720, 1280],
  '2:3': [640, 960],
  '1:1': [640, 640],
  '4:3': [640, 480],
  '3:2': [720, 480],
  '5:3': [800, 480],
  '16:9': [1280, 720],
  '2:1': [960, 480],
  '11:4': [1320, 480],
  '3:1': [1440, 480],
  '32:5': [640, 100]
};

/**
 * 文字元素和视频元素的key与字数的对应
 */
const elemsWordNum = {
  title: [10, 20, 30],
  text: [15, 20, 35],
  ctaText: [4],
  appName: [10]
};

/**
 * 样式信息，广告位类型与标准元素默认组合
 */
const defaultElemsInfo = {
  小图: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '3:2',
        width: 720,
        height: 480,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: [
      {
        elementName: '标题',
        elementKey: 'title',
        length: 20,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ]
  },
  大图: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '16:9',
        width: 1289, // 尺寸的宽
        height: 720, // 尺寸的高
        sizeMonitor: '',
        isStandard: true, // 标准元素 true；非标准元素 false
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: [
      {
        elementName: '标题',
        elementKey: 'title',
        length: 20,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ]
  },
  组图: {
    imageElements: [
      {
        elementName: '主图片1',
        elementKey: 'mainimage1',
        ratio: '3:2',
        width: 720, // 尺寸的宽
        height: 480, // 尺寸的高
        sizeMonitor: '',
        isStandard: true, // 标准元素 true；非标准元素 false
        nameValid: true,
        keyValid: true
      },
      {
        elementName: '主图片2',
        elementKey: 'mainimage2',
        ratio: '3:2',
        width: 720, // 尺寸的宽
        height: 480, // 尺寸的高
        sizeMonitor: '',
        isStandard: true, // 标准元素 true；非标准元素 false
        nameValid: true,
        keyValid: true
      },
      {
        elementName: '主图片3',
        elementKey: 'mainimage3',
        ratio: '3:2',
        width: 720, // 尺寸的宽
        height: 480, // 尺寸的高
        sizeMonitor: '',
        isStandard: true, // 标准元素 true；非标准元素 false
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: [
      {
        elementName: '标题',
        elementKey: 'title',
        length: 20,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ]
  },
  视频: {
    imageElements: [
      {
        elementName: '封面配图',
        elementKey: 'coverimage',
        ratio: '16:9',
        width: 1289, // 尺寸的宽
        height: 720, // 尺寸的高
        sizeMonitor: '',
        isStandard: true, // 标准元素 true；非标准元素 false
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: [
      {
        elementName: '标题',
        elementKey: 'title',
        length: 20,
        isStandard: true,
        nameValid: true,
        keyValid: true
      },
      {
        elementName: '行动号召文案（如：立即下载、免费体验等）',
        elementKey: 'ctaText',
        length: 4,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    videoElements: [
      {
        elementName: '视频链接',
        elementKey: 'videourl',
        length: 1000,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ]
  },
  开屏: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '9:16',
        width: 720,
        height: 1280,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      },
      {
        elementName: '主图片1',
        elementKey: 'mainimage1',
        ratio: '1:2',
        width: 480,
        height: 960,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: []
  },
  插屏: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '1:1',
        width: 640,
        height: 640,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: []
  },
  横幅: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '32:5',
        width: 640,
        height: 100,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: []
  },
  焦点图: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '16:9',
        width: 1280,
        height: 720,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: []
  },
  激励视频: {
    imageElements: [
      {
        elementName: '主图片',
        elementKey: 'mainimage',
        ratio: '1:1',
        width: 640,
        height: 640,
        sizeMonitor: '',
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    textElements: [
      {
        elementName: '标题',
        elementKey: 'title',
        length: 30,
        isStandard: true,
        nameValid: true,
        keyValid: true
      },
      {
        elementName: '行动号召文案（如：立即下载、免费体验等）',
        elementKey: 'ctaText',
        length: 4,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ],
    videoElements: [
      {
        elementName: '视频链接',
        elementKey: 'videourl',
        length: 1000,
        isStandard: true,
        nameValid: true,
        keyValid: true
      }
    ]
  },
  自定义: {
    imageElements: [],
    textElements: [],
    videoElements: [],
    nameValid: true,
    keyValid: true
  }
};

/**
 * 文字、图片、视频元素默认的可添加元素项
 */
const defaultElemsItems = {
  小图: {
    imageElemsList: ['主图片'],
    textElemsList: ['标题']
  },
  大图: {
    imageElemsList: ['主图片'],
    textElemsList: ['标题']
  },
  组图: {
    imageElemsList: ['主图片1', '主图片2', '主图片3'],
    textElemsList: ['标题']
  },
  视频: {
    imageElemsList: ['封面配图'],
    textElemsList: ['标题', '行动号召文案（如：立即下载、免费体验等）'],
    videoElemsList: ['视频链接']
  },
  开屏: {
    imageElemsList: ['主图片', '主图片1']
  },
  插屏: {
    imageElemsList: ['主图片']
  },
  横幅: {
    imageElemsList: ['主图片']
  },
  焦点图: {
    imageElemsList: ['主图片']
  },
  激励视频: {
    imageElemsList: ['主图片'],
    textElemsList: ['标题', '行动号召文案（如：立即下载、免费体验等）'],
    videoElemsList: ['视频链接']
  }
};

/**
 * 添加样式信息
 */
const restElemsItems = (defaultElemsItems, elemsMapKey, elemType) => {
  const newElemsItems = [..._.keys(elemsMapKey)];
  defaultElemsItems &&
    defaultElemsItems[elemType] &&
    defaultElemsItems[elemType].forEach(t => {
      newElemsItems.findIndex(s => s === t) > -1 &&
        newElemsItems.splice(newElemsItems.findIndex(s => s === t), 1);
    });
  return newElemsItems;
};

/**
 * 获取默认的样式信息
 * @param {Array} elemsInfo 
 * @param {Object} defaultElemsItems 
 */
const defaultStyleInfo = (elemsInfo, defaultElemsItems) => {
  const newStyleInfo = {
    styleStandardTemplateId: 1, // 添加默认的样式类型
    // styleType: '', // 样式类型，根据广告位类型不同而不同，比如开屏样式、小图样式等
    styleAuditStatus: AdPosAuditStatus[1].name, // 审核状态
    schemaStandardTemplateName: '小图', // 样式名称
    styleNameValid: true,
    styleNameRepeat: false,
    styleType: 0, // 推广表标的类型
    minSupportVersion: '0.0.0', // 可兼容的最低/高版本号或App当前版本号
    versionValid: true // 版本号是否合法
  };
  newStyleInfo.imageElemsList = restElemsItems(
    defaultElemsItems,
    imageElemsMapKey,
    'imageElemsList',
  );
  newStyleInfo.textElemsList = restElemsItems(
    defaultElemsItems,
    textElemsMapKey,
    'textElemsList',
  );
  newStyleInfo.videoElemsList = restElemsItems(
    defaultElemsItems,
    videoElemsMapKey,
    'videoElemsList',
  );
  _.keys(elemsInfo).forEach(t => {
    newStyleInfo[t] = elemsInfo[t];
  });
  return newStyleInfo;
};

/**
 * 获取自定义样式的默认元素
 * @param {string} elemType
 */
const getCustomDefaultElem = elemType => {
  const resElem = {
    elementType: 'custom',
    elementId: null,
    elementKey: 'custom',
    elementName: '自定义',
    isStandard: false,
    keyValid: true,
    nameValid: true,
    ratio: '3:2'
  };
  switch(elemType) {
    case 'image': {
      resElem.attr = {
        width: '300',
        height: '200',
        sizeMonitor: ''
      };
      resElem.width = '300';
      resElem.height = '200';
      resElem.sizeMonitor = '';
      break;
    }
    case 'text': {
      resElem.length = 10;
      break;
    }
    default:
      break;
  }
  return resElem;
};

const AppAndAdposTabDataColumns = [
  'reqAdNum', 'resAdNum', 'imprRate',
  'imprNum', 'fillRate', 'estimateProfit',
  'ecpm', 'cpc', 'clickRate', 'clickNum'
];

// Data Grid元素类型Map
const elemTypeMap2State = {
  0: 'imageElements',
  1: 'textElements',
  2: 'videoElements'
};

// Data Grid 下拉列表类型
const elemTypeMap2List = {
  0: 'imageElemsList',
  1: 'textElemsList',
  2: 'videoElemsList'
};

const elemTypeMap2SelectList = {
  0: imageElemsListArray,
  1: textElemsListArray,
  2: videoElemsListArray
};

// ====================================== 应用管理 -- END ===========================================//
// ====================================== 数据报表 -- START =========================================//
const DataReportTabs = {
  账户报表: 'account',
  应用: 'apps',
  广告位: 'slots',
  样式: 'schemas'
};

// 数据报表
const DataReportPath2Title = {
  'account': '账户报表',
  'apps': '应用',
  'slots': '广告位',
  'schemas': '样式'
};

const DataReportExcelName = {
  'account': '账户报表',
  'apps': '应用报表',
  'slots': '广告位报表',
  'schemas': '样式报表'
};

const DataReportApiMap = {
  'account': 'getDeveloperReportData',
  'apps': 'getDeveloperAppReportData',
  'slots': 'getDeveloperSlotReportData',
  'schemas': 'getDeveloperSchemaReportData'
};

const DownloadDataReportApiMap = {
  'account': 'downloadDeveloperReportData',
  'apps': 'downloadDeveloperAppReportData',
  'slots': 'downloadDeveloperSlotReportData',
  'schemas': 'downloadDeveloperSchemaReportData'
};
// ====================================== 数据报表 -- END ===========================================//
// ====================================== 账户管理 -- START =========================================//
// 账户管理tabs
const accountManagementTabs = {
  accountInfo: 'accountInfo',
  systemInfo: 'systemInfo',
  deviceInfo: 'deviceInfo'
};

// 路由标题
const Path2Title = {
  'accountInfo': '账户信息',
  'systemInfo': '消息中心',
  'deviceInfo': '自测信息管理'
};

// 账户类型 - 前端
const AccountTypeForFE = {
  0: '个人',
  1: '公司'
};

// 账户类型 - 后端
const AccountTypeForBE = {
  个人: 0,
  公司: 1
};

// 证件类型 - 前端
const CidTypeForFE = {
  0: '身份证',
  1: '护照',
  2: '军官证'
};
// ====================================== 账户管理 -- END ==========================================//
// ====================================== 帮助中心 -- START ========================================//
const HelpCenterSdkType = {
  IOS: 'ios',
  Android: 'android'
};
// ====================================== 帮助中心 -- END ==========================================//
// ====================================== 账户报表 -- START ========================================//
const DataReportAggregateType = {
  汇总: 'all',
  按天: 'day',
  按小时: 'hour'
};

const LoadMoreStatusMap = {
  initial: 'loading',
  loading: 'loading',
  load_success: 'loaded',
  load_fail: 'loaded',
  没有更多: 'noMore'
};

const DataReportFilterMap = {
  全部: 'all',
  自定义: 'custom'
};
// ====================================== 账户报表 -- END ==========================================//
// ====================================== 其他部分 -- START =======================================//
/* eslint-disable  */
const PostBodyUrl = [
  /\/slots$/, // 新建广告位
  /\/slots\/([0-9]|[a-z])+$/, // 编辑广告位
  /\/slots\/([0-9]|[a-z])+\/to-audit$/, //提交审核
  /\/images$/,
  /\/developers$/, // 开发者注册信息
  /\/mediation-sdk-slots\/([0-9a-z])+\/platform-priorities$/, // 新建平台优先级配置
  /\/mediation-sdk-slots\/([0-9a-z])+\/platform-priorities\/([0-9a-z])+$/,// 编辑平台优先级配置
  /\/mediation-sdk-slots\/([0-9a-z])+\/priority-settings/,// 新建优先级配置
  /\/mediation-sdk-slots\/([0-9a-z])+\/priority-settings\/([0-9])+$/,// 编辑优先级配置
];

const SpecialDealRouteArr = [
  /\/adSlot$/, // 广告位列表
  /\/([0-9])+\/adSlot$/, // 应用广告位列表
]


// ====================================== 其他部分 --END ==========================================//
// ====================================== 聚合SDK --START ==========================================//

//聚合SDKtabs
const aggregateSDKTabs = {
  adManagement: 'adManagement',
  description: 'description',
  newslot: 'newslot',
  newedit: 'newedit'
}

//路由标题
const PathToTitle = {
  adManagement: '广告位管理',
  description: '文档说明'
};

const isNull = arr => arr.map(item => 
  item.placement_id === '' || item.priority === undefined || item.timeout === undefined ? true : false);

const dataSourceMap = (originSource, typeObj1, typeObj2) => 
  originSource.map(item => Object.assign({}, item, typeObj1, typeObj2));

const dataSourceIndex = (originSource, index, typeObj1, typeObj2, typeObj3) => 
  originSource.map((item, _index) => 
    index === _index ?
      Object.assign({}, item, typeObj1, typeObj2, typeObj3)
      : item)

const changeRowEdit = originSource => originSource.map(item => item.newAdd ? item : Object.assign({}, item, {configs:
  item.configs.map(_item => item.newAdd === true ? 
    Object.assign({}, _item, {isRowEdit: true}) : 
    Object.assign({}, _item, {isRowEdit: false}))}, {editStatus: false}))

const getListIds = originSource => 
  originSource.map(item => item.id)

const priorityList = {
  settingName: '',
  osVersionSettingMode: 0,
  osVersionIds: '',
  appVersionSettingMode: 0,
  appVersionIds: '',
  deviceType: 0,
  channelNoSettingMode: 0,
  channelNoIds: '',
  countrySettingMode: 0,
  countryIds: '',
  sysLanguageSettingMode: 0,
  sysLanguageIds: '',
  slotEnabled: 1,
  startTime: '',
  endTime: '3000-01-01 00:00:00',
  platformPriorityId: 0
};

const disabledValue = {
  settingName: true,
  osVersionSettingMode: true,
  osVersionIds: true,
  appVersionSettingMode: true,
  appVersionIds: true,
  channelNoSettingMode: true,
  channelNoIds: true,
  countrySettingMode: true,
  countryIds: true,
  sysLanguageSettingMode: true,
  sysLanguageIds: true,
  platformPriorityId: false
};

const listType = {
  osVersionSettingMode: 'osVersionSettingMode',
  appVersionSettingMode: 'appVersionSettingMode',
  channelNoSettingMode: 'channelNoSettingMode',
  countrySettingMode: 'countrySettingMode',
  sysLanguageSettingMode: 'sysLanguageSettingMode',
  osVersionIds: 'osVersionIds',
  appVersionIds: 'appVersionIds',
  channelNoIds: 'channelNoIds',
  countryIds: 'countryIds',
  sysLanguageIds: 'sysLanguageIds'
}

const modeValue = {
  osVersionSettingMode: 'osVersionIds',
  appVersionSettingMode: 'appVersionIds',
  channelNoSettingMode: 'channelNoIds',
  countrySettingMode: 'countryIds',
  sysLanguageSettingMode: 'sysLanguageIds'
}

const reverseModeValue = {
  osVersionIds: 'osVersionSettingMode',
  appVersionIds: 'appVersionSettingMode',
  channelNoIds: 'channelNoSettingMode',
  countryIds: 'countrySettingMode',
  sysLanguageIds: 'sysLanguageSettingMode'
}

const optionTypeStyle = {
  1: 'osVersionSettingMode',
  2: 'appVersionSettingMode',
  3: 'channelNoSettingMode'
}

const optionTypeValue = {
  1: 'osVersionIds',
  2: 'appVersionIds',
  3: 'channelNoIds'
}

// 取对应字段
const getNameByIds = (selectedIds, originArr) => {
  let resList = [];
  if (typeof selectedIds === 'string') {
    selectedIds.split(',').map(item => {
      originArr.map(_item => 
      _item.id === Number(item) ?
          resList.push({id: Number(item), name: _item.name}) : ''
      )
    })
  } else if (selectedIds instanceof Array) {
    selectedIds.map(item => {
      originArr.map(_item => 
      _item.id === Number(item) ?
          resList.push({id: Number(item), name: _item.name}) : ''
      )
    })
  }
  return resList;
}

// 搜索框
const getIdByKeyword = (name, countryList) => {
  let resList = [];
  countryList.map(item => {
    if(item.name.indexOf(name) !== -1) {
      resList.push(item);  
    }
  })
  return resList;
}

// 获取系统日期与时间
const dateAndTime = () => {
  let date = new Date();
  const Y = date.getFullYear() + '-';
  const M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
  const D = date.getDate() + ' ';
  const h = date.getHours() + ':';
  const m = date.getMinutes() + ':';
  const s = date.getSeconds(); 
  return (Y + M + D + h + m + s);
}

const checkValue = priorityList => {
  let newPriorityList = {}
  for(let key in priorityList){
    priorityList[key] === 0 ? newPriorityList[key] = `${priorityList[key]}`
     : 
    priorityList[key] instanceof Array ? newPriorityList[key] = priorityList[key].join()
     : newPriorityList[key] = priorityList[key]
  }
  return newPriorityList 
}

const checkPlatformPriorityId = (priorityList, detailsInfo) => 
    detailsInfo.map(item => item.id).includes(priorityList.platformPriorityId) ? 
      priorityList : Object.assign({}, priorityList, {platformPriorityId: 0})

const modalTitle = {
  1: '系统版本',
  2: 'APP版本',
  3: '渠道号'
}

// ====================================== 聚合SDK --END ==========================================//
export {
  AppAdposListMapForFE,
  AppAdposNewMapForBE,
  OperationStatus,
  AppTabTypes,
  AppTabItems,
  AppAdposStatus,
  AppOsTypes,
  TrackMultipleOperationItems,
  AdPosAuditStatus,
  AdPosObject,
  PageSizeOptions,
  AppEntitySwitchStatusMapForFE,
  NewAppSettingItems,
  NewAdPosSettingItems,
  NewSelfTestSettingItems,
  NewToAuditSettingItems,
  AppOsTypeZH,
  saveButtonText,
  flowStyleItems,
  objectTypeItems,
  imageElemsMapKey,
  textElemsMapKey,
  videoElemsMapKey,
  styleElemName,
  pictureElemRatio,
  elemsWordNum,
  defaultElemsInfo,
  defaultStyleInfo,
  defaultElemsItems,
  AppAdposNewMapForFE,
  restElemsItems,
  DateRangeItems,
  Path2Title,
  AppAndAdposTabDataColumns,
  AppAdInfoMapForBE,
  PostBodyUrl,
  AdPosTypeForFE,
  AdPosTypeForBE,
  SlotStyleBE2FE,
  AppAdposStyleNewMapForFE,
  AppAdInfoMapForFE,
  getCustomDefaultElem,
  SlotStyleFE2BE,
  elemTypeMap2List,
  elemTypeMap2SelectList,
  elemTypeMap2State,
  accountManagementTabs,
  SpecialDealRouteArr,
  AccountTypeForFE,
  AccountTypeForBE,
  CidTypeForFE,
  HelpCenterSdkType,
  DataReportPath2Title,
  DataReportTabs,
  DataReportAggregateType,
  DataReportExcelName,
  NewAppClassify,
  SlotAndStyleStatusText,
  LoadMoreStatusMap,
  DataReportFilterMap,
  DataReportApiMap,
  DownloadDataReportApiMap,
  AppOs2Label,
  aggregateSDKTabs,
  PathToTitle,
  isNull,
  dataSourceMap,
  dataSourceIndex,
  changeRowEdit,
  priorityList,
  listType,
  getListIds,
  originIds,
  getNameByIds,
  dateAndTime,
  checkValue,
  getIdByKeyword,
  checkPlatformPriorityId,
  modalTitle,
  modeValue,
  disabledValue,
  checkDisabled,
  reverseModeValue,
  optionTypeStyle,
  optionTypeValue,
  systemFuncsKey,
  systemWhiteFuncs
};
