import {
  GET_ADSLOT_LIST,
  GET_ADSLOT_LIST_SUCCESS,
  GET_ADSLOT_LIST_FAIL,
  GET_LANGUAGE_LIST,
  GET_LANGUAGE_LIST_SUCCESS,
  GET_LANGUAGE_LIST_FAIL,
  GET_COUNTRY_LIST,
  GET_COUNTRY_LIST_SUCCESS,
  GET_COUNTRY_LIST_FAIL,
  DELETE_SLOT_LIST,
  DELETE_SLOT_LIST_SUCCESS,
  DELETE_SLOT_LIST_FAIL,
  ENTER_ADD_SLOT_LIST,
  ADD_SLOT_LIST,
  ADD_SLOT_LIST_SUCCESS,
  ADD_SLOT_LIST_FAIL,
  ENTER_EDIT_SLOT_NAME,
  EDIT_SLOT_NAME,
  EDIT_SLOT_NAME_SUCCESS,
  EDIT_SLOT_NAME_FAIL,
  GET_ADVERTISING_LIST,
  GET_ADVERTISING_LIST_SUCCESS,
  GET_ADVERTISING_LIST_FAIL,
  DELETE_ADVERTISING_LIST,
  DELETE_ADVERTISING_LIST_SUCCESS,
  DELETE_ADVERTISING_LIST_FAIL,
  UP_SET_PRIORITY,
  UP_SET_PRIORITY_SUCCESS,
  UP_SET_PRIORITY_FAIL,
  ENTER_CREATE_PRIORITY,
  GET_PRIORITY_LIST,
  GET_PRIORITY_LIST_SUCCESS,
  GET_PRIORITY_LIST_FAIL,
  GET_PLATFORM_LIST,
  GET_PLATFORM_LIST_SUCCESS,
  GET_PLATFORM_LIST_FAIL,
  PLATFORM_ADDING_NOW,
  PLATFORM_VALUE_CHANGE,
  PLATFORM_DELETE,
  ADD_PLATFORM_PRIORITY,
  ADD_PLATFORM_PRIORITY_SUCCESS,
  ADD_PLATFORM_PRIORITY_FAIL,
  EDIT_PLATFORM_PRIORITY,
  EDIT_PLATFORM_PRIORITY_FAIL,
  EDIT_PLATFORM_PRIORITY_SUCCESS,
  DELETE_PLATFORM_PRIORITY,
  DELETE_PLATFORM_PRIORITY_SUCCESS,
  DELETE_PLATFORM_PRIORITY_FAIL,
  GET_DETAILS_INFO,
  GET_DETAILS_INFO_SUCCESS,
  GET_DETAILS_INFO_FAIL,
  PLATFORM_EDITING_NOW,
  GET_OPTION_LIST,
  GET_OPTION_LIST_SUCCESS,
  GET_OPTION_LIST_FAIL,
  CHANGE_RADIO_VALUE,
  CHANGE_KEYWORD,
  EMIT_EDIT_MODAL,
  DELETE_OR_ADD,
  CHANGE_EDITMODAL_VALUE,
  CHANGE_EDITMODAL_VALUE_SUCCESS,
  CHANGE_EDITMODAL_VALUE_FAIL,
  EDIT_PRIORITY_CONFIG,
  EDIT_PRIORITY_CONFIG_SUCCESS,
  EDIT_PRIORITY_CONFIG_FAIL,
  ADD_PRIORITY_CONFIG,
  ADD_PRIORITY_CONFIG_SUCCESS,
  ADD_PRIORITY_CONFIG_FAIL,
  CHANGE_SELECTED_LIST,
  PLATFORM_ADD_ROW,
  PLATFORM_DELETE_ROW,
  PLATFORM_ROW_SAVE,
  PLATFORM_ROW_EDIT
} from '../../constants/ActionTypes';
import {
  checkValue, 
  listType
} from '../../constants/MenuTypes';

// 获取广告位列表
export const getAdSlotList = () => dispatch => {
  const query = {
    pageNo: 1,
    pageCapacity: 20
  };
  return dispatch({
    types: [
      GET_ADSLOT_LIST,
      GET_ADSLOT_LIST_SUCCESS,
      GET_ADSLOT_LIST_FAIL
    ],
    promise: http => http.get('/api/aggregateSDK/getAdSlotList', { query })
  });
};

// 获取语言列表
export const getLanguageList = () => dispatch => {
  return dispatch({
    types: [
      GET_LANGUAGE_LIST,
      GET_LANGUAGE_LIST_SUCCESS,
      GET_LANGUAGE_LIST_FAIL
    ],
    promise: http => http.get('/api/aggregateSDK/getLanguageList')
  });
};

// 获取国家列表
export const getCountryList = () => dispatch => {
  return dispatch({
    types: [
      GET_COUNTRY_LIST,
      GET_COUNTRY_LIST_SUCCESS,
      GET_COUNTRY_LIST_FAIL
    ],
    promise: http => http.get('/api/aggregateSDK/getCountryList')
  });
};

// 根据mediationSdkSlotUid删除广告位列表
export const deleteSlotList = (mediationSdkSlotUid, index) => dispatch => {
  const data = { mediationSdkSlotUid };
  return dispatch({
    types: [
      DELETE_SLOT_LIST,
      DELETE_SLOT_LIST_SUCCESS,
      DELETE_SLOT_LIST_FAIL
    ],
    infoObj: index,
    promise: http => http.delete(`/api/aggregateSDK/deleteSlotList/${mediationSdkSlotUid}`, { data })
  });
};

// 根据mediationSdkSlotUid,settingId删除优先级列表
export const deleteAdvertisingList = (mediationSdkSlotUid, settingId) => dispatch => {
  const data = { 
    mediationSdkSlotUid,
    settingId 
  };
  return dispatch({
    types: [
      DELETE_ADVERTISING_LIST,
      DELETE_ADVERTISING_LIST_SUCCESS,
      DELETE_ADVERTISING_LIST_FAIL
    ],
    promise: http => http.delete(`/api/aggregateSDK/deleteAdvertisingList/${mediationSdkSlotUid}/${settingId}`, { data })
  });
};

// 进入新增广告位页面
export const enterAdd = () => ({
  type: ENTER_ADD_SLOT_LIST
});

// 新增广告位
export const addSlotList = mediationSdkSlotName => dispatch => {
  const data = { mediationSdkSlotName };
  return dispatch({
    types: [
      ADD_SLOT_LIST,
      ADD_SLOT_LIST_SUCCESS,
      ADD_SLOT_LIST_FAIL
    ],
    promise: http => http.post('/api/aggregateSDK/addSlotList', { data })
  });
};

// 进入编辑广告位页面
export const enterEdit = () => ({
  type: ENTER_EDIT_SLOT_NAME
});

// 编辑广告位名称
export const editSlotName = (mediationSdkSlotName, mediationSdkSlotUid) => dispatch => {
  const data = { 
    mediationSdkSlotName,
    mediationSdkSlotUid
  };
  return dispatch({
    types: [
      EDIT_SLOT_NAME,
      EDIT_SLOT_NAME_SUCCESS,
      EDIT_SLOT_NAME_FAIL
    ],
    promise: http => http.post(`/api/aggregateSDK/editSlotName/${mediationSdkSlotUid}`, { data })
  });
};

// 根据mediationSdkSlotUid获取优先级列表
export const getAdvertisingList = mediationSdkSlotUid => dispatch => {
  return dispatch({
    types: [
      GET_ADVERTISING_LIST,
      GET_ADVERTISING_LIST_SUCCESS,
      GET_ADVERTISING_LIST_FAIL
    ],
    promise: http => http.get(`/api/aggregateSDK/getAdvertisingList/${mediationSdkSlotUid}`)
  });
};

// 优先级移动
export const upSetPriority = (upSettingId, upPriority, downSettingId, downPriority) => dispatch => {
  const query = {
    upSettingId, 
    upPriority, 
    downSettingId, 
    downPriority
  };
  return dispatch({
    types: [
      UP_SET_PRIORITY,
      UP_SET_PRIORITY_SUCCESS,
      UP_SET_PRIORITY_FAIL
    ],
    promise: http => http.put('/api/aggregateSDK/upSetPriority', { query })
  });
};

// 获取优先级配置
export const getPriorityList = (mediationSdkSlotUid, settingId) => dispatch => {
  const data = { 
    mediationSdkSlotUid,
    settingId
  };
  return dispatch({
    types: [
      GET_PRIORITY_LIST,
      GET_PRIORITY_LIST_SUCCESS,
      GET_PRIORITY_LIST_FAIL
    ],
    promise: http => http.get(`/api/aggregateSDK/getPriorityList/${mediationSdkSlotUid}/${settingId}`, { data })
  });
};

// 进入优先级配置新增页面
export const enterCreatePriority = (priorityList, priorityName, mediationSdkSlotUid) => ({
  type: ENTER_CREATE_PRIORITY,
  payload: {
    priorityList,
    priorityName,
    mediationSdkSlotUid
  }
});

// 获取平台优先级配置列表
export const getPlatformList = mediationSdkSlotUid => dispatch => {
  const data = {
    mediationSdkSlotUid
  };
  return dispatch({
    types: [
      GET_PLATFORM_LIST,
      GET_PLATFORM_LIST_SUCCESS,
      GET_PLATFORM_LIST_FAIL
    ],
    promise: http => http.get(`/api/aggregateSDK/getPlatformList/${mediationSdkSlotUid}`, { data })
  });
};

// 新建平台优先级配置
export const addPlatformPriority = ( 
  mediationSdkSlotUid, 
  platformPriorityName, 
  platformInfo, 
  editStatus,
  newAdd
) => dispatch => {
  const data = {
    mediationSdkSlotUid,
    platformPriorityName,
    platformInfo: JSON.stringify(platformInfo)
  };
  return dispatch({
    types: [
      ADD_PLATFORM_PRIORITY,
      ADD_PLATFORM_PRIORITY_SUCCESS,
      ADD_PLATFORM_PRIORITY_FAIL
    ],
    infoObj: {
      mediationSdkSlotUid,
      editStatus,
      newAdd
    },
    promise: http => http.post(`/api/aggregateSDK/addPlatformPriority/${mediationSdkSlotUid}`, { data })
  });
};

// 平台优先级配置 正在编辑
export const platformEditing = (editStatus, index, dataSource) => ({
  type: PLATFORM_EDITING_NOW,
  payload: {
    editStatus,
    index,
    dataSource
  }
});

// 平台优先级编辑中
export const platformValueChange = (dataSource, index) => ({
  type: PLATFORM_VALUE_CHANGE,
  payload: {
    dataSource,
    index
  }
});

// 平台优先级新增行
export const platformAddRow = (dataSource, index) => ({
  type: PLATFORM_ADD_ROW,
  payload: {
    dataSource,
    index
  }
});

// 平台优先级删除行
export const platformDeleteRow = (dataSource, index) => ({
  type: PLATFORM_DELETE_ROW,
  payload: {
    dataSource,
    index
  }
});

// 平台优先级保存行
export const platformRowSave = (dataSource, index) => ({
  type: PLATFORM_ROW_SAVE,
  payload: {
    dataSource,
    index
  }
});

// 平台优先级编辑行
export const platformRowEdit = (dataSource, index) => ({
  type: PLATFORM_ROW_EDIT,
  payload: {
    dataSource,
    index
  }
});

// 平台优先级配置 正在新增
export const platformAdding = (editStatus, newAdd) => ({
  type: PLATFORM_ADDING_NOW,
  payload: {
    editStatus,
    newAdd
  }
});

// 编辑平台优先级配置
export const editPlatformPriority = (
  mediationSdkSlotUid, 
  platformPriorityId, 
  platformPriorityName, 
  platformInfo, 
  editStatus,
  index
) => 
  dispatch => {
    const data = {
      mediationSdkSlotUid,
      platformPriorityId,
      platformPriorityName,
      platformInfo: JSON.stringify(platformInfo)
    };
    return dispatch({
      types: [
        EDIT_PLATFORM_PRIORITY,
        EDIT_PLATFORM_PRIORITY_SUCCESS,
        EDIT_PLATFORM_PRIORITY_FAIL
      ],
      infoObj: {
        editStatus,
        index,
        platformInfo
      },
      promise: http => 
        http.post(`/api/aggregateSDK/editPlatformPriority/${mediationSdkSlotUid}/${platformPriorityId}`, { data })
    });
  };

// 删除未保存的平台优先级配置
export const platformDelete = (newAdd, index) => ({
  type: PLATFORM_DELETE,
  payload: {
    newAdd,
    index
  }
});

// 删除平台优先级配置
export const deletePlatformPriority = (mediationSdkSlotUid, platformPriorityId, index) => dispatch => {
  const data = {
    mediationSdkSlotUid,
    platformPriorityId
  };
  return dispatch({
    types: [
      DELETE_PLATFORM_PRIORITY,
      DELETE_PLATFORM_PRIORITY_SUCCESS,
      DELETE_PLATFORM_PRIORITY_FAIL
    ],
    infoObj: index,
    promise: http => 
      http.delete(`/api/aggregateSDK/deletePlatformPriority/${mediationSdkSlotUid}/${platformPriorityId}`, { data })
  });
};

// 获取平台优先级下拉列表
export const getDetailsInfo = mediationSdkSlotUid => dispatch => {
  const data = {
    mediationSdkSlotUid
  };
  return dispatch({
    types: [
      GET_DETAILS_INFO,
      GET_DETAILS_INFO_SUCCESS,
      GET_DETAILS_INFO_FAIL
    ],
    promise: http => http.get(`/api/aggregateSDK/getDetailsInfo/${mediationSdkSlotUid}`, { data })
  });
};

// 系统版本，APP版本，渠道号等可选项列表
export const getOptionList = optionType => dispatch => {
  const query = {
    optionType
  };
  return dispatch({
    types: [
      GET_OPTION_LIST,
      GET_OPTION_LIST_SUCCESS,
      GET_OPTION_LIST_FAIL
    ],
    infoObj: optionType,
    promise: http => http.get('/api/aggregateSDK/getOptionList', { query })
  });
};

// 单选框改变
export const radioChange = (option, changeInfo) => ({
  type: CHANGE_RADIO_VALUE,
  payload: {
    option,
    changeInfo,
    keys: listType[Object.keys(option)[0]]
  }
});

// 搜索框
export const onCascadingKeywordChange = keyword => ({
  type: CHANGE_KEYWORD,
  payload: keyword
});

// 触发编辑模态框
export const emitEditModal = optionType => ({
  type: EMIT_EDIT_MODAL,
  payload: optionType
});

// 编辑可选项
export const editOption = (toDeleteIds, toAddValues) => ({
  type: DELETE_OR_ADD,
  payload: {
    toDeleteIds,
    toAddValues
  }
});

// 选中列表改变
export const changeSelectedList = (option, selectedMenuList, text, changeInfo) => ({
  type: CHANGE_SELECTED_LIST,
  payload: {
    option,
    selectedMenuList,
    text,
    changeInfo
  }
});

// 增加或删除可选项列表
export const changeEditModalValue = (optionType, toDeleteIds, toAddValues, changeInfo) => dispatch => {
  const query = {
    optionType,
    toDeleteIds,
    toAddValues
  };
  return dispatch({
    types: [
      CHANGE_EDITMODAL_VALUE,
      CHANGE_EDITMODAL_VALUE_SUCCESS,
      CHANGE_EDITMODAL_VALUE_FAIL
    ],
    infoObj: {
      optionType,
      changeInfo
    },
    promise: http => http.post('/api/aggregateSDK/changeEditModalValue', { query })
  });
};

// 编辑优先级配置
export const editPriorityConfig = prioritySettingData => dispatch => {
  const newPrioritySettingData = checkValue(prioritySettingData);
  const {
    mediationSdkSlotUid,
    settingId
  } = prioritySettingData;
  const data = {
    mediationSdkSlotUid: prioritySettingData.mediationSdkSlotUid,
    settingId: prioritySettingData.settingId,
    prioritySettingData: JSON.stringify(newPrioritySettingData)
  };
  return dispatch({
    types: [
      EDIT_PRIORITY_CONFIG,
      EDIT_PRIORITY_CONFIG_SUCCESS,
      EDIT_PRIORITY_CONFIG_FAIL
    ],
    infoObj: mediationSdkSlotUid,
    promise: http => http.post(`/api/aggregateSDK/editPriorityConfig/${mediationSdkSlotUid}/${settingId}`, { data })
  });
};

// 新建优先级配置
export const addPriorityConfig = (mediationSdkSlotUid, prioritySettingData) => dispatch => {
  const data = {
    mediationSdkSlotUid,
    prioritySettingData: JSON.stringify(checkValue(prioritySettingData))
  };
  return dispatch({
    types: [
      ADD_PRIORITY_CONFIG,
      ADD_PRIORITY_CONFIG_SUCCESS,
      ADD_PRIORITY_CONFIG_FAIL
    ],
    infoObj: mediationSdkSlotUid,
    promise: http => http.post(`/api/aggregateSDK/addPriorityConfig/${mediationSdkSlotUid}`, { data })
  });
};