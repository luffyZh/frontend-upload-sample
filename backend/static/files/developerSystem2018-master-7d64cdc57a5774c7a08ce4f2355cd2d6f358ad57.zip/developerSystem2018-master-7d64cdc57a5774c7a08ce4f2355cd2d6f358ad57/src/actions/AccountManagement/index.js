import {
  GET_SELF_TEST_DEVICE_LIST,
  GET_SELF_TEST_DEVICE_LIST_SUCCESS,
  GET_SELF_TEST_DEVICE_LIST_FAIL,
  CHANGE_SELF_TEST_DEVICE_STATUS,
  CHANGE_SELF_TEST_DEVICE_STATUS_SUCCESS,
  CHANGE_SELF_TEST_DEVICE_STATUS_FAIL,
  ADD_SELF_TEST_DEVICE,
  ADD_SELF_TEST_DEVICE_SUCCESS,
  ADD_SELF_TEST_DEVICE_FAIL,
  GET_ACCOUNT_INFO,
  GET_ACCOUNT_INFO_SUCCESS,
  GET_ACCOUNT_INFO_FAIL,
  CHANGE_USER_INFO,
  UPDATE_ACCOUNT_INFO,
  UPDATE_ACCOUNT_INFO_SUCCESS,
  UPDATE_ACCOUNT_INFO_FAIL,
  UPDATE_SELF_TEST_DEVICE_INFO,
  UPDATE_SELF_TEST_DEVICE_INFO_SUCCESS,
  UPDATE_SELF_TEST_DEVICE_INFO_FAIL,
  GET_SYSTEM_INFO,
  GET_SYSTEM_INFO_SUCCESS,
  GET_SYSTEM_INFO_FAIL,
  UPDATE_SYSTEM_INFO_STATUS,
  UPDATE_SYSTEM_INFO_STATUS_SUCCESS,
  UPDATE_SYSTEM_INFO_STATUS_FAIL,
  RESET_QUERY_CONDITION,
  QUERY_CONDITION_CHANGE,
  FETCH_UNREAD_MESSAGE,
  FETCH_UNREAD_MESSAGE_SUCCESS,
  FETCH_UNREAD_MESSAGE_FAIL
} from '../../constants/ActionTypes';

export const getSelfTestDeviceList = (type = '') => dispatch => {
  const query = {
    onlyEnabled: type
  };
  return dispatch({
    types: [
      GET_SELF_TEST_DEVICE_LIST,
      GET_SELF_TEST_DEVICE_LIST_SUCCESS,
      GET_SELF_TEST_DEVICE_LIST_FAIL
    ],
    promise: http => http.get('/api/accountManagement/getSelfTestDeviceList', { query })
  });
};

export const changeSelfTestDeviceStatus = (ids, status) => dispatch => (
  dispatch({
    types: [
      CHANGE_SELF_TEST_DEVICE_STATUS,
      CHANGE_SELF_TEST_DEVICE_STATUS_SUCCESS,
      CHANGE_SELF_TEST_DEVICE_STATUS_FAIL
    ],
    devicesObj: {
      ids,
      status
    },
    promise: http => http.get('/api/accountManagement/changeSelfTestDeviceStatus',
      { query: { ids, status: status.toString() } })
  })
);

// 增加自测设备信息
export const addSelfTestDevice = deviceObj => dispatch => {
  const data = {
    deviceId: deviceObj.deviceId,
    comment: deviceObj.comment
  };
  return dispatch({
    types: [
      ADD_SELF_TEST_DEVICE,
      ADD_SELF_TEST_DEVICE_SUCCESS,
      ADD_SELF_TEST_DEVICE_FAIL
    ],
    addDevice: data,
    promise: http => http.post('/api/accountManagement/addSelfTestDevice', { data })
  });
};

// 获取用户信息
export const getAccountInfo = () => dispatch =>
  dispatch({
    types: [
      GET_ACCOUNT_INFO,
      GET_ACCOUNT_INFO_SUCCESS,
      GET_ACCOUNT_INFO_FAIL
    ],
    promise: http => http.get('/api/accountManagement/getAccountInfo')
  });

// 更新用户state信息
export const changeUserInfo = user => ({
  type: CHANGE_USER_INFO,
  payload: user
});

// 更新用户信息到后台
export const updateAccountInfo = () => (dispatch, getState) => {
  const { user } = getState().accountManagement.accountInfo;
  const {
    name,
    email,
    phone,
    address
  } = user;
  const query = {
    name,
    email,
    phone,
    address
  };
  return dispatch({
    types: [
      UPDATE_ACCOUNT_INFO,
      UPDATE_ACCOUNT_INFO_SUCCESS,
      UPDATE_ACCOUNT_INFO_FAIL
    ],
    promise: http => http.put('/api/accountManagement/updateAccountInfo', { query })
  });
};

// 更新自测设备备注信息
export const updateDeviceInfo = (id, comment) => dispatch => {
  const query = { id, comment };
  return dispatch({
    types: [
      UPDATE_SELF_TEST_DEVICE_INFO,
      UPDATE_SELF_TEST_DEVICE_INFO_SUCCESS,
      UPDATE_SELF_TEST_DEVICE_INFO_FAIL
    ],
    promise: http => http.put('/api/accountManagement/updateDeviceInfo', { query })
  });
};

// 获取消息列表
export const getSystemInfo = () => (dispatch, getState) => {
  const { queryCondition } = getState().accountManagement.systemInfo;
  const query = {
    pageNo: queryCondition.pageNo,
    pageCapacity: queryCondition.pageSize
  };
  return dispatch({
    types: [
      GET_SYSTEM_INFO,
      GET_SYSTEM_INFO_SUCCESS,
      GET_SYSTEM_INFO_FAIL
    ],
    promise: http => http.get('/api/accountManagement/getSystemInfo', { query })
  });
};

// 更新消息中心信息状态
export const updateSystemInfo = (id, status) => dispatch => {
  const query = { id, status };
  return dispatch({
    types: [
      UPDATE_SYSTEM_INFO_STATUS,
      UPDATE_SYSTEM_INFO_STATUS_SUCCESS,
      UPDATE_SYSTEM_INFO_STATUS_FAIL
    ],
    promise: http => http.put('/api/accountManagement/updateSystemInfo', { query })
  });
};

// 页码和条数改变
export const queryConditionChange = payload => ({
  type: QUERY_CONDITION_CHANGE,
  payload
});

// 恢复列表到初始状态
export const resetQueryCondition = () => ({
  type: RESET_QUERY_CONDITION
});

// 获取未读消息
export const fetchUnreadMessage = () => dispatch =>
  dispatch({
    types: [
      FETCH_UNREAD_MESSAGE,
      FETCH_UNREAD_MESSAGE_SUCCESS,
      FETCH_UNREAD_MESSAGE_FAIL
    ],
    promise: http => http.get('/api/accountManagement/getUnreadMessage')
  });