import {
  RESET_QUERY_CONDITION,
  QUERY_CONDITION_CHANGE,
  GET_DEVELOPER_REPORT_DATA,
  GET_DEVELOPER_REPORT_DATA_SUCCESS,
  GET_DEVELOPER_REPORT_DATA_FAIL,
  DATA_REPORT_TAB_CHANGE,
  DOWNLOAD_DATA_REPORT_DATA,
  GET_DATAREPORT_CASCADING_LIST,
  GET_DATAREPORT_CASCADING_LIST_FAIL,
  GET_DATAREPORT_CASCADING_LIST_SUCCESS,
  CASCADING_QUERY_CONDITION_CHANGE,
  RESET_CASCADING_QUERY_CONDITION,
  GET_SELECTED_MENU_LIST,
  GET_SELECTED_MENU_LIST_FAIL,
  GET_SELECTED_MENU_LIST_SUCCESS,
  SELECTED_MENU_LIST_CHANGE
} from '../../constants/ActionTypes';

// 账户报表tab变化
export const dataReportTabChange = (payload, targetId) => ({
  type: DATA_REPORT_TAB_CHANGE,
  payload,
  targetId
});

// 页码和条数改变
export const queryConditionChange = (tabType, payload) => ({
  tabType,
  type: QUERY_CONDITION_CHANGE,
  payload
});

// 恢复列表到初始状态
export const resetQueryCondition = payload => ({
  type: RESET_QUERY_CONDITION,
  payload
});

// 获取用户账户报表
// eslint-disable-next-line
export const getDeveloperReportData = tabType =>
  (dispatch, getState) => {
    const {
      pageNo,
      pageSize,
      dateRange: { startDate, endDate },
      aggregate,
      id,
      ids
    } = getState().dataReport.queryCondition;
    const query = {
      tabType,
      pageNo,
      pageSize,
      aggregate,
      startDate: startDate === '' ? '' : startDate.format('YYYY-MM-DD'),
      endDate: endDate === '' ? '' : endDate.format('YYYY-MM-DD'),
      ids,
      id
    };
    return dispatch({
      types: [
        GET_DEVELOPER_REPORT_DATA,
        GET_DEVELOPER_REPORT_DATA_SUCCESS,
        GET_DEVELOPER_REPORT_DATA_FAIL
      ],
      tabType,
      promise: http => http.get('/api/dataReport/getDeveloperReportData', { query })
    });
  };

// 下载数据报表数据
export const downloadReportData = payload => (dispatch, getState) => {
  const {
    dateRange: { startDate, endDate },
    aggregate,
    id,
    ids
  } = getState().dataReport.queryCondition;
  payload.startDate = startDate.format('YYYY-MM-DD');
  payload.endDate = endDate.format('YYYY-MM-DD');
  payload.aggregate = aggregate;
  payload.id = id;
  payload.ids = ids;
  return dispatch({
    type: DOWNLOAD_DATA_REPORT_DATA,
    payload
  });
};

// 获取cascading list数据
export const getDataReportCascadingMenuList = tabType => (dispatch, getState) => {
  const {
    pageNo,
    pageSize,
    keyword
  } = getState().dataReport.cascading.queryCondition;
  const query = {
    pageNo,
    pageCapacity: pageSize,
    keyword,
    tabType
  };
  return dispatch({
    types: [
      GET_DATAREPORT_CASCADING_LIST,
      GET_DATAREPORT_CASCADING_LIST_SUCCESS,
      GET_DATAREPORT_CASCADING_LIST_FAIL
    ],
    tabType,
    promise: http => http.get('/api/dataReport/getDataReportCascadingMenuList', { query })
  });
};

// 页码和条数改变
export const cascadingQueryConditionChange = payload => ({
  type: CASCADING_QUERY_CONDITION_CHANGE,
  payload
});

// 恢复列表到初始状态
export const resetCascadingQueryCondition = () => ({
  type: RESET_CASCADING_QUERY_CONDITION
});

// 初始化获取Modal已选择列表
export const getSelectedMenuList = (tabType, id) => (dispatch, getState) => {
  const {
    ids
  } = getState().dataReport.queryCondition;
  const query = {
    appIds: id
  };
  return dispatch({
    types: [
      GET_SELECTED_MENU_LIST,
      GET_SELECTED_MENU_LIST_SUCCESS,
      GET_SELECTED_MENU_LIST_FAIL
    ],
    tabType,
    slotUdid: ids && ids.trim(),
    promise: http => http.get('/api/dataReport/getSelectedMenuList', { query })
  });
};

// 动态更新selectedMenuList
export const selectedMenuListChange = (tabType, payload) => ({
  type: SELECTED_MENU_LIST_CHANGE,
  tabType,
  payload
});