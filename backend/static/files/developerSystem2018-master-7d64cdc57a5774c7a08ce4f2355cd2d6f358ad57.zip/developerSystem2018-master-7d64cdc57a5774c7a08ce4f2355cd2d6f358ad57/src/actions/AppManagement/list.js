import _ from 'lodash';
import {
  GET_APP_AND_ADPOS_LIST,
  GET_APP_AND_ADPOS_LIST_SUCCESS,
  GET_APP_AND_ADPOS_LIST_FAIL,
  GET_APP_AND_ADPOS_STATISTIC_LIST,
  GET_APP_AND_ADPOS_STATISTIC_LIST_SUCCESS,
  GET_APP_AND_ADPOS_STATISTIC_LIST_FAIL,
  QUERY_CONDITION_CHANGE,
  RESET_QUERY_CONDITION,
  ON_TAB_CHANGE,
  UPDATE_APP_STATUS,
  UPDATE_APP_STATUS_SUCCESS,
  UPDATE_APP_STATUS_FAIL,
  UPDATE_ADPOS_STATUS,
  UPDATE_ADPOS_STATUS_SUCCESS,
  UPDATE_ADPOS_STATUS_FAIL,
  UPDATE_ADPOS_STYLE_STATUS,
  UPDATE_ADPOS_STYLE_STATUS_SUCCESS,
  UPDATE_ADPOS_STYLE_STATUS_FAIL
} from '../../constants/ActionTypes';
import { AppTabTypes } from '../../constants/MenuTypes';

// 获取应用列表和广告位列表
export const getAppAndAdposList = (subType, appId) => (dispatch, getState) => {
  const {
    dateRange: {
      startDate,
      endDate
    },
    keyword,
    pageNo,
    pageSize,
    selectedOsType,
    selectedStatus,
    selectedOperateStatus,
    selectedAuditStatus,
    selectedObject
  } = getState().appManagement.list.queryConditions[subType];
  const { tabType } = getState().appManagement.list.navTab;
  const queryObj = {
    subType,
    tabType,
    startDate: startDate === '' ? '' : startDate.format('YYYY-MM-DD'),
    endDate: endDate === '' ? '' : endDate.format('YYYY-MM-DD'),
    keyword,
    pageNo,
    pageSize,
    appId
  };
  const query =
    subType === AppTabTypes.appTab
      ? _.assign(queryObj, {
        appOs: selectedOsType.value,
        appStatus: selectedStatus.value
      })
      : _.assign(queryObj, {
        operateStatus: selectedOperateStatus.value,
        auditStatus: selectedAuditStatus.value,
        object: selectedObject.value
      });
  return dispatch({
    types: [
      GET_APP_AND_ADPOS_LIST,
      GET_APP_AND_ADPOS_LIST_SUCCESS,
      GET_APP_AND_ADPOS_LIST_FAIL
    ],
    type: GET_APP_AND_ADPOS_LIST,
    subType,
    promise: http => http.get('/api/appManagement/queryAppEntityList', { query })
  });
};

// 列表状态与数据解藕，获取数据部分
export const getAppAndAdposStatisticList = (subType, idsList) => (dispatch, getState) => {
  const {
    dateRange: {
      startDate,
      endDate
    }
  } = getState().appManagement.list.queryConditions[subType];
  const query = {
    idsList,
    startDate: startDate === '' ? '' : startDate.format('YYYY-MM-DD'),
    endDate: endDate === '' ? '' : endDate.format('YYYY-MM-DD'),
    subType
  };
  return dispatch({
    types: [
      GET_APP_AND_ADPOS_STATISTIC_LIST,
      GET_APP_AND_ADPOS_STATISTIC_LIST_SUCCESS,
      GET_APP_AND_ADPOS_STATISTIC_LIST_FAIL
    ],
    type: GET_APP_AND_ADPOS_LIST,
    subType,
    promise: http => http.get('/api/appManagement/getAppAndAdposStatisticList', { query })
  });
};

// 应用管理列表页 queryCondition改变时，比如日期、页码、平台、审核状态、搜索等 目前未用到
export const appAndAdposListQueryConditionChange = (subType, payload) => ({
  type: QUERY_CONDITION_CHANGE,
  subType,
  payload
});

// 恢复列表到初始状态
export const resetQueryCondition = () => ({
  type: RESET_QUERY_CONDITION
});

// 应用管理页 导航切换，或者点击列表中应用
export const onTabChange = subType => ({
  type: ON_TAB_CHANGE,
  subType
});

// 批量修改应用状态
export const updateAppStatus = (tabType, appIdList, status) => ({
  types: [UPDATE_APP_STATUS, UPDATE_APP_STATUS_SUCCESS, UPDATE_APP_STATUS_FAIL],
  params: {
    tabType,
    idList: appIdList,
    status
  },
  promise: http =>
    http.put('/api/appManagement/updateAppStatus', {
      data: {
        appIds: appIdList,
        appStatus: status
      }
    })
});

// 批量修改广告位状态
export const updateAdPosStatus = (tabType, adPosList, status) => ({
  types: [
    UPDATE_ADPOS_STATUS,
    UPDATE_ADPOS_STATUS_SUCCESS,
    UPDATE_ADPOS_STATUS_FAIL
  ],
  params: {
    tabType,
    idList: adPosList,
    status
  },
  promise: http =>
    http.put('/api/appManagement/updateSlotStatus', {
      data: {
        slotUdids: adPosList,
        slotOpStatus: status
      }
    })
});

// 设置样式状态(开关)
export const updateAdPosStyleStatus = (
  tabType,
  adPosUdid,
  styleId,
  status,
) => ({
  types: [
    UPDATE_ADPOS_STYLE_STATUS,
    UPDATE_ADPOS_STYLE_STATUS_SUCCESS,
    UPDATE_ADPOS_STYLE_STATUS_FAIL
  ],
  params: {
    tabType,
    adPosUdid,
    styleId,
    status
  },
  promise: http =>
    http.put(`/api/appManagement/updateAdSlotStyleStatus/${adPosUdid}`, {
      data: {
        styleId,
        status
      }
    })
});
