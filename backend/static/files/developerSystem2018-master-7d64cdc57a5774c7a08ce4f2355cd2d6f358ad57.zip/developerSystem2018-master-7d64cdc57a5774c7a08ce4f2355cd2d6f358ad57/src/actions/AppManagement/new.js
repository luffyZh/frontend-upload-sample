import {
  EDITING_APP,
  EDITING_ADPOS,
  EDITING_SELF_TEST,
  EDITING_TO_AUDIT,
  APP_ITEM_CHANGE,
  RESET_APP_ITEM,
  CREATE_APP,
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  ADPOS_ADD_ELEM,
  ADD_OR_DEL_STYLE,
  ADPOS_ITEM_CHANGE,
  CREATE_AD_POS,
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  SELF_TEST_DATA_CHANGE,
  SAVE_SELF_TEST,
  TO_AUDIT_DATA_CHANGE,
  CREATE_TO_AUDIT,
  CREATE_TO_AUDIT_SUCCESS,
  CREATE_TO_AUDIT_FAIL,
  GO_TO_APP_LIST,
  SET_ADPOS_ISEDIT,
  RESET_ADPOS_ITEM,
  GET_APP_CATEGORY,
  GET_APP_CATEGORY_FAIL,
  GET_APP_CATEGORY_SUCCESS,
  GET_APP_NAME_BY_ID,
  GET_APP_NAME_BY_ID_SUCCESS,
  GET_APP_NAME_BY_ID_FAIL,
  GET_STANDARD_TEMPLATES,
  GET_STANDARD_TEMPLATES_FAIL,
  GET_STANDARD_TEMPLATES_SUCCESS,
  GET_STANDARD_ELEMENTS,
  GET_STANDARD_ELEMENTS_FAIL,
  GET_STANDARD_ELEMENTS_SUCCESS,
  GET_ADSLOT_INFO,
  GET_ADSLOT_INFO_SUCCESS,
  GET_ADSLOT_INFO_FAIL,
  GET_ADSLOT_AUDIT_INFO,
  GET_ADSLOT_AUDIT_INFO_SUCCESS,
  GET_ADSLOT_AUDIT_INFO_FAIL,
  CHANGE_SLOT_AUDIT_SOURCE,
  RESET_AUDIT_DATA,
  CHANGE_SAVE_TYPE,
  GENERATE_SELF_TEST_MATERIAL,
  GENERATE_SELF_TEST_MATERIAL_SUCCESS,
  GENERATE_SELF_TEST_MATERIAL_FAIL
} from '../../constants/ActionTypes';
import {
  isValidAppAdPosEntityName,
  generateStyleList,
  transtfromStyleElement,
  getneratePostAuditData
} from '../../core/utils';
import {
  OperationStatus
} from '../../constants/MenuTypes';

// 正在编辑应用、广告位、自测页面、提交审核页面
const editingAppManagementEntity = type => ({ type });
export const editApp = () => editingAppManagementEntity(EDITING_APP);
export const editAdPos = () => editingAppManagementEntity(EDITING_ADPOS);
export const editSelfTest = () => editingAppManagementEntity(EDITING_SELF_TEST);
export const editToAudit = () => editingAppManagementEntity(EDITING_TO_AUDIT);

// 编辑新建应用页面,表单数据改变
export const appDataChange = (sectionType, itemType, itemValue) => ({
  type: APP_ITEM_CHANGE,
  payload: {
    type: sectionType,
    itemType,
    [itemType]: itemValue
  }
});

// 重置应用元素
export const resetAppItem = () => ({
  type: RESET_APP_ITEM
});

// 重置广告位元素
export const resetAdPosItem = () => ({
  type: RESET_ADPOS_ITEM
});

// 保存新建应用信息
export const saveAppData = saveType => (dispatch, getState) => {
  const {
    status,
    newApp: { appName, osType, appType, androidOrItunes }
  } = getState().appManagement.entity.app; 

  const validStatus =
    status === OperationStatus.load_success ||
    status === OperationStatus.editing ||
    status === OperationStatus.save_fail;
  const validAppName = isValidAppAdPosEntityName(appName);

  if (!validStatus || !validAppName) return;

  const data = {
    appName: appName.trim(),
    appOs: osType,
    appCategory: appType[1],
    appUniqueIdentifier: androidOrItunes.trim()
  };

  return dispatch({
    types: [CREATE_APP, CREATE_APP_SUCCESS, CREATE_APP_FAIL],
    saveType,
    promise: http => http.post('/api/appManagement/createNewApp', { data })
  });
};

// 保存新建广告位信息
export const saveAdPosData = (saveType, isEdit) => (dispatch, getState) => {
  const {
    status,
    adPosInfo: { adPosName, adPosType, slotCallbackUrl, appId, adPosId },
    styleObj
  } = getState().appManagement.entity.adPos;
  const validStatus =
    status === OperationStatus.load_success ||
    status === OperationStatus.editing ||
    status === OperationStatus.save_fail;
  const validAdPosName = isValidAppAdPosEntityName(adPosName);
  if (!validStatus || !validAdPosName) return;
  const data = {
    appId,
    adPosName,
    adPosType,
    slotCallbackUrl,
    styleList: JSON.stringify(generateStyleList(styleObj.styleInfo))
  };
  data.slotUdid = adPosId;
  return dispatch({
    types: [CREATE_AD_POS, CREATE_AD_POS_SUCCESS, CREATE_AD_POS_FAIL],
    saveType,
    promise: http => (isEdit || data.slotUdid)
      ? http.put('/api/appManagement/editAdPos', { data })
      : http.post('/api/appManagement/createNewAdPos', { data })
  });
};

// 新增加一个元素，如图片元素、文字元素、视频元素
export const adPosAddElem = (elemType, elemValue, index) => ({
  type: ADPOS_ADD_ELEM,
  payload: {
    elemType,
    elemValue,
    index
  }
});

// 继续添加样式或者删除样式
export const addOrDelStyle = styleInfo => ({
  type: ADD_OR_DEL_STYLE,
  payload: {
    styleInfo
  }
});

// 编辑新建广告位页面,表单数据改变
export const adPosDataChange = (
  sectionType,
  itemType,
  itemValue,
  itemIndex,
) => ({
  type: ADPOS_ITEM_CHANGE,
  payload: {
    type: sectionType,
    itemType,
    [itemType]: transtfromStyleElement(itemIndex, itemType, itemValue),
    itemIndex
  }
});

// 自测页面改变
export const selfTestDataChange = (sectionType, itemType, itemValue) => ({
  type: SELF_TEST_DATA_CHANGE,
  payload: {
    type: sectionType,
    itemType,
    [itemType]: itemValue
  }
});

// 保存自测页面
export const saveSelfTestData = saveType => {
  // 保存并继续
  return {
    type: SAVE_SELF_TEST,
    saveType
  };
};

// 自测页面变化
export const toAuditDataChange = (sectionType, itemType, itemValue) => ({
  type: TO_AUDIT_DATA_CHANGE,
  payload: {
    type: sectionType,
    itemType,
    [itemType]: itemValue
  }
});

// 广告位提交审核
export const saveToAuditData = () => (dispatch, getState) => {
  const {
    status,
    uploadScreenShot: { styleInfo, adPosId },
    uploadInstallPackage: { installPackage }
  } = getState().appManagement.entity.toAudit;
  const validStatus =
    status === OperationStatus.load_success ||
    status === OperationStatus.editing ||
    status === OperationStatus.save_fail;
  if (!validStatus) return;
  const data = {
    styleScreenshots: JSON.stringify(getneratePostAuditData(styleInfo)),
    appPackage: installPackage.value
  };
  return dispatch({
    types: [CREATE_TO_AUDIT, CREATE_TO_AUDIT_SUCCESS, CREATE_TO_AUDIT_FAIL],
    promise: http => http.post(`/api/appManagement/postAdSlotAudit/${adPosId}`, { data })
  });
};

// 新建应用管理页 取消操作
export const goToAppList = tabType => (dispatch, getState) => {
  const { appId } = getState().appManagement.entity.adPos.adPosInfo; 
  return dispatch({
    type: GO_TO_APP_LIST,
    payload: {
      tabType,
      appId
    }
  });
};

// 进入编辑广告位，设置是否为编辑状态
export const setAdPosIsEdit = isEdit => ({
  type: SET_ADPOS_ISEDIT,
  isEdit
});

// 新建应用获取分类
export const getAppCategories = () =>({
  types: [
    GET_APP_CATEGORY,
    GET_APP_CATEGORY_SUCCESS,
    GET_APP_CATEGORY_FAIL
  ],
  promise: http => http.get('/api/appManagement/getAppCategories')
});

// 根据应用id获取应用名称
export const getAppNameById = appId => ({
  types: [
    GET_APP_NAME_BY_ID,
    GET_APP_NAME_BY_ID_SUCCESS,
    GET_APP_NAME_BY_ID_FAIL
  ],
  promise: http => http.get(`/api/appManagement/getAppNameById/${appId}`)
});

// 获取预设模板数据
export const getStandardTemplates = () => ({
  types: [
    GET_STANDARD_TEMPLATES,
    GET_STANDARD_TEMPLATES_SUCCESS,
    GET_STANDARD_TEMPLATES_FAIL
  ],
  promise: http => http.get('/api/appManagement/getStandardTemplates')
});

// 获取预设元素数据
export const getStandardElements = () => ({
  types: [
    GET_STANDARD_ELEMENTS,
    GET_STANDARD_ELEMENTS_SUCCESS,
    GET_STANDARD_ELEMENTS_FAIL
  ],
  promise: http => http.get('/api/appManagement/getStandardElements')
});

// 根据广告位id获取广告位数据
export const getAdSlotInfo = slotUdid => ({
  types: [
    GET_ADSLOT_INFO,
    GET_ADSLOT_INFO_SUCCESS,
    GET_ADSLOT_INFO_FAIL
  ],
  promise: http => http.get(`/api/appManagement/getAdSlotInfo/${slotUdid}`)
});

// 获取广告位审核信息
export const getAdSlotAuditInfo = slotUdid => ({
  types: [
    GET_ADSLOT_AUDIT_INFO,
    GET_ADSLOT_AUDIT_INFO_SUCCESS,
    GET_ADSLOT_AUDIT_INFO_FAIL
  ],
  promise: http => http.get(`/api/appManagement/getAdSlotAuditInfo/${slotUdid}`)
});

// 讲审核信息回传到state,提交审核需要用
export const changeSlotAuditSource = (index, list, type) => ({
  type: CHANGE_SLOT_AUDIT_SOURCE,
  payload: {
    index,
    list,
    type
  }
});

// 重置audit 数据
export const resetAuditData = () => ({
  type: RESET_AUDIT_DATA
});

// 回传保存的类型
export const changeSaveType = saveType => ({
  type: CHANGE_SAVE_TYPE,
  payload: saveType
});

// 生成自测物料
export const generateSelfTestMaterial = slotUdid => ({
  types: [
    GENERATE_SELF_TEST_MATERIAL,
    GENERATE_SELF_TEST_MATERIAL_SUCCESS,
    GENERATE_SELF_TEST_MATERIAL_FAIL
  ],
  promise: http => http.post(`/api/appManagement/generateSelfTestMaterial/${slotUdid}`)
});