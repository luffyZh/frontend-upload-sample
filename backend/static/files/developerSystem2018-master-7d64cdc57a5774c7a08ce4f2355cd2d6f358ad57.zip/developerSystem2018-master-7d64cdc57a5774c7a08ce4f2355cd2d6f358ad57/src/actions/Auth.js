import {
  GO_TO_LOGIN_PAGE,
  LOGIN_SUCCESS,
  LOGOUT,
  LOGOUT_SUCCESS,
  LOGOUT_FAIL
} from '../constants/ActionTypes';

// 跳转到登陆页
export const goToLogin = payload => ({
  type: GO_TO_LOGIN_PAGE,
  payload
});

// 登陆成功
export const loginSuccess = payload => ({
  type: LOGIN_SUCCESS,
  payload
});

// 登出系统
export const logout = () => ({
  types: [LOGOUT, LOGOUT_SUCCESS, LOGOUT_FAIL],
  promise: http => http.get('/logout')
});
