import { connect } from 'react-redux';
import AccountManagement from '../../pages/accountManagement';
import {
  getSelfTestDeviceList,
  changeSelfTestDeviceStatus,
  addSelfTestDevice,
  changeUserInfo,
  updateAccountInfo,
  updateDeviceInfo,
  getSystemInfo,
  queryConditionChange,
  updateSystemInfo
} from '../../actions/AccountManagement';

const mapStateToProps = state => ({
  selfDeviceList: state.accountManagement.deviceInfo.list,
  user: state.accountManagement.accountInfo.user,
  originalUser: state.accountManagement.accountInfo.originalUser,
  systemList: state.accountManagement.systemInfo.list.list,
  systemInfoTotal: state.accountManagement.systemInfo.list.total, 
  queryCondition: state.accountManagement.systemInfo.queryCondition,
  systemInfoStatus: state.accountManagement.systemInfo.list.status
});

const mapDispatchToProps = dispatch => ({
  getSelfTestDeviceList() {
    dispatch(getSelfTestDeviceList());
  },

  changeSelfTestDeviceStatus(ids, status) {
    dispatch(changeSelfTestDeviceStatus(ids, status));
  },

  addSelfTestDevice(deviceObj) {
    dispatch(addSelfTestDevice(deviceObj));
  },

  changeUserInfo(user) {
    dispatch(changeUserInfo(user));
  },

  updateAccountInfo() {
    dispatch(updateAccountInfo());
  },

  updateDeviceInfo(id, comment) {
    dispatch(updateDeviceInfo(id, comment));
  },

  getSystemInfo() {
    dispatch(getSystemInfo());
  },

  updateSystemInfo(id, status) {
    dispatch(updateSystemInfo(id, status));
  },

  onPageSizeChange(pageNo, pageSize) {
    dispatch(
      queryConditionChange({
        type: 'pageSize',
        pageNo,
        pageSize
      }),
    );
  },

  onPageNoChange(pageNo) {
    dispatch(
      queryConditionChange({
        type: 'pageNo',
        pageNo
      }),
    );
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AccountManagement);
