import { connect } from 'react-redux';
import { logout } from '../actions/Auth';
import { fetchUnreadMessage } from '../actions/AccountManagement';
import Layout from '../components/Layout';

const mapStateToProps = state => ({
  username: state.auth.user && state.auth.user.email,
  permissionList: state.auth.user && state.auth.user.permissionList,
  unReadCount: state.accountManagement.systemInfo.list.unReadCount
});

const mapDispatchToProps = dispatch => ({
  onLogout() {
    dispatch(logout());
  },
  fetchUnreadMessage() {
    dispatch(fetchUnreadMessage());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(Layout);
