import { connect } from 'react-redux';
import DataReport from '../../pages/dataReport';
import {
  queryConditionChange,
  getDeveloperReportData,
  downloadReportData,
  getDataReportCascadingMenuList,
  cascadingQueryConditionChange,
  selectedMenuListChange
} from '../../actions/DataReport';

const mapStateToProps = state => {
  const {
    tabType,
    list
  } = state.dataReport.data;

  const {
    queryCondition: cascadingQueryCondition,
    list: { originMenuList, status, total, selectedMenuList, selectedCount }
  } = state.dataReport.cascading;

  return {
    queryCondition: state.dataReport.queryCondition,
    data: list[tabType.activeTab],
    type: tabType.activeTab,
    originMenu: { status, list: originMenuList, total, selectedMenuList, selectedCount },
    cascadingQueryCondition
  };
};

const mapDispatchToProps = dispatch => ({

  onPageSizeChange(tabType, pageNo, pageSize) {
    dispatch(
      queryConditionChange(
        tabType,
        {
          type: 'pageSize',
          pageNo,
          pageSize
        }
      ),
    );
  },

  onPageNoChange(tabType, pageNo) {
    dispatch(
      queryConditionChange(
        tabType, 
        {
          type: 'pageNo',
          pageNo
        }
      ),
    );
  },

  onDateRangeChange(tabType, dateRange) {
    dispatch(
      queryConditionChange(
        tabType,
        {
          type: 'dateRange',
          dateRange
        }
      ),
    );
  },

  onQueryMethodChange(tabType, aggregate) {
    dispatch(
      queryConditionChange(
        tabType, 
        {
          type: 'aggregate',
          aggregate
        }
      )
    );
  },

  onFilterIdChange(tabType, id) {
    dispatch(
      queryConditionChange(
        tabType,
        {
          type: 'id',
          id
        }
      )
    );
  },

  onFilterIdsChange(tabType, ids) {
    dispatch(
      queryConditionChange(
        tabType,
        {
          type: 'ids',
          ids
        }
      )
    );
  },

  getDeveloperReportData(tabType) {
    dispatch(getDeveloperReportData(tabType));
  },

  downloadReportData(options) {
    dispatch(downloadReportData(options));
  },

  getDataReportCascadingMenuList(tabType) {
    dispatch(getDataReportCascadingMenuList(tabType));
  },

  onCascadingKeywordChange(keyword) {
    dispatch(
      cascadingQueryConditionChange({
        type: 'keyword',
        keyword
      })
    );
  },

  onCascadingPageSizeChange(pageSize) {
    dispatch(
      cascadingQueryConditionChange({
        type: 'pageSize',
        pageSize
      })
    );
  },

  onSelectedMenuListChange(tabType, selectedMenuList) {
    dispatch(
      selectedMenuListChange(tabType, selectedMenuList)
    );
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(DataReport);
