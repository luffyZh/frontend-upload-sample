import { connect } from 'react-redux';
import New from '../../pages/appManagement/new';
import {
  editApp,
  editAdPos,
  editSelfTest,
  editToAudit,
  appDataChange,
  saveAppData,
  saveAdPosData,
  adPosAddElem,
  addOrDelStyle,
  adPosDataChange,
  saveSelfTestData,
  saveToAuditData,
  goToAppList,
  getAppNameById,
  getAdSlotInfo,
  getAdSlotAuditInfo,
  changeSlotAuditSource,
  changeSaveType,
  generateSelfTestMaterial
} from '../../actions/AppManagement/new';
import { getSelfTestDeviceList } from '../../actions/AccountManagement';

const mapStateToProps = state => {
  const { app, adPos, selfTest, toAudit } = state.appManagement.entity;
  return {
    appData: app,
    adPosData: adPos,
    selfTestData: selfTest,
    toAuditData: toAudit
  };
};

const mapDispatchToProps = dispatch => ({
  onEditApp() {
    dispatch(editApp());
  },

  onEditAdPos() {
    dispatch(editAdPos());
  },

  onEditSelfTest() {
    dispatch(editSelfTest());
  },

  onEditToAudit() {
    dispatch(editToAudit());
  },

  onAppDataChange(sectionType, itemType, itemValue) {
    dispatch(appDataChange(sectionType, itemType, itemValue));
  },

  onSaveAppData(saveType) {
    dispatch(saveAppData(saveType));
  },

  onSaveAdPosData(saveType, isEdit) {
    dispatch(saveAdPosData(saveType, isEdit));
  },

  onAdPosAddElem(elemType, elemValue, index) {
    dispatch(adPosAddElem(elemType, elemValue, index));
  },

  onAddOrDelStyle(styleInfo) {
    dispatch(addOrDelStyle(styleInfo));
  },

  onAdPosDataChange(sectionType, itemType, itemValue, itemIndex) {
    dispatch(adPosDataChange(sectionType, itemType, itemValue, itemIndex));
  },

  onSaveSelfTestData(saveType) {
    dispatch(saveSelfTestData(saveType));
  },

  onSaveToAuditData() {
    dispatch(saveToAuditData());
  },

  onGoToAppList(tabType) {
    dispatch(goToAppList(tabType));
  },

  getAppNameById(appId) {
    dispatch(getAppNameById(appId));
  },

  getSelfTestDeviceList(type) {
    dispatch(getSelfTestDeviceList(type));
  },

  getAdSlotInfo(slotUdid) {
    dispatch(getAdSlotInfo(slotUdid));
  },

  getAdSlotAuditInfo(slotUdid) {
    dispatch(getAdSlotAuditInfo(slotUdid));
  },

  changeSlotAuditSource(index, list, type) {
    dispatch(changeSlotAuditSource(index, list, type));
  },

  changeSaveType(saveType) {
    dispatch(changeSaveType(saveType));
  },

  generateSelfTestMaterial(slotUdid) {
    dispatch(generateSelfTestMaterial(slotUdid));
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(New);
