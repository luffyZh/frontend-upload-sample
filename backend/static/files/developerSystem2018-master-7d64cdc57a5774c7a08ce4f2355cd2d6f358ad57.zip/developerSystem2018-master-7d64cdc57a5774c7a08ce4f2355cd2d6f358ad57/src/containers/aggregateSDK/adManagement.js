import { connect } from 'react-redux';
import AdManagement from '../../pages/aggregateSDK/adManagement';
import {
  deleteSlotList,
  addSlotList,
  editSlotName,
  getAdvertisingList,
  deleteAdvertisingList,
  upSetPriority
} from '../../actions/AggregateSDK';

const mapStateToProps = state => ({
  total: state.aggregateSDK.adList.total,
  list: state.aggregateSDK.adList.list,
  status: state.aggregateSDK.adList.status,
  advertisingList: state.aggregateSDK.adList.advertisingList,
  mediationSdkSlotName: state.aggregateSDK.adList.mediationSdkSlotName,
  changeInfo: state.aggregateSDK.editPriority.priority.changeInfo
});

const mapDispatchToProps = dispatch => ({
  deleteSlotList(mediationSdkSlotUid, index) {
    dispatch(deleteSlotList(mediationSdkSlotUid, index));
  },

  addSlotList(mediationSdkSlotName) {
    dispatch(addSlotList(mediationSdkSlotName));
  },

  editSlotName(mediationSdkSlotName, mediationSdkSlotUid) {
    dispatch(editSlotName(mediationSdkSlotName, mediationSdkSlotUid));
  },

  getAdvertisingList(mediationSdkSlotUid) {
    dispatch(getAdvertisingList(mediationSdkSlotUid));
  },

  deleteAdvertisingList(mediationSdkSlotUid, settingId) {
    dispatch(deleteAdvertisingList(mediationSdkSlotUid, settingId));
  },

  upSetPriority(upSettingId, upPriority, downSettingId, downPriority) {
    dispatch(upSetPriority(upSettingId, upPriority, downSettingId, downPriority));
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AdManagement);