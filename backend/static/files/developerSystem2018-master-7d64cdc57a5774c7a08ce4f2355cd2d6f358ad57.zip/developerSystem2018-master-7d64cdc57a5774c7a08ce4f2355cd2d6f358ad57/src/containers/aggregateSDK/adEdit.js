import { connect } from 'react-redux';
import AdEdit from '../../pages/aggregateSDK/adManagement/edit';
import {
  getPriorityList,
  getDetailsInfo,
  getPlatformList,
  addPlatformPriority,
  editPlatformPriority,
  deletePlatformPriority,
  platformEditing,
  platformValueChange,
  platformAdding,
  platformDelete,
  getOptionList,
  radioChange,
  getLanguageList,
  getCountryList,
  emitEditModal,
  editOption,
  changeEditModalValue,
  editPriorityConfig,
  addPriorityConfig,
  changeSelectedList,
  onCascadingKeywordChange,
  platformAddRow,
  platformDeleteRow,
  platformRowSave,
  platformRowEdit
} from '../../actions/AggregateSDK';

const mapStateToProps = state => ({
  mediationSdkSlotName: state.aggregateSDK.editPriority.priorityConfig.mediationSdkSlotName,
  platformPriorities: state.aggregateSDK.editPriority.priorityConfig.platformPriorities,
  status: state.aggregateSDK.editPriority.priority.status,
  priorityList: state.aggregateSDK.editPriority.priority.priorityList,
  detailsInfo: state.aggregateSDK.editPriority.priority.detailsInfo,
  osList: state.aggregateSDK.editPriority.priority.osList,
  appList: state.aggregateSDK.editPriority.priority.appList,
  channelList: state.aggregateSDK.editPriority.priority.channelList,
  countryList: state.aggregateSDK.editPriority.priority.countryList,
  languageList: state.aggregateSDK.editPriority.priority.languageList,
  osVersionIds: state.aggregateSDK.editPriority.priority.osVersionIds,
  appVersionIds: state.aggregateSDK.editPriority.priority.appVersionIds,
  channelNoIds: state.aggregateSDK.editPriority.priority.channelNoIds,
  countryIds: state.aggregateSDK.editPriority.priority.countryIds,
  sysLanguageIds: state.aggregateSDK.editPriority.priority.sysLanguageIds,
  optionType: state.aggregateSDK.editPriority.priority.optionType,
  toDeleteIds: state.aggregateSDK.editPriority.priority.toDeleteIds,
  toAddValues: state.aggregateSDK.editPriority.priority.toAddValues,
  changeInfo: state.aggregateSDK.editPriority.priority.changeInfo,
  disabledValue: state.aggregateSDK.editPriority.priority.disabledValue
});

const mapDispatchToProps = dispatch => ({
  getPriorityList() {
    dispatch(getPriorityList());
  },

  getDetailsInfo(mediationSdkSlotUid) {
    dispatch(getDetailsInfo(mediationSdkSlotUid));
  },

  getOptionList(optionType) {
    dispatch(getOptionList(optionType));
  },

  getLanguageList() {
    dispatch(getLanguageList());
  },

  getCountryList() {
    dispatch(getCountryList());
  },

  radioChange(option, changeInfo) {
    dispatch(radioChange(option, changeInfo));
  },

  emitEditModal(optionType) {
    dispatch(emitEditModal(optionType));
  },

  changeSelectedList(option, selectedMenuList, text, changeInfo) {
    dispatch(changeSelectedList(option, selectedMenuList, text, changeInfo));
  },

  editOption(toDeleteIds, toAddValues) {
    dispatch(editOption(toDeleteIds, toAddValues));
  },

  changeEditModalValue(optionType, toDeleteIds, toAddValues, changeInfo) {
    dispatch(changeEditModalValue(optionType, toDeleteIds, toAddValues, changeInfo));
  },

  onCascadingKeywordChange(keyword) {
    dispatch(onCascadingKeywordChange(keyword));
  },

  editPriorityConfig(priorityList, mediationSdkSlotUid) {
    dispatch(editPriorityConfig(priorityList, mediationSdkSlotUid));
  },

  addPriorityConfig(mediationSdkSlotUid, priorityList) {
    dispatch(addPriorityConfig(mediationSdkSlotUid, priorityList));
  },

  getPlatformList(mediationSdkSlotUid) {
    dispatch(getPlatformList(mediationSdkSlotUid));
  },

  platformEditing(editStatus, index, dataSource) {
    dispatch(platformEditing(editStatus, index, dataSource));
  },

  platformValueChange(dataSource, index) {
    dispatch(platformValueChange(dataSource, index));
  },

  platformAddRow(dataSource, index) {
    dispatch(platformAddRow(dataSource, index));
  },

  platformDeleteRow(dataSource, index) {
    dispatch(platformDeleteRow(dataSource, index));
  },

  platformRowSave(dataSource, index) {
    dispatch(platformRowSave(dataSource, index));
  },

  platformRowEdit(dataSource, index) {
    dispatch(platformRowEdit(dataSource, index));
  },

  platformAdding(editStatus, newAdd) {
    dispatch(platformAdding(editStatus, newAdd));
  },

  platformDelete(newAdd, index) {
    dispatch(platformDelete(newAdd, index));
  },

  addPlatformPriority(mediationSdkSlotUid, platformPriorityName, details, editStatus, newAdd) {
    dispatch(addPlatformPriority(mediationSdkSlotUid, platformPriorityName, details, editStatus, newAdd));
  },

  editPlatformPriority(mediationSdkSlotUid, platformPriorityId, platformPriorityName, details, editStatus, index) {
    dispatch(editPlatformPriority(mediationSdkSlotUid, platformPriorityId, platformPriorityName, details, editStatus, index));
  },

  deletePlatformPriority(mediationSdkSlotUid, platformPriorityId, index) {
    dispatch(deletePlatformPriority(mediationSdkSlotUid, platformPriorityId, index));
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AdEdit);