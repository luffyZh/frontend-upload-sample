import { getAppCategoriesReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    categories: ret
  };
  return payload;
}

const getAppCategories = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getAppCategoriesReducer(accessId, user);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAppCategories);
