import { updateSlotStatusReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import {
  SlotOpStatusForBE
} from '../../constants/MenuTypes';

function handleResData(ret) {
  return ret;
}

const updateSlotStatus = async req => {
  const {
    _accessId: accessId,
    body: {
      slotUdids,
      slotOpStatus
    }
  } = req;

  const data = {
    slotUdids,
    slotOpStatus: SlotOpStatusForBE[slotOpStatus]
  };
  const user = fetchUserInfo(req); 

  const ret = await updateSlotStatusReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(updateSlotStatus);
