import { postAdSlotAuditReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const postAdSlotAudit = async req => {
  const {
    _accessId: accessId,
    params: {
      slotUdid
    },
    body: {
      styleScreenshots,
      appPackage
    }
  } = req;
  
  const data = {
    slotUdid,
    styleScreenshots: JSON.parse(styleScreenshots),
    appPackage
  };
  const user = fetchUserInfo(req);

  const ret = await postAdSlotAuditReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(postAdSlotAudit);
