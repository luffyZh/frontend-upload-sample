import fs from 'fs';
import { uploadSlotImageAuditSourceReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

const uploadSlotImageAuditSource = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);

  // 数据合法性已在上级进行了验证
  const fileInfo = req.file;

  const base64 = await new Promise((resolve, reject) => {
    fs.readFile(fileInfo.path, (err, data) => {
      if (err) {
        return reject(err);
      }
      resolve(data.toString('base64'));
    });
  });

  const postData = {
    imageName: fileInfo.filename,
    base64
  };

  try {
    fs.unlinkSync(fileInfo.path);
  } catch (e) {
    console.info(`unlink image failed: ${fileInfo.path}`);
  }
  

  const ret = await uploadSlotImageAuditSourceReducer(accessId, user, postData);

  return {
    content: {
      resData: ret
    }
  };
};

export default tryCatch(uploadSlotImageAuditSource);
