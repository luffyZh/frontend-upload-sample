import { createNewAdPosReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import { SlotStyleForBE } from '../../constants/MenuTypes';

function handleResData(ret) {
  const payload = {
    slotUdid: ret.slotUdid
  };
  return payload;
}

const createNewAdPos = async req => {
  const {
    _accessId: accessId,
    body: {
      appId,
      adPosName,
      adPosType,
      slotCallbackUrl = '',
      styleList,
      slotUdid
    }
  } = req;
  const data = {
    appId: parseInt(appId, 10),
    slotName: adPosName,
    slotStyle: SlotStyleForBE[adPosType],
    slotCallbackUrl,
    styleList: JSON.parse(styleList),
    slotUdid
  };

  const user = fetchUserInfo(req);
  const ret = await createNewAdPosReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(createNewAdPos);
