import { getAppAndAdposStatisticListReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    list: ret
  };
  return payload;
}

const getAppAndAdposStatisticList = async req => {
  const {
    _accessId: accessId,
    query: {
      subType,
      startDate = '',
      endDate = '',
      idsList = []
    }
  } = req;
  const user = fetchUserInfo(req);
  
  const data = {
    subType,
    startDate,
    endDate,
    idsList
  };
  const ret = await getAppAndAdposStatisticListReducer(accessId, user, data, subType);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAppAndAdposStatisticList);
