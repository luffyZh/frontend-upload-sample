import { createNewAppReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import { AppOsForBE } from '../../constants/MenuTypes';

function handleResData(ret) {
  return ret;
}

const createNewApp = async req => {
  const {
    _accessId: accessId,
    body: {
      appName,
      appOs,
      appCategory,
      appUniqueIdentifier
    }
  } = req;

  const data = {
    appName,
    appOs: AppOsForBE[appOs],
    appCategory,
    appUniqueIdentifier
  };
  const user = fetchUserInfo(req);
  

  const ret = await createNewAppReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(createNewApp);
