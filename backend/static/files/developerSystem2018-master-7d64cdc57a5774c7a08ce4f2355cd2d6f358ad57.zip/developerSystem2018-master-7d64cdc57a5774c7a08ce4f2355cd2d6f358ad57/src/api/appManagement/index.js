import { Router } from 'express';
import multer from 'multer';
import { uploadDir } from '../../config';
import queryAppEntityList from './queryAppEntityList';
import updateAppStatus from './updateAppStatus';
import updateSlotStatus from './updateSlotStatus';
import getAppCategories from './getAppCategories';
import createNewApp from './createNewApp';
import getAppAndAdposStatisticList from './getAppAndAdposStatisticList';
import createNewAdPos from './createNewAdPos';
import getAppNameById from './getAppNameById';
import getStandardTemplates from './getStandardTemplates';
import getStandardElements from './getStandardElements';
import getAdSlotInfo from './getAdSlotInfo';
import getAdSlotAuditInfo from './getAdSlotAuditInfo';
import uploadSlotImageAuditSource from './uploadSlotImageAuditSource';
import uploadSlotPackageAuditSource from './uploadSlotPackageAuditSource';
import postAdSlotAudit from './postAdSlotAudit';
import updateAdSlotStyleStatus from './updateAdSlotStyleStatus';
import generateSelfTestMaterial from './generateSelfTestMaterial';
/**
 * 存储图片上传的位置和文件命名
 * linux 下需要注意存储图片的位置的文件夹是否有权限创建
 * 如果没有权限，会导致图片上传失败
 */
const imageStorage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, uploadDir);
  },
  filename(req, file, cb) {
    // 以进程 id、timestamp 和 accessId 计算的 filename，node.js 的单线程保证了结果不会重复
    const filename = `${1e8 - process.pid}${Date.now()}${1e8 - req._accessId}`; // eslint-disable-line
    let suffix;
    if (file.mimetype === 'image/png') {
      suffix = '.png';
    } else {
      suffix = '.jpg';
    }
    cb(null, `${filename}${suffix}`);
  }
});

// 上传文件安装包
const packageStorage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, uploadDir);
  },
  filename(req, file, cb) {
    // 以进程 id、timestamp 和 accessId 计算的 filename，node.js 的单线程保证了结果不会重复
    // const filename = `${1e8 - process.pid}${Date.now()}${1e8 - req._accessId}`; // eslint-disable-line
    // let suffix;
    // if (file.mimetype === 'application/vnd.android.package-archive') {
    //   suffix = '.apk';
    // } else {
    //   suffix = '.ipa';
    // }
    // cb(null, `${filename}${suffix}`);
    cb(null, `${file.originalname}`);
  }
});

// 新建、编辑创意的上传图片的过滤器，筛选哪些是合法的上传
const imageFilter = (req, file, cb) => {
  const { mimetype } = file;
  const validType = /^image\/(png|jpeg)$/.test(mimetype);
  cb(null, validType);
};

// 上传安装包的文件过滤器
const packageFilter = (req, file, cb) => {
  const acceptPackageType = [
    'application/vnd.android.package-archive',
    'application/iphone-package-archive',
    'application/x-itunes-ipa',
    'application/octet-stream'
  ];
  const { mimetype } = file;
  const validType = acceptPackageType.includes(mimetype);
  cb(null, validType);
};

const uploadImage = multer({
  storage: imageStorage,
  limits: {
    fileSize: 1 * 1024 * 1024, // 1MB
    files: 1, // 不同图片名个数
    fields: 3, // body 中参数个数
    fieldNameSize: 100, // body 中参数名长度
    fieldSize: 100 // body 中参数值长度
  },
  fileFilter: imageFilter
}).single('slotAuditImageSource');

const uploadPackage = multer({
  storage: packageStorage,
  limits: {
    fileSize: 400 * 1024 * 1024, // 文件包支持400M
    files: 1, // 不同图片名个数
    fields: 3, // body 中参数个数
    fieldNameSize: 100, // body 中参数名长度
    fieldSize: 100 // body 中参数值长度
  },
  fileFilter: packageFilter
}).single('slotAuditPackageSource');

const router = new Router();

// 新建 提交审核页面上传图片
router.post(
  '/uploadSlotImageAuditSource',
  (req, res, next) => {
    uploadImage(req, res, err => {
      if (err) {
        // eslint-disable-next-line no-param-reassign
        err.message = `${err.message} (code: ${err.code}, field: ${
          err.field
        }, storageErrors: ${err.storageErrors.join(';')})`;
        err.code = 400; // eslint-disable-line no-param-reassign
      }
      next(err);
    });
  },
  uploadSlotImageAuditSource,
);

// 新建广告位提交审核上传安装包
router.post(
  '/uploadSlotPackageAuditSource/:slotUdid',
  (req, res, next) => {
    uploadPackage(req, res, err => {
      if (err) {
        // eslint-disable-next-line no-param-reassign
        err.message = `${err.message} (code: ${err.code}, field: ${
          err.field
        }, storageErrors: ${err.storageErrors.join(';')})`;
        err.code = 400; // eslint-disable-line no-param-reassign
      }
      next(err);
    });
  },
  uploadSlotPackageAuditSource,
);

// 获取全部应用管理列表
router.get('/queryAppEntityList', queryAppEntityList);

// 批量修改应用状态
router.put('/updateAppStatus', updateAppStatus);

// 批量修改广告位列表状态
router.put('/updateSlotStatus', updateSlotStatus);

// 新建应用获取分类
router.get('/getAppCategories', getAppCategories);

// 新建应用
router.post('/createNewApp', createNewApp);

// 获取应用列表数据部分
router.get('/getAppAndAdposStatisticList', getAppAndAdposStatisticList);

// 新建广告位
router.post('/createNewAdPos', createNewAdPos);

// 编辑广告位
router.put('/editAdPos', createNewAdPos);

// 根据应用id获取应用名称
router.get('/getAppNameById/:appId', getAppNameById);

// 获取预设模板数据
router.get('/getStandardTemplates', getStandardTemplates);

// 获取预设元素数据
router.get('/getStandardElements', getStandardElements);

// 根据id获取广告位信息
router.get('/getAdSlotInfo/:slotUdid', getAdSlotInfo);

// 根据id获取广告位审核信息
router.get('/getAdSlotAuditInfo/:slotUdid', getAdSlotAuditInfo);

// 广告位提交审核
router.post('/postAdSlotAudit/:slotUdid', postAdSlotAudit);

// 修改广告位样式状态
router.put('/updateAdSlotStyleStatus/:slotUdid', updateAdSlotStyleStatus);

// 生成自测物料
router.post('/generateSelfTestMaterial/:slotUdid', generateSelfTestMaterial);

export default router;
