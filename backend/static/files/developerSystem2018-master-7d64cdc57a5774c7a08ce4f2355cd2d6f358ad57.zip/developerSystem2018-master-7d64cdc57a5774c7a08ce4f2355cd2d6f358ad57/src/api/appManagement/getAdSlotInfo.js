import { getAdSlotInfoReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  ret.styleList.forEach(item => {
    item.imageElements.map(ele => ele.isStandard = ele.isStandard === 0);
    item.textElements.map(ele => ele.isStandard = ele.isStandard === 0);
    item.videoElements.map(ele => ele.isStandard = ele.isStandard === 0);
    item.styleType = item.styleType && item.styleType.toString();
    // 兼容旧数据
    item.minSupportVersion = item.minSupportVersion || '0.0.0';
  });
  return ret;
}

const getAdSlotInfo = async req => {
  const {
    _accessId: accessId,
    params: {
      slotUdid
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getAdSlotInfoReducer(accessId, user, slotUdid);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAdSlotInfo);
