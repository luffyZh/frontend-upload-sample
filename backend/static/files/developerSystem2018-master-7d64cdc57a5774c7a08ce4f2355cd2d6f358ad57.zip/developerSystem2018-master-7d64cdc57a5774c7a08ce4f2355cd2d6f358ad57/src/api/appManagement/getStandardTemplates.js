import { getStandardTemplatesReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    standardTemplates: ret
  };
  return payload;
}

const getStandardTemplates = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getStandardTemplatesReducer(accessId, user);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getStandardTemplates);
