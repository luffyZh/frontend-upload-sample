import { queryAppEntityListReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import { AppTabTypes, AppAndAdposTabDataColumns } from '../../constants/MenuTypes';

function handleResData(ret) {
  let list = [];
  ret.resultList.map(item => {
    AppAndAdposTabDataColumns.map(key => item[key] = '--');
    list.push(item); 
  });
  const payload = {
    list,
    total: ret.total
  };
  return payload;
}

const queryAppEntityList = async req => {
  const {
    _accessId: accessId,
    query: {
      subType,
      tabType,
      startDate = '',
      endDate = '',
      keyword = '',
      pageNo,
      pageSize,
      appId,
      appOs,
      appStatus,
      operateStatus,
      auditStatus,
      object
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const data = subType === AppTabTypes.appTab
    ? {
      subType,
      tabType,
      startDate,
      endDate,
      keyword,
      pageNo,
      pageSize,
      appId,
      appOs,
      appStatus
    }
    : {
      subType,
      tabType,
      startDate,
      endDate,
      keyword,
      pageNo,
      pageSize,
      appId,
      operateStatus,
      auditStatus,
      object
    };
  const ret = await queryAppEntityListReducer(accessId, user, data, subType);
  const resData = handleResData(ret, subType);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(queryAppEntityList);
