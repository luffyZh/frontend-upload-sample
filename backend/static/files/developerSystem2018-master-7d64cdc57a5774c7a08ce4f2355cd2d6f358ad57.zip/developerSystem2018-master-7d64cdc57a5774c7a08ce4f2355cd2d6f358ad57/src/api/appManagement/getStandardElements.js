import { getStandardElementsReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    standardElements: ret
  };
  return payload;
}

const getStandardElements = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getStandardElementsReducer(accessId, user);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getStandardElements);
