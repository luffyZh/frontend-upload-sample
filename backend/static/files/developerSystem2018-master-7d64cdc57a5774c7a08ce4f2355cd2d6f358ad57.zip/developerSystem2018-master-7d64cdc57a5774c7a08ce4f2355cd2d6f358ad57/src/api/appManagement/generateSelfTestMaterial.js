import { generateSelfTestMaterialReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const generateSelfTestMaterial = async req => {
  const {
    _accessId: accessId,
    params: {
      slotUdid
    }
  } = req;

  const user = fetchUserInfo(req);

  const ret = await generateSelfTestMaterialReducer(accessId, user, slotUdid);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(generateSelfTestMaterial);
