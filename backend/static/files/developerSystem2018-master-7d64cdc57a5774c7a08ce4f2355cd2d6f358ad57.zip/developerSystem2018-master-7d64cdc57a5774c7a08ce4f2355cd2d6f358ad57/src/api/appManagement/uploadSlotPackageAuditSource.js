import fs from 'fs';
import { uploadSlotPackageAuditSourceReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

const uploadSlotPackageAuditSource = async req => {
  const {
    _accessId: accessId,
    params: {
      slotUdid
    }
  } = req;

  const user = fetchUserInfo(req);

  const fileInfo = req.file;

  const fileData = fs.createReadStream(fileInfo.path, { autoClose: true });

  const postData = {
    slotUdid,
    packageData: fileData
  };

  // 遇到错误，删除temp文件
  fileData.on('error', err => {
    console.log(err.message);
    fs.exists(fileInfo.path, exists => {
      if (exists) {
        try {
          fs.closeSync(fileInfo.path);
          fs.unlinkSync(fileInfo.path);
        } catch (e) {
          console.log(`unlink file failed: ${fileInfo.path}`);
        }
      }
    });
  });

  // 顺利读取文件流之后，删除temp文件
  fileData.on('end', () => {
    fs.exists(fileInfo.path, exists => {
      if (exists) {
        try {
          fs.unlinkSync(fileInfo.path);
        } catch (e) {
          console.log(e.message);
          console.log(`unlink file failed: ${fileInfo.path}`);
        }
      }
    });
  });

  const timeout = 60000;

  const ret = await uploadSlotPackageAuditSourceReducer(accessId, user, timeout, postData);

  return {
    content: {
      resData: ret
    }
  };
};

export default tryCatch(uploadSlotPackageAuditSource);
