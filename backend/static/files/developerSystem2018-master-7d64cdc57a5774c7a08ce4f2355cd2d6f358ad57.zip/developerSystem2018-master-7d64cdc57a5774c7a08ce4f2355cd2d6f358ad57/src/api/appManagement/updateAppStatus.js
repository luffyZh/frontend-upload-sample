import { updateAppStatusReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import {
  AppOpStatusForBE
} from '../../constants/MenuTypes';

function handleResData(ret) {
  return ret;
}

const updateAppStatus = async req => {
  const {
    _accessId: accessId,
    body: {
      appIds,
      appStatus
    }
  } = req;

  const data = {
    appIds,
    appStatus: AppOpStatusForBE[appStatus]
  };

  const user = fetchUserInfo(req);
  

  const ret = await updateAppStatusReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(updateAppStatus);
