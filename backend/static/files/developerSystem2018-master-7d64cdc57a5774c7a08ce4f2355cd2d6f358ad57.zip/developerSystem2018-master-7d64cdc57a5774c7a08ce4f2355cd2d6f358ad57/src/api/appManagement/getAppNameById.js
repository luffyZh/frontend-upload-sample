import { getAppNameByIdReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    appName: ret.appName,
    slotNameList: ret.slotNameList || [],
    appOs: ret.appOs,
    appPackageName: ret.appPackageName
  };
  return payload;
}

const getAppNameById = async req => {
  const {
    _accessId: accessId,
    params: {
      appId
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getAppNameByIdReducer(accessId, user, appId);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAppNameById);
