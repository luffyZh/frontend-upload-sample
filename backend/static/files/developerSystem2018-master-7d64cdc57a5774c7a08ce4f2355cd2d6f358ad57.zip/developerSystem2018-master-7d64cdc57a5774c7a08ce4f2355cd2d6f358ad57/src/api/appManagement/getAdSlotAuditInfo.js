import { getAdSlotAuditInfoReducer } from '../atomicRequest/appManagement';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  ret.styleList.map(item => {
    const screenShot = [{
      key: Date.now(),
      name: 'slotAuditInfo',
      value: item.styleScreenshot,
      valid: !!item.styleScreenshot
    }];
    item.styleScreenshot = screenShot;
  });
  return ret;
}

const getAdSlotAuditInfo = async req => {
  const {
    _accessId: accessId,
    params: {
      slotUdid
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getAdSlotAuditInfoReducer(accessId, user, slotUdid);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAdSlotAuditInfo);
