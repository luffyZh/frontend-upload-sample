import { updateAccountInfoReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const updateAccountInfo = async req => {
  const {
    _accessId: accessId,
    query: {
      name,
      email,
      address,
      phone
    }
  } = req;

  const user = fetchUserInfo(req);

  const data = {
    name,
    email,
    address,
    phone
  };
  const ret = await updateAccountInfoReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(updateAccountInfo);
