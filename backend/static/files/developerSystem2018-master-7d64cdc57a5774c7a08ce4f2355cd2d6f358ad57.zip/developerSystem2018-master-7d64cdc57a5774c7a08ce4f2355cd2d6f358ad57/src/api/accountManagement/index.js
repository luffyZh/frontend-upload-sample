import { Router } from 'express';
import getSelfTestDeviceList from './getSelfTestDeviceList';
import changeSelfTestDeviceStatus from './changeSelfTestDeviceStatus';
import addSelfTestDevice from './addSelfTestDevice';
import getAccountInfo from './getAccountInfo';
import updateAccountInfo from './updateAccountInfo';
import updateDeviceInfo from './updateDeviceInfo';
import getSystemInfo from './getSystemInfo';
import updateSystemInfo from './updateSystemInfo';
import getUnreadMessage from './getUnreadMessage';

const router = new Router();

// 获取全部应用管理列表
router.get('/getSelfTestDeviceList', getSelfTestDeviceList);

// 改变设备信息状态
router.get('/changeSelfTestDeviceStatus', changeSelfTestDeviceStatus);

// 增加自测设备
router.post('/addSelfTestDevice', addSelfTestDevice);

// 获取用户信息
router.get('/getAccountInfo', getAccountInfo);

// 更新用户信息
router.put('/updateAccountInfo', updateAccountInfo);

// 更新设备备注信息
router.put('/updateDeviceInfo', updateDeviceInfo);

// 获取消息中心
router.get('/getSystemInfo', getSystemInfo);

// 更新消息中心消息状态
router.put('/updateSystemInfo', updateSystemInfo);

// 获取未读消息个数
router.get('/getUnreadMessage', getUnreadMessage);

export default router;
