import { updateDeviceInfoReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const updateDeviceInfo = async req => {
  const {
    _accessId: accessId,
    query: {
      id,
      comment
    }
  } = req;

  const user = fetchUserInfo(req);

  const data = {
    id,
    comment
  };
  const ret = await updateDeviceInfoReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(updateDeviceInfo);
