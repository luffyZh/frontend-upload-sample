import { addSelfTestDeviceReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const addSelfTestDevice = async req => {
  const {
    _accessId: accessId
  } = req;

  const data = req.body;

  const user = fetchUserInfo(req);
  
  const ret = await addSelfTestDeviceReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(addSelfTestDevice);
