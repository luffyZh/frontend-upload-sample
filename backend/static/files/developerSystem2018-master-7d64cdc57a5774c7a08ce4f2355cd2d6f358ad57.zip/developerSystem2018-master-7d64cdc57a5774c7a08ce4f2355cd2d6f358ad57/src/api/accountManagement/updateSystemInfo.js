import { updateSystemInfoReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const updateSystemInfo = async req => {
  const {
    _accessId: accessId,
    query: {
      id,
      status = 2
    }
  } = req;

  const user = fetchUserInfo(req);

  const data = {
    id,
    status
  };

  const ret = await updateSystemInfoReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(updateSystemInfo);
