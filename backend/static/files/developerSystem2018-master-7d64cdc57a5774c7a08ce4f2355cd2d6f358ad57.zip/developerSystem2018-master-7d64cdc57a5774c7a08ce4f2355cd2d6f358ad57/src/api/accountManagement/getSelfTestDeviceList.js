import { getSelfTestDeviceListReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    total: ret.length,
    list: ret
  };
  return payload;
}

const getSelfTestDeviceList = async req => {
  const {
    _accessId: accessId,
    query: {
      onlyEnabled
    }
  } = req;

  const data = {
    onlyEnabled
  };

  const user = fetchUserInfo(req);
  
  const ret = await getSelfTestDeviceListReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getSelfTestDeviceList);
