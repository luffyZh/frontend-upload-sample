import { getUnreadMessageReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getUnreadMessage = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);

  const ret = await getUnreadMessageReducer(accessId, user);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getUnreadMessage);
