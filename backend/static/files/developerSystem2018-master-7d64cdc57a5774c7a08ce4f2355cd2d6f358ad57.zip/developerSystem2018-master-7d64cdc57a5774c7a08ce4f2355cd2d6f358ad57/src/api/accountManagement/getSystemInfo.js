import { getSystemInfoReducer } from '../atomicRequest/accountManagement';
import { tryCatch, invalidParamsRes } from '../helper';
import {
  fetchUserInfo,
  isPositiveInteger
} from '../../core/utils';

function handleResData(ret) {
  const { resultList, total } = ret;
  const list = [...resultList].map(item => {
    item.date = item.date.split(' ')[0];
    return item;
  });
  return {
    list,
    total
  };
}

const getSystemInfo = async req => {
  const {
    _accessId: accessId,
    query: {
      pageNo = 1,
      pageCapacity = 10
    }
  } = req;

  // 必须是合法的正整数
  const valid = isPositiveInteger(pageNo) && isPositiveInteger(pageCapacity);

  // 不合法返回前端响应
  if (!valid) {
    return invalidParamsRes;
  }

  const user = fetchUserInfo(req);

  const data = {
    pageCapacity,
    pageNo
  };

  const ret = await getSystemInfoReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getSystemInfo);
