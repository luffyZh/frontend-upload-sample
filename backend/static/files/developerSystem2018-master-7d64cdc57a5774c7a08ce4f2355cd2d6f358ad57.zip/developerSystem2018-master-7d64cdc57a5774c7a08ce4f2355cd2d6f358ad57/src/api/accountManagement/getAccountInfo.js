import { getAccountInfoReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getAccountInfo = async req => {
  const {
    _accessId: accessId
  } = req;

  const user = fetchUserInfo(req);

  const ret = await getAccountInfoReducer(accessId, user, parseInt(user.developerId, 10));
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAccountInfo);
