import { changeSelfTestDeviceStatusReducer } from '../atomicRequest/accountManagement';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  const payload = {
    success: ret.success
  };
  return payload;
}

const getSelfTestDeviceList = async req => {
  const {
    _accessId: accessId,
    query: {
      ids,
      status
    }
  } = req;

  const data = {
    ids,
    status: parseInt(status, 10)
  };

  const user = fetchUserInfo(req);
  
  const ret = await changeSelfTestDeviceStatusReducer(accessId, user, data);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getSelfTestDeviceList);
