import { javaHost } from '../config';

const javaServer = `http://${javaHost}`;
const apiVersion = 'v1.0.0';
const apiServer = `${javaServer}/${apiVersion}`;

export default {
  /**
   * 特殊登录接口，需要加密后的密码
   * @method POST
   * @param {Long} developerId
   * @param {String} password md5 加密后的 password
   */
  specialLogin: `${apiServer}/developers/login-with-token`,
  /**
   * 正常登录接口，用户名密码登录
   * @method POST
   */
  authorization: `${apiServer}/developers/authorization`,

  // ============== 应用管理部分接口 ================= /

  /**
   * 获取广告的整体数据
   * @method GET
   * @param {String} timePeroidType 单选range,simpleTimePeriod, range需要填开始或结束时间
   * @param {String} simpleTimePeriod 单选today,yesterday,last7days, last14days,last30days等
   * @param {String} beginDateField 开始日期，yyyy-MM-dd
   * @param {String} endDateField 结束日期，yyyy-MM-dd
   * @param {String} pageSize 每页容量，当查询天数过多时最好指定，否则默认会全部查出
   * @param {String} pageNo 第几页，默认为1
   *
   */
  adStats: `${apiServer}/developers/{developerId}/stats`,
  /**
   * 获取应用管理列表
   * @method POST
   */
  getAppEntityList: `${apiServer}/apps`,
  /**
   * 新建应用
   * @method POST
   */
  createNewApp: `${apiServer}/apps`,
  /**
   * 获取广告位列表
   * @method GET
   */
  getAdSlotEntityList: `${apiServer}/slots`,
  /**
   * 新建广告位
   * @method POST
   */
  createNewAdPos: `${apiServer}/slots`,
  /**
   * 编辑广告位
   * @method PUT
   */
  editAdPos: `${apiServer}/slots/{slotUdid}`,
  /**
   * 批量更新App状态信息
   * @method PATCH
   */
  updateAppStatus: `${apiServer}/apps/batch-status`,
  /**
   * 批量更新Slot状态信息
   * @method PATCH
   */
  updateSlotStatus: `${apiServer}/slots/batch-status`,
  /**
   * 获取应用分类
   * @method GET
   */
  getAppCategories: `${apiServer}/categories`,
  /**
   * 获取应用列表数据部分内容
   * @method GET
   */
  getAppStatisticList: `${apiServer}/statistic/app-data`,
  /**
   * 获取广告位列表数据部分接口
   * @method GET
   */
  getSlotStatisticList: `${apiServer}/statistic/slot-data`,
  /**
   * 根据应用id获取应用名称
   * @method GET
   * @param appId 应用id
   */
  getAppNameById: `${apiServer}/apps/{appId}/name`,
  /**
   * 新建广告位获取预设模板
   * @method GET
   */
  getStandardTemplates: `${apiServer}/preset-data/standard-schema-templates`,
  /**
   * 新建广告位获取预设元素
   * @method GET
   */
  getStandardElements: `${apiServer}/preset-data/optional-standard-elements`,
  /**
   *  根据id获取广告位信息 
   * @method GET
   * @param slotUdid 广告位id 
   */
  getAdSlotInfo: `${apiServer}/slots/{slotUdid}`,
  /**
   * 获取广告位审核信息
   */
  getAdSlotAuditInfo: `${apiServer}/slots/{slotUdid}/audit-info`,
  /**
   * 上传各种截图信息
   * @method POST
   */
  uploadSlotImageAuditSource: `${apiServer}/images`,
  /**
   * 上传审核安装包信息
   * @method POST
   * @param slotUdid 广告位id
   */
  uploadSlotPackageAuditSource: `${apiServer}/slots/{slotUdid}/audit-info/app-package`,
  /**
   * 下载安装包
   * @method GET
   * @param slotUdid 广告位id
   */
  downloadAdSlotAppPackage: `${apiServer}/slots/{slotUdid}/audit-info/app-package`,
  /**
   * 广告位提交审核
   * @method POST
   * @param slotUdid 广告位id
   */
  postAdSlotAudit: `${apiServer}/slots/{slotUdid}/to-audit`,
  /**
   * 修改广告位样式状态
   * @method PATCH
   * @param slotUdid 广告位id
   * @param styleId 样式id
   */
  updateAdSlotStyleStatus: `${apiServer}/slots/{slotUdid}/styles/{styleId}/op-status`,
  /**
   * 生成自测物料
   * @method POST
   */
  generateSelfTestMaterial: `${apiServer}/slots/{slotUdid}/generate-self-test-material`,

  // ============== 账户管理部分接口 ================= /

  /**
   * 获取用户自测设备列表
   * @method GET
   */
  getSelfTestDeviceList: `${apiServer}/self-test-devices`,
  /**
   * 修改设备状态信息
   * @method GET
   */
  changeSelfTestDeviceStatus: `${apiServer}/self-test-devices/batch-status`,
  /**
   * 增加自测设备信息
   * @method POST
   */
  addSelfTestDevice: `${apiServer}/self-test-devices`,
  /**
   * 获取用户信息
   * @method GET
   * @param developerId 用户developerId
   */
  getAccountInfo: `${apiServer}/developers/{developerId}`,
  /**
   * 更新用户信息
   * @method PUT
   * @param developerId 用户developerId
   */
  updateAccountInfo: `${apiServer}/developers/{developerId}`,
  /**
   * 更新设备备注信息
   * @method PUT
   * @param deviceId
   */
  updateDeviceInfo: `${apiServer}/self-test-devices/{deviceId}`,
  /**
   * 获取消息中心
   * @method GET
   * @param developerId
   */
  getSystemInfo: `${apiServer}/developers/{developerId}/messages`,
  /**
   * 更新消息中心消息状态
   * @method PATCH
   * @param developerId
   * @param messageId
   */
  updateSystemInfo: `${apiServer}/developers/{developerId}/messages/{messageId}`,
  /**
   * 获取未读消息
   * @param developerId
   */
  getUnreadMessage: `${apiServer}/developers/{developerId}/messages/count`,

  // ============== 数据报表部分接口 ================= /

  /**
   * 获取账户报表账户数据
   * @method GET
   */
  getDeveloperReportData: `${apiServer}/report/developer`,
  /**
   * 获取账户报表应用数据
   * @method GET
   */
  getDeveloperAppReportData: `${apiServer}/report/apps`,
  /**
   * 获取账户报表广告位数据
   * @method GET
   */
  getDeveloperSlotReportData: `${apiServer}/report/slots`,
  /**
   * 获取样式数据
   */
  getDeveloperSchemaReportData: `${apiServer}/report/schemas`,
  /**
   * 下载账户报表账户数据
   * @method GET
   */
  downloadDeveloperReportData: `${apiServer}/report/developer/excel`,
  /**
   * 下载账户报表应用数据
   * @method GET
   */
  downloadDeveloperAppReportData: `${apiServer}/report/apps/excel`,
  /**
   * 下载账户报表广告位数据
   * @method GET
   */
  downloadDeveloperSlotReportData: `${apiServer}/report/slots/excel`,
  /**
   * 下载样式报表数据
   * @method GET
   */
  downloadDeveloperSchemaReportData: `${apiServer}/report/schemas/excel`,
  /**
   * 获取slots cascading list
   * @method GET
   */
  getDataReportCascadingSlotsMenuList: `${apiServer}/slots/names`,
  /**
   * 获取apps cascading list
   * @method GET
   */
  getDataReportCascadingAppsMenuList: `${apiServer}/apps/names`,
  /**
   * 获取应用下的所有广告位名称
   * @method GET
   */
  getSelectedMenuList: `${apiServer}/apps/slots`,

  // ============== 注册组件部分接口 ================= /
  /**
   * 提交用户注册信息
   * @method POST
   */
  postRegisterInfo: `${apiServer}/developers`,
  /**
   * 激活用户
   * @method GET
   */
  getActivation: `${apiServer}/developers/activation`,
  /**
   * 发送激活邮件
   * @method GET
   */
  getActiveEmail: `${apiServer}/developers/active-mail`,
  // ============== 聚合SDK接口 ================= /
  /**
   * 获取广告位列表
   * @method GET
   */
  getAdSlotList: `${apiServer}/mediation-sdk-slots`,
  /**
   * 删除广告位列表
   * @method DELETE
   * @param mediationSdkSlotUid 广告位id
   */
  deleteSlotList: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}`,
  /**
   * 新增广告位
   * @method POST
   */
  addSlotList: `${apiServer}/mediation-sdk-slots`,
  /**
   * 编辑广告位名称
   * @method POST
   */
  editSlotName: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}`,
  /**
   * 获取优先级列表
   * @method GET
   */
  getAdvertisingList: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings`,
  /**
   * 删除优先级列表
   * @method DELETE
   * @param settingId 优先级配置id
   */
  deleteAdvertisingList: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings/{settingId}`,
  /**
   * 优先级移动
   * @method PUT
   */
  upSetPriority: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings/priorities`,
  /**
   * 获取优先级配置列表
   * @method GET
   */
  getPriorityList: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings/{settingId}`,
  /**
   * 编辑优先级配置列表
   * @method POST
   */
  editPriorityConfig: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings/{settingId}`,
  /**
   * 新建优先级配置列表
   * @method POST
   */
  addPriorityConfig: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/priority-settings`,
  /**
   * 获取系统版本，APP版本，渠道号等可选项列表
   * @method GET
   */
  getOptionList: `${apiServer}/mediation-sdk-slots/priority-setting-options`,
  /**
   * 增加或删除可选项
   * @method POST
   */
  changeEditModalValue: `${apiServer}/mediation-sdk-slots/priority-setting-options`,
  /**
   * 获取语言列表
   * @method GET
   */
  getLanguageList: `${apiServer}/languages`,
  /**
   * 获取国家列表
   * @method GET
   */
  getCountryList: `${apiServer}/countries`,

  /**
   * 获取平台优先级配置下拉列表
   * @method GET
   */
  getDetailsInfo: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/platform-priority-names`,
  /**
   * 获取平台优先级配置列表
   * @method GET
   */
  getPlatformList: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/platform-priorities`,
  /**
   * 新建平台优先级配置
   * @method POST
   */
  addPlatformPriority: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/platform-priorities`,
  /**
   * 编辑平台优先级配置
   * @method POST
   */
  editPlatformPriority: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/platform-priorities/{platformPriorityId}`,
  /**
   * 删除平台优先级配置
   * @method DELETE
   */
  deletePlatformPriority: `${apiServer}/mediation-sdk-slots/{mediationSdkSlotUid}/platform-priorities/{platformPriorityId}`
};



