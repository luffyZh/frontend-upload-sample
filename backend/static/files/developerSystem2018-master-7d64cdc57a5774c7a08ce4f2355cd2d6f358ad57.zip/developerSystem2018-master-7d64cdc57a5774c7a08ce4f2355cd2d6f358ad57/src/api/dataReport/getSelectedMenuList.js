import { getSelectedMenuListReducer } from '../atomicRequest/dataReport';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getSelectedMenuList = async req => {
  const {
    _accessId: accessId,
    query: {
      appIds
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getSelectedMenuListReducer(accessId, user, appIds);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getSelectedMenuList);
