import { getDeveloperReportDataReducer } from '../atomicRequest/dataReport';
import { tryCatch } from '../helper';
import {
  fetchUserInfo,
  generateDeveloperReportQuery,
  getDateAll
} from '../../core/utils';

function handleResData(ret, startDate, endDate) {
  const dateArr = getDateAll(startDate, endDate);
  const { summaryList } = ret;
  const zeroData = {
    requestAdNum: 0,
    bid: 0,
    bidRate: '0.00%',
    imprRate: '0.00%',
    date: '',
    clickRate: '0.00%',
    impr: 0,
    click: 0
  };
  const isDayDate = startDate === endDate;
  if (!isDayDate) {
    dateArr.forEach(date => {
      if (!summaryList.map(item => item.date).includes(date)) {
        summaryList.push({ ...zeroData, date });
      }
    });
  } else {
    for (let i = 0; i < 24; i++) {
      if (!summaryList.map(item => parseInt(item.date)).includes(i)) {
        summaryList.push({ ...zeroData, date: i });
      }
    }
    summaryList.forEach(item => item.date = parseInt(item.date, 10));
  }
  return ret;
}

const getDeveloperReportData = async req => {
  const {
    _accessId: accessId,
    query: {
      tabType,
      startDate,
      endDate
    }
  } = req;

  const user = fetchUserInfo(req);
  
  // 如果是按天查询， 聚合方式改变成hour
  if (startDate === endDate) {
    req.query.aggregate = 'hour';
  }

  const data = generateDeveloperReportQuery(tabType, req.query);

  const ret = await getDeveloperReportDataReducer(accessId, user, data, tabType);
  const resData = handleResData(ret, startDate, endDate);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getDeveloperReportData);
