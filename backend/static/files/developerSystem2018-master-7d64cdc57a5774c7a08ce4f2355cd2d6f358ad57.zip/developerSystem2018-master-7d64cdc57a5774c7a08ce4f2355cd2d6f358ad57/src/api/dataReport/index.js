import { Router } from 'express';
import getDeveloperReportData from './getDeveloperReportData';
import downloadReportData from './downloadReportData';
import getDataReportCascadingMenuList from './getDataReportCascadingMenuList';
import getSelectedMenuList from './getSelectedMenuList';

const router = new Router();

// 获取数据报表数据
router.get('/getDeveloperReportData', getDeveloperReportData);
// 下载数据报表数据
router.get('/downloadReportData', downloadReportData);
// 获取cascading list 数据
router.get('/getDataReportCascadingMenuList', getDataReportCascadingMenuList);
// 获取自定义列表初始化已选List
router.get('/getSelectedMenuList', getSelectedMenuList);

export default router;
