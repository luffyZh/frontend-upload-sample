import { getDataReportCascadingMenuListReducer } from '../atomicRequest/dataReport';
import { tryCatch } from '../helper';
import {
  fetchUserInfo
} from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getDataReportCascadingMenuList = async req => {
  const {
    _accessId: accessId,
    query: {
      pageNo,
      pageCapacity,
      keyword = '',
      tabType
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const data = {
    pageNo,
    pageCapacity,
    keyword
  };

  const ret = await getDataReportCascadingMenuListReducer(accessId, user, data, tabType);
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getDataReportCascadingMenuList);
