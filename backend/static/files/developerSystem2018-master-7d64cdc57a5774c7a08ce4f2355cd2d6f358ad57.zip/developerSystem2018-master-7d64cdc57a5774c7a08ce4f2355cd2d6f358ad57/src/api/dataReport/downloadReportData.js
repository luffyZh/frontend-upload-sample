import excel from 'node-xlsx';
import { downloadReportDataReducer } from '../atomicRequest/dataReport';
import {
  tryCatch,
  invalidParamsRes
} from '../helper';
import {
  isValidDate,
  fetchUserInfo,
  generateDataReportTableHeader,
  generateDataReportTableBody
} from '../../core/utils';
import { DataReportExcelName } from '../../constants/MenuTypes';

const downloadReportData = async req => {
  const {
    _accessId: accessId,
    query: {
      startDate,
      endDate,
      aggregate,
      id = '',
      ids = '',
      type
    }
  } = req;

  const user = fetchUserInfo(req);

  const isValidStartDate = isValidDate(startDate);
  const isValidEndDate = isValidDate(endDate);

  if (!isValidStartDate
    || !isValidEndDate
    || startDate > endDate
  ) {
    return invalidParamsRes;
  }

  const data = {
    startDate,
    endDate,
    aggregate,
    id,
    ids
  };

  const ret = await downloadReportDataReducer(accessId, user, data, type);

  const tableHeader = generateDataReportTableHeader(type);

  const dateRange = `${startDate} ~ ${endDate}`;

  const tableBody = generateDataReportTableBody(type, ret, aggregate, dateRange);

  const filename = `${DataReportExcelName[type]}_${startDate}_${endDate}.xlsx`;
  // eslint-disable-next-line
  const buffer = excel.build([{ name: '表1', data: [tableHeader].concat(tableBody) }]);

  return {
    content: {
      resData: buffer,
      filename
    }
  };
};

export default tryCatch(downloadReportData);
