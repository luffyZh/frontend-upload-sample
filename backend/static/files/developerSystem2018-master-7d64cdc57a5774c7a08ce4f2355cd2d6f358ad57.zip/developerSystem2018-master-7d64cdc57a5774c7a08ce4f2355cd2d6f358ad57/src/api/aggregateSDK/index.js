import { Router } from 'express';
import getAdSlotList from './getAdSlotList';
import getLanguageList from './getLanguageList';
import getCountryList from './getCountryList';
import deleteSlotList from './deleteSlotList';
import addSlotList from './addSlotList';
import getAdvertisingList from './getAdvertisingList';
import deleteAdvertisingList from './deleteAdvertisingList';
import editSlotName from './editSlotName';
import upSetPriority from './upSetPriority';
import getPriorityList from './getPriorityList';
import getPlatformList from './getPlatformList';
import addPlatformPriority from './addPlatformPriority';
import editPlatformPriority from './editPlatformPriority';
import deletePlatformPriority from './deletePlatformPriority';
import getDetailsInfo from './getDetailsInfo';
import getOptionList from './getOptionList';
import changeEditModalValue from './changeEditModalValue';
import editPriorityConfig from './editPriorityConfig';
import addPriorityConfig from './addPriorityConfig';

const router = new Router();

// 获取广告位列表
router.get('/getAdSlotList', getAdSlotList);

// 删除广告位列表
router.delete('/deleteSlotList/:mediationSdkSlotUid', deleteSlotList);

// 新增广告位
router.post('/addSlotList', addSlotList);

// 编辑广告位名称
router.post('/editSlotName/:mediationSdkSlotUid', editSlotName);

// 获取优先级列表
router.get('/getAdvertisingList/:mediationSdkSlotUid', getAdvertisingList);

// 删除优先级列表
router.delete('/deleteAdvertisingList/:mediationSdkSlotUid/:settingId', deleteAdvertisingList);

// 优先级移动
router.put('/upSetPriority', upSetPriority);

// 获取优先级配置列表
router.get('/getPriorityList/:mediationSdkSlotUid/:settingId', getPriorityList);

// 编辑优先级配置列表
router.post('/editPriorityConfig/:mediationSdkSlotUid/:settingId', editPriorityConfig);

// 新建优先级配置列表
router.post('/addPriorityConfig/:mediationSdkSlotUid', addPriorityConfig);

// 获取系统版本，APP版本，渠道号等可选项列表
router.get('/getOptionList', getOptionList);

// 增加或删除可选项
router.post('/changeEditModalValue', changeEditModalValue);

// 获取语言列表
router.get('/getLanguageList', getLanguageList);

// 获取国家列表
router.get('/getCountryList', getCountryList);

// 获取平台优先级配置下拉列表
router.get('/getDetailsInfo/:mediationSdkSlotUid', getDetailsInfo);

// 获取平台优先级配置列表
router.get('/getPlatformList/:mediationSdkSlotUid', getPlatformList);

// 新建平台优先级配置
router.post('/addPlatformPriority/:mediationSdkSlotUid', addPlatformPriority);

// 编辑平台优先级配置
router.post('/editPlatformPriority/:mediationSdkSlotUid/:platformPriorityId', editPlatformPriority);

// 删除平台优先级配置
router.delete('/deletePlatformPriority/:mediationSdkSlotUid/:platformPriorityId', deletePlatformPriority);

export default router;