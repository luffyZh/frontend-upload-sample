import { deletePlatformPriorityReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const deletePlatformPriority = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      platformPriorityId
    }
  } = req;
    
  const user = fetchUserInfo(req);

  const data = { 
    mediationSdkSlotUid,
    platformPriorityId 
  };

  const ret = await deletePlatformPriorityReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(deletePlatformPriority);