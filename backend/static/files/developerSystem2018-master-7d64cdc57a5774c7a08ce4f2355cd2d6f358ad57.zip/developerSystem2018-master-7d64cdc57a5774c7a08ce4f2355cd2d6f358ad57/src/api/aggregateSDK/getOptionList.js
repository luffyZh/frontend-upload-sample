import { getOptionListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getOptionList = async req => {
  const {
    _accessId: accessId,
    query: {
      optionType
    }
  } = req;

  const data = {
    optionType
  };
  
  const user = fetchUserInfo(req);
  
  const ret = await getOptionListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getOptionList);