import { addPlatformPriorityReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const addPlatformPriority = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      platformPriorityName,
      platformInfo
    }
  } = req;

  const data = { 
    mediationSdkSlotUid,
    platformPriorityName,
    platformInfo: JSON.parse(platformInfo)
  };

  const user = fetchUserInfo(req);

  const ret = await addPlatformPriorityReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(addPlatformPriority);