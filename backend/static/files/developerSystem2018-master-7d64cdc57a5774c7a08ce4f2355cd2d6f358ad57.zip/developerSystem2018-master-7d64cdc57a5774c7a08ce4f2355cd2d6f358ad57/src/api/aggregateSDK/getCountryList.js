import { getCountryListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getCountryList = async req => {
  const {
    _accessId: accessId
  } = req;
  
  const user = fetchUserInfo(req);
  
  const ret = await getCountryListReducer(accessId, user);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getCountryList);