import { getAdSlotListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    total:ret.total,
    list: ret.resultList
  };
  return payload;
}

const getAdSlotList = async req => {
  const {
    _accessId: accessId,
    query: {
      pageNo,
      pageCapacity
    }
  } = req;

  const data = {
    pageNo,
    pageCapacity
  };

  
  const user = fetchUserInfo(req);
  
  const ret = await getAdSlotListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAdSlotList);