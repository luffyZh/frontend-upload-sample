import { upSetPriorityReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const upSetPriority = async req => {
  const {
    _accessId: accessId,
    query: {
      upSettingId,
      upPriority,
      downSettingId,
      downPriority
    }
  } = req;
    
  const user = fetchUserInfo(req);

  const data = { 
    upSettingId,
    upPriority,
    downSettingId,
    downPriority
  };

  const ret = await upSetPriorityReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(upSetPriority);