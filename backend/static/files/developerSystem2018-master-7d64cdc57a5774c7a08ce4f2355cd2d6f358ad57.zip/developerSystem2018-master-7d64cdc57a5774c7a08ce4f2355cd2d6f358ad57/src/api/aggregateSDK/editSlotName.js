import { editSlotNameReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const editSlotName = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotName,
      mediationSdkSlotUid
    }
  } = req;

  const data = { 
    mediationSdkSlotName,
    mediationSdkSlotUid
  };

  const user = fetchUserInfo(req);

  const ret = await editSlotNameReducer(accessId, user, data);
  
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(editSlotName);