import { getDetailsInfoReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const getDetailsInfo = async req => {
  const {
    _accessId: accessId,
    params: {
      mediationSdkSlotUid
    }
  } = req;

  const data = {
    mediationSdkSlotUid
  };

  const user = fetchUserInfo(req);
  
  const ret = await getDetailsInfoReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getDetailsInfo);