import { deleteSlotListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const deleteSlotList = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid
    }
  } = req;
    
  const user = fetchUserInfo(req);

  const data = { mediationSdkSlotUid };

  const ret = await deleteSlotListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      data: resData
    }
  };
};

export default tryCatch(deleteSlotList);
