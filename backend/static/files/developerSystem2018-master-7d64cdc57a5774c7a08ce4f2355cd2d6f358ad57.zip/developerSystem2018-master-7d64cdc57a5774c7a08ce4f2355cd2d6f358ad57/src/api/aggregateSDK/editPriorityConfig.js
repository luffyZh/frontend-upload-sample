import { editPriorityConfigReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const editPriorityConfig = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      settingId,
      prioritySettingData
    }
  } = req;

  const data = { 
    mediationSdkSlotUid,
    settingId,
    prioritySettingData: JSON.parse(prioritySettingData)
  };

  const user = fetchUserInfo(req);

  const ret = await editPriorityConfigReducer(accessId, user, data);
  
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(editPriorityConfig);