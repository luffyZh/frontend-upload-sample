import { addPriorityConfigReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const addPriorityConfig = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      prioritySettingData
    }
  } = req;

  const data = { 
    mediationSdkSlotUid,
    prioritySettingData: JSON.parse(prioritySettingData)
  };

  const user = fetchUserInfo(req);

  const ret = await addPriorityConfigReducer(accessId, user, data);
  
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(addPriorityConfig);