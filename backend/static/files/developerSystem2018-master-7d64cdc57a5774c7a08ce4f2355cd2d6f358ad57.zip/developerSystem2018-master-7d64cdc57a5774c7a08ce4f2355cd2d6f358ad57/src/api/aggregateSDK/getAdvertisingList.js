import { getAdvertisingListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    advertisingList: ret.prioritySettings,
    mediationSdkSlotName: ret.mediationSdkSlotName
  };
  return payload;
}

const getAdvertisingList = async req => {
  const {
    _accessId: accessId,
    params: {
      mediationSdkSlotUid
    }
  } = req;

  const user = fetchUserInfo(req);
  
  const ret = await getAdvertisingListReducer(accessId, user, mediationSdkSlotUid);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getAdvertisingList);