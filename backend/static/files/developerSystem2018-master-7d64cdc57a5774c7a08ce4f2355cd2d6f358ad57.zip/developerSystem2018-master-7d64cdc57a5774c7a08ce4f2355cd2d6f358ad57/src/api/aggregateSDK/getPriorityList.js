import { getPriorityListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    priorityList: ret,
    mediationSdkSlotUid: ret.mediationSdkSlotUid
  };
  return payload;
}

const getPriorityList = async req => {
  const {
    _accessId: accessId,
    params: {
      mediationSdkSlotUid,
      settingId
    }
  } = req;

  const data = {
    mediationSdkSlotUid,
    settingId
  };
  
  const user = fetchUserInfo(req);
  
  const ret = await getPriorityListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getPriorityList);