import { addSlotListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  const payload = {
    mediationSdkSlotUid: ret
  };
  return payload;
}

const addSlotList = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotName
    }
  } = req;

  const data = { mediationSdkSlotName };
  
  const user = fetchUserInfo(req);

  const ret = await addSlotListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(addSlotList);