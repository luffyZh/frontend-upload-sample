import { deleteAdvertisingListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const deleteAdvertisingList = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      settingId
    }
  } = req;
    
  const user = fetchUserInfo(req);

  const data = { 
    mediationSdkSlotUid,
    settingId 
  };

  const ret = await deleteAdvertisingListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      data: resData
    }
  };
};

export default tryCatch(deleteAdvertisingList);