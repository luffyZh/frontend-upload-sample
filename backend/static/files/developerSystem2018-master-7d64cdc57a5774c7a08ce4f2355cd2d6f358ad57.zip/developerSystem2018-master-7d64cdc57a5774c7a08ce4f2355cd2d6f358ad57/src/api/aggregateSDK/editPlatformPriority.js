import { editPlatformPriorityReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const editPlatformPriority = async req => {
  const {
    _accessId: accessId,
    body: {
      mediationSdkSlotUid,
      platformPriorityId,
      platformPriorityName,
      platformInfo
    }
  } = req;

  const data = { 
    mediationSdkSlotUid,
    platformPriorityId,
    platformPriorityName,
    platformInfo: JSON.parse(platformInfo)
  };

  const user = fetchUserInfo(req);

  const ret = await editPlatformPriorityReducer(accessId, user, data);
  
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(editPlatformPriority);