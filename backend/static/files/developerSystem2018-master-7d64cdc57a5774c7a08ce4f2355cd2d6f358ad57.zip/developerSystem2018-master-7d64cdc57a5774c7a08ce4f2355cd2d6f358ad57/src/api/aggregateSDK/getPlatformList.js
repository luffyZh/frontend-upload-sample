import { getPlatformListReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';
import { dataSourceMap } from '../../constants/MenuTypes';

function handleResData(ret) {
  const payload = {
    mediationSdkSlotName: ret.mediationSdkSlotName,
    platformPriorities: dataSourceMap(ret.platformPriorities, {editStatus: false}, {newAdd: false})
  };
  return payload;
}

const getPlatformList = async req => {
  const {
    _accessId: accessId,
    params: {
      mediationSdkSlotUid
    }
  } = req;

  const data = {
    mediationSdkSlotUid
  };

  const user = fetchUserInfo(req);
  
  const ret = await getPlatformListReducer(accessId, user, data);

  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
};

export default tryCatch(getPlatformList);