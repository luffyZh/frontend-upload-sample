import { changeEditModalValueReducer } from '../atomicRequest/aggregateSDK';
import { tryCatch } from '../helper';
import { fetchUserInfo } from '../../core/utils';

function handleResData(ret) {
  return ret;
}

const changeEditModalValue = async req => {
  const {
    _accessId: accessId,
    query: {
      optionType,
      toDeleteIds,
      toAddValues
    }
  } = req;

  const data = { 
    optionType,
    toDeleteIds,
    toAddValues
  };

  const user = fetchUserInfo(req);

  const ret = await changeEditModalValueReducer(accessId, user, data);
  
  const resData = handleResData(ret);
  return {
    content: {
      resData
    }
  };
  
};

export default tryCatch(changeEditModalValue);