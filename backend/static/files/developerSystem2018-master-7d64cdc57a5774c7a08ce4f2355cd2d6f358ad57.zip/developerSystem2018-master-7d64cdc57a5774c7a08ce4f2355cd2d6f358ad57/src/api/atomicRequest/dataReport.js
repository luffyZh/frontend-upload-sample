import api from '../apiDefOfBE';
import http from '../../core/HttpServer';
import { DataReportApiMap, DownloadDataReportApiMap, DataReportTabs } from '../../constants/MenuTypes';

export const getDeveloperReportDataReducer = (accessId, params, data, tabType) =>
  http.get(api[DataReportApiMap[tabType]], {
    accessId,
    params,
    query: {
      ...data
    }
  });

export const downloadReportDataReducer = (accessId, params, data, tabType) =>
  http.get(api[DownloadDataReportApiMap[tabType]], {
    accessId,
    params,
    query: {
      ...data
    }
  });

export const getDataReportCascadingMenuListReducer = (accessId, params, data, tabType) =>
  tabType !== DataReportTabs.应用
    ? http.get(api.getDataReportCascadingSlotsMenuList, {
      accessId,
      params,
      query: {
        pageNo: data.pageNo,
        pageCapacity: data.pageCapacity,
        keyword: data.keyword
      }
    }) : http.get(api.getDataReportCascadingAppsMenuList, {
      accessId,
      params,
      query: {
        pageNo: data.pageNo,
        pageCapacity: data.pageCapacity,
        keyword: data.keyword
      }
    });

export const getSelectedMenuListReducer = (accessId, params, data) =>
  http.get(api.getSelectedMenuList, {
    accessId,
    params,
    query: {
      appIds: data
    }
  });