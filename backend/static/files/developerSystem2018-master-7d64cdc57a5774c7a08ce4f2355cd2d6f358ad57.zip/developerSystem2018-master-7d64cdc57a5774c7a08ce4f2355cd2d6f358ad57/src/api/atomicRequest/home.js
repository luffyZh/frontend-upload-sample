import api from '../apiDefOfBE';
import http from '../../core/HttpServer';

export const getAdStats = (accessId, params, data) =>
  http.get(api.adStats, {
    accessId,
    params,
    query: {
      timePeroidType: 'range',
      beginDateField: data.dateRange[0],
      endDateField: data.dateRange[1]
    }
  });

export const getRegionList = (accessId, params, data) =>
  http.get(api.regionList, {
    accessId,
    params,
    query: {
      keyword: data.keyword
    }
  });
