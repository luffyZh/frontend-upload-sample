import api from '../apiDefOfBE';
import http from '../../core/HttpServer';

export const getAdSlotListReducer = (accessId, params, data) =>
  http.get(api.getAdSlotList, {
    accessId,
    params,
    query: {
      pageNo: data.pageNo,
      pageCapacity: data.pageCapacity
    }
  });

export const deleteSlotListReducer = (accessId, params, data) =>
  http.delete(api.deleteSlotList, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    }
  });

export const addSlotListReducer = (accessId, params, data) =>
  http.post(api.addSlotList, {
    accessId,
    params,
    data
  });

export const editSlotNameReducer = (accessId, params, data) =>
  http.post(api.editSlotName, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    },
    query: {
      mediationSdkSlotName: data.mediationSdkSlotName
    }
  });

export const getAdvertisingListReducer = (accessId, params, mediationSdkSlotUid) =>
  http.get(api.getAdvertisingList, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid
    }
  });

export const deleteAdvertisingListReducer = (accessId, params, data) =>
  http.delete(api.deleteAdvertisingList, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid,
      settingId: data.settingId
    }
  });

export const upSetPriorityReducer = (accessId, params, data) =>
  http.put(api.upSetPriority, {
    accessId,
    params,
    query: {
      upSettingId: data.upSettingId,
      upPriority: data.upPriority,
      downSettingId: data.downSettingId,
      downPriority: data.downPriority
    }
  });

export const getPriorityListReducer = (accessId, params, data) =>
  http.get(api.getPriorityList, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid,
      settingId: data.settingId
    }
  }
  );

export const getLanguageListReducer = (accessId, params) =>
  http.get(api.getLanguageList, {
    accessId,
    params
  }
  );

export const getCountryListReducer = (accessId, params) =>
  http.get(api.getCountryList, {
    accessId,
    params
  }
  );

export const getPlatformListReducer = (accessId, params, data) =>
  http.get(api.getPlatformList, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    }
  });

export const addPlatformPriorityReducer = (accessId, params, data) =>
  http.post(api.addPlatformPriority, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    },
    query: {
      platformPriorityName: data.platformPriorityName
    },
    data: JSON.stringify(data.platformInfo) 
  });

export const editPlatformPriorityReducer = (accessId, params, data) =>
  http.post(api.editPlatformPriority, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid,
      platformPriorityId: data.platformPriorityId
    },
    query: {
      platformPriorityName: data.platformPriorityName
    },
    data: JSON.stringify(data.platformInfo)
  });

export const deletePlatformPriorityReducer = (accessId, params, data) =>
  http.delete(api.deletePlatformPriority, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid,
      platformPriorityId: data.platformPriorityId
    }
  });

export const getDetailsInfoReducer = (accessId, params, data) =>
  http.get(api.getDetailsInfo, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    }
  });

export const getOptionListReducer = (accessId, params, data) =>
  http.get(api.getOptionList, {
    accessId,
    params,
    query: {
      optionType: data.optionType
    }
  });

export const changeEditModalValueReducer = (accessId, params, data) =>
  http.post(api.changeEditModalValue, {
    accessId,
    params,
    query: {
      optionType: data.optionType,
      toDeleteIds: data.toDeleteIds,
      toAddValues: data.toAddValues
    }
  });

export const editPriorityConfigReducer = (accessId, params, data) =>
  http.post(api.editPriorityConfig, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid,
      settingId: data.settingId
    },
    data: JSON.stringify(data.prioritySettingData)
  });

export const addPriorityConfigReducer = (accessId, params, data) =>
  http.post(api.addPriorityConfig, {
    accessId,
    params: {
      ...params,
      mediationSdkSlotUid: data.mediationSdkSlotUid
    },
    data: JSON.stringify(data.prioritySettingData)
  });
