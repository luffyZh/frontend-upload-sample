import api from '../apiDefOfBE';
import http from '../../core/HttpServer';

export const getSelfTestDeviceListReducer = (accessId, params, data) => 
  http.get(api.getSelfTestDeviceList, {
    accessId,
    params,
    query: {
      onlyEnabled: data.onlyEnabled
    }
  });

export const changeSelfTestDeviceStatusReducer = (accessId, params, data) => 
  http.get(api.changeSelfTestDeviceStatus, {
    accessId,
    params,
    query: {
      ids: data.ids,
      status: data.status
    }
  });

export const addSelfTestDeviceReducer = (accessId, params, data) =>
  http.post(api.addSelfTestDevice, {
    accessId,
    params,
    data
  });

export const getAccountInfoReducer = (accessId, params, developerId) =>
  http.get(api.getAccountInfo, {
    accessId,
    params: {
      ...params,
      developerId
    }
  });

export const updateAccountInfoReducer = (accessId, params, data) =>
  http.put(api.updateAccountInfo, {
    accessId,
    params,
    query: {
      name: data.name,
      address: data.address,
      phone: data.phone,
      email: data.email
    }
  });

export const updateDeviceInfoReducer = (accessId, params, data) =>
  http.put(api.updateDeviceInfo, {
    accessId,
    params: {
      ...params,
      deviceId: parseInt(data.id, 10)
    },
    query: {
      comment: data.comment
    }
  });

export const getSystemInfoReducer = (accessId, params, data) =>
  http.get(api.getSystemInfo, {
    accessId,
    params,
    query: {
      pageNo: data.pageNo,
      pageCapacity: data.pageCapacity
    }
  });

export const updateSystemInfoReducer = (accessId, params, data) =>
  http.patch(api.updateSystemInfo, {
    accessId,
    params: {
      ...params,
      messageId: data.id
    },
    query: {
      status: data.status
    }
  });

export const getUnreadMessageReducer = (accessId, params) =>
  http.get(api.getUnreadMessage, {
    accessId,
    params,
    query: {
      status: 1
    }
  });