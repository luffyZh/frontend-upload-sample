import api from '../apiDefOfBE';
import http from '../../core/HttpServer';

import {
  AppTabTypes,
  AppOsForBE,
  AppStatusForBE,
  SlotOpStatusForBE,
  SlotAuditStatusForBE,
  SlotStyleForBE
} from '../../constants/MenuTypes';

export const uploadSlotImageAuditSourceReducer = (accessId, params, data) =>
  http.post(api.uploadSlotImageAuditSource, {
    accessId,
    params,
    query: {
      imageName: data.imageName
    },
    data: data.base64
  });

export const uploadSlotPackageAuditSourceReducer = (accessId, params, timeout, data) =>
  http.post(api.uploadSlotPackageAuditSource, {
    accessId,
    params: {
      ...params,
      slotUdid: data.slotUdid,
      uploadFile: true,
      upload: data.packageData
    },
    timeout,
    data: data.packageData
  });

export const queryAppEntityListReducer = (accessId, params, data, subType) => {
  const {
    startDate,
    endDate,
    keyword,
    pageNo,
    pageSize,
    appId,
    appOs,
    appStatus,
    operateStatus,
    auditStatus,
    object
  } = data;
  const query = subType === AppTabTypes.appTab
    ? {
      startDate,
      endDate,
      keyword,
      pageNo: parseInt(pageNo, 10),
      pageCapacity: parseInt(pageSize, 10),
      appOs: AppOsForBE[appOs],
      appStatus: AppStatusForBE[appStatus]
    }
    : {
      startDate,
      endDate,
      keyword,
      pageNo: parseInt(pageNo, 10),
      pageCapacity: parseInt(pageSize, 10),
      appId,
      slotOpStatus: SlotOpStatusForBE[operateStatus],
      slotAuditStatus: SlotAuditStatusForBE[auditStatus],
      slotStyle: SlotStyleForBE[object]
    };

  return (subType === AppTabTypes.appTab)
    ? http.get(api.getAppEntityList, {
      accessId,
      params,
      query
    })
    : http.get(api.getAdSlotEntityList, {
      accessId,
      params,
      query
    });
};

export const getAppAndAdposStatisticListReducer = (accessId, params, data, subType) => {
  const {
    startDate,
    endDate,
    idsList
  } = data;
  let reqList = (typeof idsList === 'string') ? [idsList] : idsList;
  const query = (subType === AppTabTypes.appTab) ? {
    startDate,
    endDate,
    appIds: reqList.join(',')
  } : {
    startDate,
    endDate,
    slotUdids: reqList.join(',')
  };
  return (subType === AppTabTypes.appTab)
    ? http.get(api.getAppStatisticList, {
      accessId,
      params,
      query
    })
    : http.get(api.getSlotStatisticList, {
      accessId,
      params,
      query
    });
};

export const updateAppStatusReducer = (accessId, params, data) =>
  http.patch(api.updateAppStatus, {
    accessId,
    params,
    data
  });

export const updateSlotStatusReducer = (accessId, params, data) =>
  http.patch(api.updateSlotStatus, {
    accessId,
    params,
    data
  });

export const getAppCategoriesReducer = (accessId, params) =>
  http.get(api.getAppCategories, {
    accessId,
    params
  });

export const createNewAppReducer = (accessId, params, data) =>
  http.post(api.createNewApp, {
    accessId,
    params,
    data
  });

export const createNewAdPosReducer = (accessId, params, data) => 
  data.slotUdid
    ? http.put(api.editAdPos, {
      accessId,
      params: {
        ...params,
        slotUdid: data.slotUdid
      },
      data: JSON.stringify(data)
    })
    : http.post(api.createNewAdPos, {
      accessId,
      params,
      data: JSON.stringify(data)
    });

// 根据应用id获取应用名称
export const getAppNameByIdReducer = (accessId, params, appId) =>
  http.get(api.getAppNameById, {
    accessId,
    params: {
      ...params,
      appId: parseInt(appId, 10)
    },
    query: {
      appId: parseInt(appId, 10)
    }
  });

export const getStandardTemplatesReducer = (accessId, params) =>
  http.get(api.getStandardTemplates, {
    accessId,
    params
  });

export const getStandardElementsReducer = (accessId, params) =>
  http.get(api.getStandardElements, {
    accessId,
    params
  });

export const getAdSlotInfoReducer = (accessId, params, slotUdid) =>
  http.get(api.getAdSlotInfo, {
    accessId,
    params: {
      ...params,
      slotUdid
    }
  });

export const getAdSlotAuditInfoReducer = (accessId, params, slotUdid) =>
  http.get(api.getAdSlotAuditInfo, {
    accessId,
    params: {
      ...params,
      slotUdid
    }
  });

export const postAdSlotAuditReducer = (accessId, params, data) =>
  http.post(api.postAdSlotAudit, {
    accessId,
    params: {
      ...params,
      slotUdid: data.slotUdid
    },
    data: JSON.stringify({
      appPackage: data.appPackage,
      styleScreenshots: data.styleScreenshots
    })
  });

export const downloadAdSlotAppPackageReducer = (accessId, params, slotUdid) =>
  http.get(api.downloadAdSlotAppPackage, {
    accessId,
    params: {
      ...params,
      slotUdid
    }
  });

export const updateAdSlotStyleStatusReducer = (accessId, params, data) =>
  http.patch(api.updateAdSlotStyleStatus, {
    accessId,
    params: {
      ...params,
      slotUdid: data.slotUdid,
      styleId: data.styleId
    },
    query: {
      styleOpStatus: data.status
    }
  });

export const generateSelfTestMaterialReducer = (accessId, params, slotUdid) =>
  http.post(api.generateSelfTestMaterial, {
    accessId,
    params: {
      ...params,
      slotUdid
    }
  });