# 说明

本文件夹下的文件是对页面数据请求的耕细粒度的拆分，具体涉及到数据端的接口设计，请参照 [http://nb080x.corp.youdao.com:10017/swagger-ui/index.html#!/v1.0.0](http://nb080x.corp.youdao.com:10017/swagger-ui/index.html#!/v1.0.0)
