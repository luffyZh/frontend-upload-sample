import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Radio, Modal, Input } from 'antd';
import IfComp from 'if-comp';
import _ from 'lodash';
import history from '../../../history';
import CascadingMenuPicker from '../../../components/Common/CascadingMenuPicker';
import {
  DataReportTabs,
  OperationStatus,
  LoadMoreStatusMap,
  DataReportFilterMap
} from '../../../constants/MenuTypes';
import { generateDataReportQueryIds } from '../../../core/utils';

const BASE_FETCH_DATA_NUM = 10;

const RadioGroup = Radio.Group;
const { Search } = Input;

const radioContainerStyle = {
  position: 'absolute',
  right: '10px'
};

const pickerStyle = {
  originMenuWidth: 320,
  selectedMenuWidth: 320,
  totalHeight: 352
};

const searchStyle = {
  width: 318
};

const selectedItemsStyle = {
  color: '#108ee9',
  fontSize: '12px'
};

class RadioComp extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    getDataReportCascadingMenuList: PropTypes.func.isRequired,
    originMenu: PropTypes.object.isRequired,
    onFilterIdsChange: PropTypes.func.isRequired,
    queryCondition: PropTypes.object.isRequired,
    onCascadingPageSizeChange: PropTypes.func.isRequired,
    onCascadingKeywordChange: PropTypes.func.isRequired,
    onSelectedMenuListChange: PropTypes.func.isRequired,
    idsArr: PropTypes.array.isRequired,
    targetId: PropTypes.any.isRequired
  };

  constructor(props) {
    super(props);
    const { queryCondition } = props;
    this.state = {
      radioValue: DataReportFilterMap.全部,
      visible: false,
      originMenuListOpenKeys: [],
      selectedMenuListOpenKeys: [],
      queryCondition,
      noMore: false,
      searchValue: '',
      rollBackSelectedMenuList: []
    };
  }

  componentDidMount() {
    this.props.getDataReportCascadingMenuList(this.props.type, '');
  }

  componentWillReceiveProps(nextProps) {
    const {
      originMenu: { status },
      type
    } = this.props;
    const {
      queryCondition,
      targetId,
      idsArr,
      originMenu: { selectedMenuList }
    } = nextProps;
    const { visible, originMenuListOpenKeys, rollBackSelectedMenuList } = this.state;
    this.setState({
      queryCondition,
      noMore: nextProps.originMenu.list.length === nextProps.originMenu.total,
      radioValue: (idsArr.length > 0 || targetId !== '' || selectedMenuList.length > 0)
        ? DataReportFilterMap.自定义 : DataReportFilterMap.全部,
      originMenuListOpenKeys: (nextProps.queryCondition.keyword.trim() !== ''
        && nextProps.originMenu.list.length > 0)
        ? nextProps.originMenu.list.map(item => item.value) : originMenuListOpenKeys,
      rollBackSelectedMenuList: (!visible && targetId !== '') ? _.cloneDeep(selectedMenuList) : rollBackSelectedMenuList 
    });
    if (visible
      && (status === OperationStatus.load_success
      || status === OperationStatus.load_fail)
      && nextProps.originMenu.status === OperationStatus.initial) {
      this.props.getDataReportCascadingMenuList(this.props.type, '');
    }
    if (nextProps.type !== type) {
      this.props.onSelectedMenuListChange(type, []);
      this.setState({
        originMenuListOpenKeys: [],
        rollBackSelectedMenuList: []
      });
    }
  }

  onChange = ({ target: { value } }) => (
    this.setState({
      radioValue: value,
      visible: value === DataReportFilterMap.自定义
    }, () => {
      if (value === DataReportFilterMap.自定义) {
        this.props.getDataReportCascadingMenuList(this.props.type, '');
      } else {
        this.props.onSelectedMenuListChange(this.props.type, []);
        this.setState({
          originMenuListOpenKeys: []
        });
        history.push(`/developer/dataReport/${this.props.type}`);
      }
    })
  )

  onSelectedListChange = selectedMenuList => this.props.onSelectedMenuListChange(this.props.type, selectedMenuList);

  onOriginMenuListOpenKeysChange = originMenuListOpenKeys => this.setState({ originMenuListOpenKeys });

  onSelectedMenuListOpenKeysChange = selectedMenuListOpenKeys => this.setState({ selectedMenuListOpenKeys });

  onLoadMore = () => {
    const { originMenu: { total } } = this.props;
    const { queryCondition: { pageSize }, visible } = this.state;
    if (!visible) return;
    if (total < (pageSize + 10)) {
      this.setState({
        noMore: true
      }, () => {
        this.props.onCascadingPageSizeChange(total);
      });
      return;
    }
    this.props.onCascadingPageSizeChange(pageSize + BASE_FETCH_DATA_NUM);
  }

  handleOk = () => {
    const {
      type,
      onFilterIdsChange,
      onCascadingKeywordChange,
      originMenu: { selectedMenuList }
    } = this.props;
    if (selectedMenuList.length === 0) {
      this.setState({
        visible: false,
        searchValue: '',
        radioValue: DataReportFilterMap.全部,
        rollBackSelectedMenuList: []
      }, () => {
        onCascadingKeywordChange('');
        this.props.onFilterIdsChange(type, '');
      });
      return;
    }
    const filterIds = generateDataReportQueryIds(type, selectedMenuList);
    this.setState({
      visible: false,
      searchValue: '',
      rollBackSelectedMenuList: _.cloneDeep(selectedMenuList)
    }, () => {
      onFilterIdsChange(type, filterIds);
      onCascadingKeywordChange('');
    });
  }

  handleCancel = () => {
    const { onCascadingKeywordChange, originMenu: { selectedMenuList }, type, onSelectedMenuListChange } = this.props;
    const { rollBackSelectedMenuList } = this.state;
    console.log(rollBackSelectedMenuList);
    if (selectedMenuList.length > 0) {
      this.setState({
        visible: false,
        searchValue: '',
        radioValue: DataReportFilterMap.自定义
      }, () => {
        onCascadingKeywordChange('');
        onSelectedMenuListChange(type, _.cloneDeep(rollBackSelectedMenuList));
      });
    } else {
      this.setState({
        visible: false,
        selectedMenuListOpenKeys: [],
        originMenuListOpenKeys: [],
        searchValue: '',
        radioValue: DataReportFilterMap.全部
      }, () => {
        onCascadingKeywordChange('');
        onSelectedMenuListChange(type, _.cloneDeep(rollBackSelectedMenuList));
      });
    }
  }

  render() {
    const {
      type,
      originMenu,
      onCascadingKeywordChange
    } = this.props;
    const {
      radioValue,
      visible,
      originMenuListOpenKeys,
      selectedMenuListOpenKeys,
      noMore,
      searchValue
    } = this.state;
    const { selectedMenuList, selectedCount } = originMenu;
    return (
      <div style={radioContainerStyle}>
        <span>{type !== DataReportTabs.应用 ? '广告位名称: ' : '应用名称: '}&nbsp;</span>
        <RadioGroup onChange={this.onChange} value={radioValue}>
          <Radio value={DataReportFilterMap.全部}>全部</Radio>
          <Radio value={DataReportFilterMap.自定义}>自定义</Radio>
        </RadioGroup>
        <IfComp
          expression={radioValue === DataReportFilterMap.自定义}
          trueComp={
            <a
              style={selectedItemsStyle}
              onClick={
                () => {
                  this.setState({ visible: true });
                  this.props.getDataReportCascadingMenuList(this.props.type, '');
                }
              }
            >已选&nbsp;{selectedCount}&nbsp;条数据</a>
          }
        />
        <Modal
          title={type !== DataReportTabs.应用 ? '广告位名称' : '应用名称'}
          visible={visible}
          width={690}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Search
            style={searchStyle}
            value={searchValue}
            onChange={
              ({ target: { value } } ) =>
                this.setState({ searchValue: value })
            }
            placeholder={type !== DataReportTabs.应用 ? '请输入应用/广告位名称' : '请输入应用名称'}
            onSearch={
              value => 
                this.setState({ searchValue: value }, () => {
                  onCascadingKeywordChange(value.trim());
                })
            }
          />
          <CascadingMenuPicker
            originHeader={type !== DataReportTabs.应用 ? '广告位名称' : '应用名称'}
            selectedHeader={type !== DataReportTabs.应用 ? '已选广告位名称' : '已选应用名称'}
            actionBar={null}
            originMenu={originMenu}
            selectedMenuList={selectedMenuList}
            originMenuListOpenKeys={originMenuListOpenKeys}
            selectedMenuListOpenKeys={selectedMenuListOpenKeys}
            onSelectedMenuListChange={this.onSelectedListChange}
            onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
            onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
            style={pickerStyle}
            loadMoreStatus={noMore ? LoadMoreStatusMap.没有更多 : LoadMoreStatusMap[originMenu.status]}
            onLoadMore={this.onLoadMore}
          />
        </Modal>
      </div>
    );
  }

}

export default RadioComp;