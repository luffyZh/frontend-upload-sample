import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import { numberFormat } from '../../../core/utils';
import { DataReportTabs } from '../../../constants/MenuTypes';
import Link from '../../../components/Link';
import s from '../index.less';

// numberFormat(2)中的2表示保留两位小数
const formatFloat = numberFormat(2);
const formatInteger = numberFormat(0);

const renderName = type => (text, record) => {
  switch (type) {
    case DataReportTabs.应用: {
      return <IfComp
        expression={record.appName !== '--'}
        trueComp={
          <Link to={`/developer/dataReport/slots/${record.appId}`}>{record.appName || '--'}</Link>
        }
        falseComp={<span>{record.appName}</span>}
      />;
    }
    case DataReportTabs.广告位: {
      return <span>{record.slotName}</span>;
      // <IfComp
      //   expression={record.slotName !== '--'}
      //   trueComp={
      //   <Link to={`/developer/dataReport/schemas/${record.slotUdid}?appId=${record.appId}`}>{record.slotName || '--'}</Link>
      //   }
      //   falseComp={<span>{record.slotName}</span>}
      // />;
    }
    case DataReportTabs.样式: {
      return <span>{record.schemaName}</span>;
    }
    default:
      break;
  } 
};

const TableColumns = {
  titleNav: pageSize => ({
    title: '',
    colSpan: 2,
    dataIndex: 'titleNav',
    key: 'titleNav',
    className: s.total,
    render: (value, row, index) => {
      const obj = {
        props: {}
      };
      if (index === 0) {
        return {
          children: <span>合计</span>,
          props: {
            colSpan: 2
          }
        };
      }
      if (index === 1) {
        obj.children = '时间';
        obj.props.rowSpan = pageSize;
      } else {
        obj.props.rowSpan = 0;
      }
      return obj;
    }
  }),
  date: () => ({
    title: '空标题',
    dataIndex: 'date',
    key: 'date',
    className: s.totalTime,
    colSpan: 0,
    render: (value, row, index) => {
      const obj = {
        children: value,
        props: {}
      };
      if (index === 0) {
        obj.props.colSpan = 0;
      } else {
        obj.props.colSpan = 1;
      }
      return obj;
    }
  }),
  appName: () => ({
    title: '应用名称',
    dataIndex: 'appName',
    key: 'appName',
    className: s.appName,
    render: renderName(DataReportTabs.应用)
  }),
  slotName: () => ({
    title: '广告位名称',
    dataIndex: 'slotName',
    key: 'slotName',
    className: s.slotName,
    render: renderName(DataReportTabs.广告位)
  }),
  schemaName: () => ({
    title: '样式名称',
    dataIndex: 'schemaName',
    key: 'schemaName',
    className: s.schemaName,
    render: renderName(DataReportTabs.样式)
  }),
  requestAdNum: () => ({
    title: '请求广告数',
    dataIndex: 'requestAdNum',
    key: 'requestAdNum',
    className: s.requestAdNum,
    render: formatInteger
  }),
  bid: () => ({
    title: '返回广告数',
    dataIndex: 'bid',
    key: 'bid',
    className: s.bid,
    render: formatInteger
  }),
  bidRate: () => ({
    title: '填充率',
    dataIndex: 'bidRate',
    key: 'bidRate',
    className: s.rate
  }),
  impr: () => ({
    title: '展示数',
    dataIndex: 'impr',
    key: 'impr',
    className: s.impr,
    render: formatInteger
  }),
  imprRate: () => ({
    title: '展示率',
    dataIndex: 'imprRate',
    key: 'imprRate',
    className: s.rate
  }),
  clickNum: () => ({
    title: '点击数',
    dataIndex: 'click',
    key: 'click',
    className: s.click,
    render: formatInteger
  }),
  clickRate: () => ({
    title: '点击率',
    dataIndex: 'clickRate',
    key: 'clickRate',
    className: s.rate
  }),
  estimateClick: () => ({
    title: '估算每次点击收入',
    dataIndex: 'estimateClick',
    key: 'estimateClick',
    className: s.tital,
    render: formatFloat
  }),
  estimateThousandsClick: () => ({
    title: '估算千次展示收入',
    dataIndex: 'estimateThousandsClick',
    key: 'estimateThousandsClick',
    className: s.total,
    render: formatFloat
  }),
  showIncome: () => ({
    title: '展示收入',
    dataIndex: 'showIncome',
    key: 'showIncome',
    className: s.total,
    render: formatFloat
  })
};

export default withStyles(s)(TableColumns);
