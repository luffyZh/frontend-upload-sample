import React, { Component } from 'react';
import PropTypes from 'prop-types';
import asyncComponent from 'rc-async-component';

const DataChart = asyncComponent(() => import('../../../components/Common/DataChart'));

class ChartComp extends Component {
  static propTypes = {
    data: PropTypes.array.isRequired,
    vsIndicator: PropTypes.array.isRequired,
    type: PropTypes.string.isRequired
  }

  render() {
    const { data, vsIndicator, type } = this.props;
    return (
      <DataChart
        moduleType='dataReport'
        vsIndicator={vsIndicator}
        data={data}
        type={type}
      />
    );
  }
}

export default ChartComp;

