/* eslint-disable import/no-extraneous-dependencies */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Table } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import TableColumns from './TableColumns';
import {
  DataReportTabs,
  PageSizeOptions
} from '../../../constants/MenuTypes';
import s from '../index.less';

const getTableColums = (activeTabKey, pageSize) => {
  switch (activeTabKey) {
    case DataReportTabs.账户报表:
      return [
        TableColumns.titleNav(pageSize),
        TableColumns.date(),
        TableColumns.requestAdNum(),
        TableColumns.bid(),
        TableColumns.bidRate(),
        TableColumns.impr(),
        TableColumns.imprRate(),
        TableColumns.clickNum(),
        TableColumns.clickRate()
      ];
    case DataReportTabs.应用:
      return [
        TableColumns.titleNav(pageSize),
        TableColumns.date(),
        TableColumns.appName(),
        TableColumns.requestAdNum(),
        TableColumns.bid(),
        TableColumns.bidRate(),
        TableColumns.impr(),
        TableColumns.imprRate(),
        TableColumns.clickNum(),
        TableColumns.clickRate()
      ];
    case DataReportTabs.广告位:
      return [
        TableColumns.titleNav(pageSize),
        TableColumns.date(),
        TableColumns.slotName(),
        TableColumns.appName(),
        TableColumns.requestAdNum(),
        TableColumns.bid(),
        TableColumns.bidRate(),
        TableColumns.impr(),
        TableColumns.imprRate(),
        TableColumns.clickNum(),
        TableColumns.clickRate()
      ];
    case DataReportTabs.样式:
      return [
        TableColumns.titleNav(pageSize),
        TableColumns.date(),
        TableColumns.schemaName(),
        TableColumns.slotName(),
        TableColumns.appName(),
        TableColumns.impr(),
        TableColumns.clickNum(),
        TableColumns.clickRate()
      ];
    default:
      return [];
  }
};
class TableComp extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    pageNo: PropTypes.number,
    pageSize: PropTypes.number,
    onPageNoChange: PropTypes.func,
    onPageSizeChange: PropTypes.func,
    total: PropTypes.number.isRequired,
    data: PropTypes.array.isRequired
  }

  static defaultProps = {
    pageNo: 1,
    pageSize: 10,
    onPageNoChange: null,
    onPageSizeChange: null
  }

  constructor(props) {
    super(props);
    const {
      type,
      pageNo,
      pageSize,
      total,
      data
    } = props;
    this.state = {
      total,
      pageNo,
      pageSize,
      columns: getTableColums(type, pageSize),
      data
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      pageNo: nextProps.pageNo,
      pageSize: nextProps.pageSize,
      total: nextProps.total,
      data: nextProps.data,
      columns: getTableColums(this.props.type, nextProps.pageSize)
    });
  }
  
  componentDidUpdate() {
    const pageSizeDom = document.querySelector('.ant-pagination-options .ant-select-selection-selected-value');
    if (pageSizeDom) {
      pageSizeDom.innerHTML = `${this.props.pageSize} 条/页`;
    }
  }

  onPageNoChange = pageNo => {
    this.props.onPageNoChange(pageNo);
  }
  onPageSizeChange = (pageNo, pageSize) => {
    this.props.onPageSizeChange(pageNo, pageSize);
  }

  render() {
    const {
      pageNo,
      pageSize,
      columns,
      total,
      data
    } = this.state;
    const virtualTotal = (total + Math.floor(total / pageSize));
    return (
      <div className={s.dataList}>
        <Table
          rowKey={(record, index) => `${index}${record.date}`}
          columns={columns}
          dataSource={data}
          bordered
          loading={false}
          pagination={{
            size: 'small',
            current: pageNo,
            pageSize: (pageSize + 1),
            showSizeChanger: true,
            pageSizeOptions: PageSizeOptions,
            total: virtualTotal,
            onChange: this.onPageNoChange,
            onShowSizeChange: this.onPageSizeChange
          }}
        />
      </div>
    );
  }
}

export default withStyles(s)(TableComp);
