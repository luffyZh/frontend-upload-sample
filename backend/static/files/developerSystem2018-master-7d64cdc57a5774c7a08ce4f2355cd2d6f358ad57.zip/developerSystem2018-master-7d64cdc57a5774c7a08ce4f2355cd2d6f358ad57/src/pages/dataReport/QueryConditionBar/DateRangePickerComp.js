import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import DateRangePicker from '../../../components/Common/QueryDateRangePicker';

const pickerStyle = {
  margin: '0 10px'
};

const DateRangePickerComp = ({ startDate, endDate, onDateRangeChange }) => (
  <Fragment>
    <span>时间范围:</span>
    <DateRangePicker
      style={pickerStyle}
      startDate={startDate}
      endDate={endDate}
      onDateRangeChange={onDateRangeChange}
    />
  </Fragment>
);

DateRangePickerComp.propTypes = {
  startDate: PropTypes.object.isRequired,
  endDate: PropTypes.object.isRequired,
  onDateRangeChange: PropTypes.func.isRequired
};

export default DateRangePickerComp;
