import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Select } from 'antd';
import IfComp from 'if-comp';
import asyncComponent from 'rc-async-component';
import DataRangePickerComp from './DateRangePickerComp';
import RadioComp from './RadioComp';
import { DataReportTabs } from '../../../constants/MenuTypes';
import s from '../index.less';

const SelectComp = asyncComponent(() => import('./SelectComp'), {
  loading: () => (
    <Fragment>
      <span>查询方式:</span>
      <Select style={{ width: 100 }} />
    </Fragment>
  )
});

export class index extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    queryCondition: PropTypes.object.isRequired,
    onDateRangeChange: PropTypes.func.isRequired,
    onQueryMethodChange: PropTypes.func.isRequired,
    originMenu: PropTypes.object.isRequired,
    cascadingQueryCondition: PropTypes.object.isRequired,
    getDataReportCascadingMenuList: PropTypes.func.isRequired,
    onFilterIdsChange: PropTypes.func.isRequired,
    getDeveloperReportData: PropTypes.func.isRequired,
    onCascadingPageSizeChange: PropTypes.func.isRequired,
    onCascadingKeywordChange: PropTypes.func.isRequired,
    onSelectedMenuListChange: PropTypes.func.isRequired
  }

  render() {
    const {
      type,
      queryCondition: { dateRange, aggregate, ids, id },
      onDateRangeChange,
      onQueryMethodChange,
      cascadingQueryCondition,
      originMenu,
      getDataReportCascadingMenuList,
      onFilterIdsChange,
      getDeveloperReportData,
      onCascadingKeywordChange,
      onCascadingPageSizeChange,
      onSelectedMenuListChange
    } = this.props;
    const { startDate, endDate } = dateRange;
    return (
      <Fragment>
        <SelectComp
          type={type}
          value={aggregate}
          onQueryMethodChange={onQueryMethodChange}
        />
        <DataRangePickerComp
          startDate={startDate}
          endDate={endDate}
          onDateRangeChange={onDateRangeChange}
        />
        <IfComp
          expression={type !== DataReportTabs.账户报表}
          trueComp={
            <RadioComp
              type={type}
              idsArr={ids.split(',').filter(e => e !== '')}
              targetId={id}
              originMenu={originMenu}
              queryCondition={cascadingQueryCondition}
              getDataReportCascadingMenuList={getDataReportCascadingMenuList}
              onFilterIdsChange={onFilterIdsChange}
              getDeveloperReportData={getDeveloperReportData}
              onCascadingKeywordChange={onCascadingKeywordChange}
              onCascadingPageSizeChange={onCascadingPageSizeChange}
              onSelectedMenuListChange={onSelectedMenuListChange}
            />
          }
        />
      </Fragment>
    );
  }
}

export default withStyles(s)(index);
