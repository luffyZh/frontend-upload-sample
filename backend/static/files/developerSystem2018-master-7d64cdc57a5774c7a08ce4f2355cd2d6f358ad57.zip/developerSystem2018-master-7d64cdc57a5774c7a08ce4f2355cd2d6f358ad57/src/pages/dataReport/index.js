import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Icon, Button } from 'antd';
import asyncComponent from 'rc-async-component';
import ChartComp from './chartComp';
import QueryConditionBar from './QueryConditionBar';
import TableComp from './tableComp';
import {
  DataReportTabs,
  OperationStatus,
  DataReportAggregateType
} from '../../constants/MenuTypes';
import {
  handleTableReportResData,
  handleChartReportResData
} from '../../core/utils';
import ic_attention from '../../static/images/ic_attention.png';
import s from './index.less';

const selectionBarList = [
  {
    name: 'account',
    title: '账户报表',
    link: '/developer/dataReport/account'
  }, {
    name: 'apps',
    title: '应用',
    link: '/developer/dataReport/apps'
  }, {
    name: 'slots',
    title: '广告位',
    link: '/developer/dataReport/slots'
  }
  // {
  //   name: 'schemas',
  //   title: '样式',
  //   link: '/developer/dataReport/schemas'
  // }
];

const vsIndicator = [{
  name: '展示数',
  value: 'impr'
}, {
  name: '点击数',
  value: 'click'
}, {
  name: '点击率',
  value: 'clickRate',
  unit: '%'
}];

const addIndicator = [
  {
    name: '展示率',
    value: 'imprRate',
    unit: '%'
  }, {
    name: '请求广告数',
    value: 'requestAdNum'
  }, {
    name: '返回广告数',
    value: 'bid'
  }, {
    name: '填充率',
    value: 'bidRate',
    unit: '%'
  }
];

const QueryConditionShape = PropTypes.shape({
  pageSize: PropTypes.number.isRequired,
  pageNo: PropTypes.number.isRequired,
  dateRange: PropTypes.object.isRequired
});

const SelectionBar = asyncComponent(() => import('../../components/Common/SelectionBar'), {
  loading: () => <div style={{ width: 200, marginTop: 44 }}>
    {
      selectionBarList.map(item => (
        <div
          style={{
            paddingLeft: 40,
            height: 42,
            fontSize: 14,
            fontWeight: 400
          }}
          key={`${item.title}${item.name}`}>
          {item.title}
        </div>)
      )
    }
  </div>
});

class DataReport extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    queryCondition: QueryConditionShape.isRequired,
    data: PropTypes.object.isRequired,
    onDateRangeChange: PropTypes.func.isRequired,
    onPageNoChange: PropTypes.func.isRequired,
    onPageSizeChange: PropTypes.func.isRequired,
    getDeveloperReportData: PropTypes.func.isRequired,
    onQueryMethodChange: PropTypes.func.isRequired,
    downloadReportData: PropTypes.func.isRequired,
    originMenu: PropTypes.object.isRequired,
    cascadingQueryCondition: PropTypes.object.isRequired,
    getDataReportCascadingMenuList: PropTypes.func.isRequired,
    onFilterIdsChange: PropTypes.func.isRequired,
    onCascadingPageSizeChange: PropTypes.func.isRequired,
    onCascadingKeywordChange: PropTypes.func.isRequired,
    onSelectedMenuListChange: PropTypes.func.isRequired
  }

  componentDidMount() {
    const { getDeveloperReportData, type } = this.props;
    getDeveloperReportData(type);
  }

  componentWillReceiveProps(nextProps) {
    const { data, getDeveloperReportData } = this.props;
    const shouldFetchData = ((data.status === OperationStatus.load_success
      || data.status === OperationStatus.load_fail)
      && nextProps.data.status === OperationStatus.initial);
    if (shouldFetchData) {
      setTimeout(() => getDeveloperReportData(nextProps.type), 0);
    }
  }

  onDateRangeChange = ranges => {
    const dateRange = {
      startDate: ranges[0],
      endDate: ranges[1]
    };
    this.props.onDateRangeChange(this.props.type, dateRange);
  };

  onPageNoChange = pageNo => this.props.onPageNoChange(this.props.type, pageNo);

  onPageSizeChange = (pageNo, pageSize) => this.props.onPageSizeChange(this.props.type, pageNo, pageSize);

  generageVsIndicator = () => (
    this.props.type === DataReportTabs.样式
      ? vsIndicator
      : [...vsIndicator].concat(addIndicator)
  )

  downloadReport = e => {
    e.stopPropagation();
    const { type, downloadReportData } = this.props;
    const options = { type };
    downloadReportData(options);
  }

  render() {
    const {
      type,
      queryCondition,
      data,
      getDeveloperReportData,
      onQueryMethodChange,
      originMenu,
      cascadingQueryCondition,
      getDataReportCascadingMenuList,
      onFilterIdsChange,
      onCascadingKeywordChange,
      onCascadingPageSizeChange,
      onSelectedMenuListChange
    } = this.props;
    const { pageNo, pageSize, aggregate, dateRange: { startDate, endDate } } = queryCondition;
    const totalRange =
      aggregate === DataReportAggregateType.汇总
        ? `${startDate.format('YYYY-MM-DD')} ~ ${endDate.format('YYYY-MM-DD')}`
        : null;
    const isDayData = startDate.format('YYYY-MM-DD') === endDate.format('YYYY-MM-DD');
    return (
      <div className={s.root}>
        <div className={s.container}>
          <SelectionBar selectedItem={type} itemList={selectionBarList} />
          <div className={s.contentContainer}>
            <div className={s.conditionBarContainer}>
              <QueryConditionBar
                type={type}
                queryCondition={queryCondition}
                onDateRangeChange={this.onDateRangeChange}
                getDeveloperReportData={getDeveloperReportData}
                onQueryMethodChange={onQueryMethodChange}
                originMenu={originMenu}
                cascadingQueryCondition={cascadingQueryCondition}
                getDataReportCascadingMenuList={getDataReportCascadingMenuList}
                onFilterIdsChange={onFilterIdsChange}
                onCascadingKeywordChange={onCascadingKeywordChange}
                onCascadingPageSizeChange={onCascadingPageSizeChange}
                onSelectedMenuListChange={onSelectedMenuListChange}
              />
            </div>
            <Fragment>
              <h2>数据趋势</h2>
              <ChartComp
                type={type}
                data={handleChartReportResData(data.chartList, isDayData)}
                vsIndicator={this.generageVsIndicator()}
              />
            </Fragment>
            <Fragment>
              <div className={s.dataTableHeaderContainer}>
                <h2>数据报表</h2>
                <div className={s.downloadContainer}>
                  <img src={ic_attention} alt='attention' />&nbsp;&nbsp;
                  <span>隐藏请求广告数为0的数据</span>
                  <span className={s.dividerLine}>|</span>
                  <Button size='small' onClick={this.downloadReport}>
                    <Icon type="download" />
                    下载报表
                  </Button>
                </div>
              </div>
              <TableComp
                type={type}
                data={handleTableReportResData(data.tableList, data.totalObj, totalRange)}
                total={data.total}
                pageNo={pageNo}
                pageSize={pageSize}
                onPageSizeChange={this.onPageSizeChange}
                onPageNoChange={this.onPageNoChange}
              />
            </Fragment>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(DataReport);
