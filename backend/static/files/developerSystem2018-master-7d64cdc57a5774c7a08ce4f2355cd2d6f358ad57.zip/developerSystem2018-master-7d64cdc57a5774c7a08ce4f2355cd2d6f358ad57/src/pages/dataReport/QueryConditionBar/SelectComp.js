import React, { Fragment, Component } from 'react';
import PropTypes from 'prop-types';
import { Select } from 'antd';
import { DataReportAggregateType } from '../../../constants/MenuTypes';

const { Option } = Select;

const selectStyle = {
  width: '100px',
  margin: '0 10px'
};

class SelectComp extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
    onQueryMethodChange: PropTypes.func.isRequired
  };
  
  render () {
    const { type, value, onQueryMethodChange } = this.props;
    return (
      <Fragment>
        <span>查询方式:</span>
        <Select
          value={value}
          style={selectStyle}
          onChange={
            value => onQueryMethodChange(type, value)
          }
        >
          <Option value={DataReportAggregateType.按天}>按天</Option>
          <Option value={DataReportAggregateType.汇总}>汇总</Option>
        </Select>
      </Fragment>
    );
  }
}

export default SelectComp;