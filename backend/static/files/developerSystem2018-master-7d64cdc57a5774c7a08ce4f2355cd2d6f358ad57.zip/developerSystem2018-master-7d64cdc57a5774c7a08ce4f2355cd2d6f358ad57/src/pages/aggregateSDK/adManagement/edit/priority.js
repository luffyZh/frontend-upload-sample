import React, { Component, Fragment } from 'react';
import { Input, Radio, Button, Select, Card, DatePicker, Modal, Icon, Divider } from 'antd';
import moment from 'moment';
import DebounceInput from 'react-debounce-input';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import CascadingMenuPicker5 from '../../../../components/Common/CascadingMenuPicker5';
import CascadingMenuPicker1 from '../../../../components/Common/CascadingMenuPicker1';
import CascadingMenuPicker2 from '../../../../components/Common/CascadingMenuPicker2';
import CascadingMenuPicker3 from '../../../../components/Common/CascadingMenuPicker3';
import CascadingMenuPicker4 from '../../../../components/Common/CascadingMenuPicker4';
import {
  getListIds,
  dateAndTime
} from '../../../../constants/MenuTypes';
import history from '../../../../history';
import s from '../index.less';

const RadioGroup = Radio.Group;
const { confirm } = Modal;
const { Option } = Select;

const pickerStyle = {
  originMenuWidth: 320,
  selectedMenuWidth: 320,
  totalHeight: 352
};

const searchStyle = {
  width: 318
};

class Priority extends Component {
  static propTypes = {
    mediationSdkSlotUid: PropTypes.string.isRequired,
    settingId: PropTypes.string.isRequired,
    priorityList: PropTypes.object.isRequired,
    detailsInfo: PropTypes.array.isRequired,
    showModal: PropTypes.func.isRequired,
    showEditModal: PropTypes.func.isRequired,
    getOptionList: PropTypes.func.isRequired,
    originMenu: PropTypes.array.isRequired,
    radioChange: PropTypes.func.isRequired,
    getLanguageList: PropTypes.func.isRequired,
    getCountryList: PropTypes.func.isRequired,
    editPriorityConfig: PropTypes.func.isRequired,
    addPriorityConfig: PropTypes.func.isRequired,
    osVersionIds: PropTypes.array.isRequired,
    appVersionIds: PropTypes.array.isRequired,
    channelNoIds: PropTypes.array.isRequired,
    countryIds: PropTypes.array.isRequired,
    sysLanguageIds: PropTypes.array.isRequired,
    changeSelectedList: PropTypes.func.isRequired,
    changeInfo: PropTypes.bool.isRequired,
    onCascadingKeywordChange: PropTypes.func.isRequired,
    disabledValue: PropTypes.object.isRequired
  };

  constructor(props) {
    super(props);
    const {
      priorityList,
      settingId
    } = props;
    this.state = {
      strLength: '',
      inputStyle: { marginLeft: '140px' },
      searchValue: '',
      searchSysValue: '',
      priorityList,
      startTimeMode: settingId === 'newedit' ? 0 : 1,
      endTimeMode: priorityList.endTime === '3000-01-01 00:00:00' ? 0 : 1,
      originMenuListOpenKeys: [],
      selectedMenuListOpenKeys: []
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      priorityList: nextProps.priorityList,
      endTimeMode: nextProps.priorityList.endTime === '3000-01-01 00:00:00' ? 0 : 1
    });
  }

  onSelectedOsListChange = selectedMenuList => {
    const {
      changeSelectedList
    } = this.props;
    changeSelectedList(
      {'osVersionIds': getListIds(selectedMenuList)},
      selectedMenuList, 
      'osVersionIds', 
      true
    );
  };

  onSelectedAppListChange = selectedMenuList => {
    const {
      changeSelectedList
    } = this.props;
    changeSelectedList(
      {'appVersionIds': getListIds(selectedMenuList)},
      selectedMenuList, 
      'appVersionIds', 
      true);
  };

  onSelectedChannelListChange = selectedMenuList => {
    const {
      changeSelectedList
    } = this.props;
    changeSelectedList(
      {'channelNoIds': getListIds(selectedMenuList)},
      selectedMenuList,
      'channelNoIds',
      true);
  };

  onSelectedCountryListChange = selectedMenuList => {
    const {
      changeSelectedList
    } = this.props;
    changeSelectedList(
      {'countryIds': getListIds(selectedMenuList)},
      selectedMenuList,
      'countryIds', 
      true);
  };

  onSelectedSysListChange = selectedMenuList => {
    const {
      changeSelectedList
    } = this.props;
    changeSelectedList(
      {'sysLanguageIds': getListIds(selectedMenuList)},
      selectedMenuList, 
      'sysLanguageIds', 
      true);
  };

  onOriginMenuListOpenKeysChange = originMenuListOpenKeys => {
    this.setState({ originMenuListOpenKeys });
  }

  onSelectedMenuListOpenKeysChange = selectedMenuListOpenKeys => {
    this.setState({ selectedMenuListOpenKeys });
  }

  inputChange = e => {
    const {
      priorityList
    } = this.state;
    const {
      radioChange
    } = this.props;
    e.preventDefault();
    radioChange({'settingName': e.target.value});
    this.setState({
      strLength: e.target.value.trim().split('').length,
      priorityList: Object.assign({}, priorityList, {settingName: e.target.value.trim()}) 
    }, () => {
      this.state.strLength > 25 || this.state.strLength === 0 ?
        this.setState({
          inputStyle: {marginLeft: '140px', color: 'red'}
        }) : this.setState({
          inputStyle: {marginLeft: '140px'}
        });
    });
  }

  styleChange = (value, propertyName) => {
    const {
      priorityList
    } = this.state;
    const {
      radioChange,
      getOptionList,
      getLanguageList,
      getCountryList
    } = this.props;
    radioChange({[propertyName]: value}, true);
    this.setState({
      priorityList: Object.assign({}, priorityList, {[propertyName]: value})
    }, () => {
      propertyName === 'osVersionSettingMode' && value === 1 ? getOptionList(1) : '';
      propertyName === 'appVersionSettingMode' && value === 1 ? getOptionList(2) : '';
      propertyName === 'channelNoSettingMode' && value === 1 ? getOptionList(3) : '';
      propertyName === 'sysLanguageSettingMode' && value === 1 ? getLanguageList() : '';
      propertyName === 'countrySettingMode' && value === 1 ? getCountryList() : '';
    }); 
  }

  valueChange = (propertyName, dateString) => {
    const {
      priorityList
    } = this.state;
    const {
      radioChange
    } = this.props;
    radioChange({[propertyName]: dateString}, true);
    this.setState({
      priorityList: Object.assign({}, priorityList, {[propertyName]: dateString})
    });
  }

  showInfo = () => {
    const {
      mediationSdkSlotUid
    } = this.props;
    confirm({
      title: '你有编辑信息尚未保存，确定要离开当前页面吗？',
      content: '',
      okText: '确认',
      cancelText: '取消',
      onOk:() => {
        history.push(`/developer/aggregateSDK/adManagement/${mediationSdkSlotUid}`);
      }
    });
  }

  render() {
    const {
      detailsInfo,
      showModal,
      originMenu,
      showEditModal,
      editPriorityConfig,
      settingId,
      addPriorityConfig,
      mediationSdkSlotUid,
      osVersionIds,
      appVersionIds,
      channelNoIds,
      countryIds,
      sysLanguageIds,
      changeInfo,
      onCascadingKeywordChange,
      getCountryList,
      getLanguageList,
      disabledValue
    } = this.props;
    const {
      inputStyle,
      searchValue,
      searchSysValue,
      priorityList,
      startTimeMode,
      endTimeMode,
      originMenuListOpenKeys,
      selectedMenuListOpenKeys
    } = this.state;
    return(
      <Fragment>
        <div className={s.labelContainer}>
          <span className={s.slotLabel}>
            广告位名称：
          </span>
          {priorityList.mediationSdkSlotName}
        </div>
        <div className={s.labelContainer}>
          <span className={s.slotLabel}>
            优先级：
          </span> 
          {priorityList.priority}
        </div>
        <div className={s.inputContainer}>
          <span className={s.slotLabel}>
          优先级配置名称：
          </span>
          <DebounceInput 
            maxLength='26' 
            placeholder= '请输入优先级配置名称'
            element={Input}
            debounceTimeout={700}
            value={priorityList.settingName}
            onChange={this.inputChange}
          /> 
        </div>
        <div style={inputStyle}>
          必填，最多25个字
        </div>
        <Divider style={{ margin: '30px 0', width: 600 }}>服务端参数判断</Divider>
        <div className={s.radioStyle}>
          <p>系统版本:</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'osVersionSettingMode') }
            value={priorityList.osVersionSettingMode}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>定向</Radio>
          </RadioGroup>
        </div>
        {priorityList.osVersionSettingMode === 1 ?
          <Card
            title="系统版本"
            extra={<a onClick={ () => showEditModal(1) }>编辑</a>}
            style={{ margin: '5px 0px 20px 80px' }}
          >
            <CascadingMenuPicker5
              originHeader='请选择系统版本'
              selectedHeader='已选择系统版本'
              actionBar={null}
              originMenu={originMenu[0]}
              selectedMenuList={osVersionIds}
              originMenuListOpenKeys={originMenuListOpenKeys}
              selectedMenuListOpenKeys={selectedMenuListOpenKeys}
              onSelectedMenuListChange={this.onSelectedOsListChange}
              onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
              onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
              style={pickerStyle}
            /> 
          </Card>
          : ''
        }    
        <div className={s.radioStyle}>
          <p>APP版本:</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'appVersionSettingMode') }
            value={priorityList.appVersionSettingMode}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>定向</Radio>
          </RadioGroup>
        </div>
        {priorityList.appVersionSettingMode === 1 ?
          <Card
            title="APP版本"
            extra={<a onClick={ () => showEditModal(2) }>编辑</a>}
            style={{ margin: '5px 0px 20px 80px' }}
          >
            <CascadingMenuPicker1
              originHeader='请选择APP版本'
              selectedHeader='已选择APP版本'
              actionBar={null}
              originMenu={originMenu[1]}
              selectedMenuList={appVersionIds}
              originMenuListOpenKeys={originMenuListOpenKeys}
              selectedMenuListOpenKeys={selectedMenuListOpenKeys}
              onSelectedMenuListChange={this.onSelectedAppListChange}
              onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
              onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
              style={pickerStyle}
            /> 
          </Card>
          : ''
        }    
        <div className={s.radioStyle}>
          <p>设备类型：</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'deviceType') }
            value={priorityList.deviceType}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>phone</Radio>
            <Radio value={2}>pad</Radio>
          </RadioGroup>
        </div>
        <div className={s.radioStyle}>
          <p>渠道号：</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'channelNoSettingMode') }
            value={priorityList.channelNoSettingMode}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>定向</Radio>
          </RadioGroup>
        </div>
        { priorityList.channelNoSettingMode === 1 ?
          <Card
            title="渠道号"
            extra={<a onClick={ () => showEditModal(3) }>编辑</a>}
            style={{ margin: '5px 0px 20px 80px' }}
          >
            <CascadingMenuPicker2
              originHeader='请选择渠道号'
              selectedHeader='已选择渠道号'
              actionBar={null}
              originMenu={originMenu[2]}
              selectedMenuList={channelNoIds}
              originMenuListOpenKeys={originMenuListOpenKeys}
              selectedMenuListOpenKeys={selectedMenuListOpenKeys}
              onSelectedMenuListChange={this.onSelectedChannelListChange}
              onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
              onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
              style={pickerStyle}
            /> 
          </Card>
          : ''
        }   
        <div className={s.radioStyle}>
          <p>地域：</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'countrySettingMode') }
            value={priorityList.countrySettingMode}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>定向</Radio>
          </RadioGroup>   
        </div>
        { priorityList.countrySettingMode === 1 ? 
          <Card
            title="地域"
            extra={
              <DebounceInput
                style={searchStyle}
                element={Input}
                debounceTimeout={800}
                value={searchValue}
                suffix={<Icon type='search' />}
                onChange={
                  ({ target: { value } } ) =>
                    this.setState({ 
                      searchValue: value 
                    }, () => {
                      value === '' ? getCountryList() : onCascadingKeywordChange({name: value});
                    })
                }
                placeholder='请输入国家名称'
              />
            }
            style={{ margin: '5px 0px 20px 80px' }}
          >
            <CascadingMenuPicker3
              originHeader='请选择国家'
              selectedHeader='已选择国家'
              actionBar={null}
              originMenu={originMenu[3]}
              selectedMenuList={countryIds}
              originMenuListOpenKeys={originMenuListOpenKeys}
              selectedMenuListOpenKeys={selectedMenuListOpenKeys}
              onSelectedMenuListChange={this.onSelectedCountryListChange}
              onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
              onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
              style={pickerStyle}
            /> 
          </Card>
          : ''
        }  
        <div className={s.radioStyle}>
          <p>手机系统语言：</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'sysLanguageSettingMode') }
            value={priorityList.sysLanguageSettingMode}
          >
            <Radio value={0}>不限</Radio>
            <Radio value={1}>定向</Radio>
          </RadioGroup>
        </div>
        { priorityList.sysLanguageSettingMode === 1 ? 
          <Card
            title="手机系统语言"
            style={{ margin: '5px 0px 20px 80px' }}
            extra={
              <DebounceInput
                style={searchStyle}
                element={Input}
                debounceTimeout={800}
                value={searchSysValue}
                suffix={<Icon type='search' />}
                onChange={
                  ({ target: { value } } ) =>
                    this.setState({ 
                      searchSysValue: value 
                    }, () => {
                      value === '' ? getLanguageList() : onCascadingKeywordChange({sysName: value});
                    })
                }
                placeholder='请输入语言名称'
              />
            }
          >
            <CascadingMenuPicker4
              originHeader='请选择手机系统语言'
              selectedHeader='已选择手机系统语言'
              actionBar={null}
              originMenu={originMenu[4]}
              selectedMenuList={sysLanguageIds}
              originMenuListOpenKeys={originMenuListOpenKeys}
              selectedMenuListOpenKeys={selectedMenuListOpenKeys}
              onSelectedMenuListChange={this.onSelectedSysListChange}
              onOriginMenuListOpenKeysChange={this.onOriginMenuListOpenKeysChange}
              onSelectedMenuListOpenKeysChange={this.onSelectedMenuListOpenKeysChange}
              style={pickerStyle}
            /> 
          </Card>
          : ''
        }
        <Divider style={{ margin: '30px 0', width: 600 }}>返回参数</Divider>
        <div className={s.radioStyle}>
          <p>广告位开关：</p>
          <RadioGroup 
            onChange={ e => this.styleChange(e.target.value, 'slotEnabled') }
            value={priorityList.slotEnabled}
          >
            <Radio value={1}>开</Radio>
            <Radio value={0}>关</Radio>
          </RadioGroup>
        </div>
        <div className={s.radioStyle}>
          <p>生效时间：</p>
          <RadioGroup 
            onChange={
              ({ target: { value } } ) =>
                this.setState({ 
                  startTimeMode: value 
                }, () => {
                  this.state.startTimeMode === 1
                    ? this.valueChange('startTime', this.state.priorityList.startTime)
                    : this.valueChange('startTime', dateAndTime());
                })
            }
            value={startTimeMode}
          >
            <Radio value={0}>即时开始</Radio>
            <Radio value={1}>设置开始时间(北京时间)</Radio>
          </RadioGroup>
        </div>
        <IfComp
          expression={startTimeMode === 1}
          trueComp={
            <DatePicker
              style={{ marginLeft: '140px', width: '200px', marginBottom: '20px' }}
              showTime
              format="YYYY-MM-DD HH:mm:ss"
              placeholder='请选择时间日期'
              value={moment(priorityList.startTime)}
              onChange={ (value, dateString) => this.valueChange('startTime', dateString) }
            />
          }
        />
        <div className={s.radioStyle}>
          <p>过期时间：</p>
          <RadioGroup
            onChange={
              ({ target: { value } } ) =>
                this.setState({ 
                  endTimeMode: value 
                }, () => {
                  priorityList.endTime === '3000-01-01 00:00:00' && this.state.endTimeMode === 1 ? 
                    this.valueChange('endTime', dateAndTime()) : this.valueChange('endTime', '3000-01-01 00:00:00');
                })
            }
            value={endTimeMode}
          >
            <Radio value={0}>无结束时间</Radio>
            <Radio value={1}>设置结束时间(北京时间)</Radio>
          </RadioGroup>
        </div>
        { endTimeMode === 1 ? 
          <DatePicker
            style={{ marginLeft: '140px', width: '200px', marginBottom: '20px' }}
            showTime
            format="YYYY-MM-DD HH:mm:ss"
            placeholder='请选择时间日期'
            value={priorityList.endTime === 1 ? moment(dateAndTime(), 'YYYY-MM-DD HH:mm:ss') : moment(priorityList.endTime)}
            onChange={ (value, dateString) => this.valueChange('endTime', dateString) }
          /> : ''
        }
        <div className={s.radioStyle}>
          <p>平台优先级配置：</p> 
          <Select 
            style={{width: '200px'}}
            onChange={ key => this.valueChange('platformPriorityId', key) }
            value={
              priorityList.platformPriorityId !== 0 ? 
                priorityList.platformPriorityId : '请选择平台优先级(必填)'
            }
          >
            { detailsInfo.map(item => 
              <Option 
                value={item.id}
                key={item.id}
              >
                {item.name}
              </Option>)
            }
          </Select>&nbsp;&nbsp;&nbsp;
          <a style={{ fontSize: '14px' }} onClick={showModal}>编辑平台优先级配置</a>
        </div>
        <div className={s.radioStyle}>
          <Button 
            type='primary'
            style={{ marginLeft: 0 }}
            disabled={Object.values(disabledValue).includes(false)}
            onClick={ () => 
              settingId === 'newedit' ?
                addPriorityConfig(mediationSdkSlotUid, priorityList)
                : editPriorityConfig(priorityList, mediationSdkSlotUid)
            }
          >
          保存
          </Button>
          <Button 
            style={{ marginLeft: 20 }}
            onClick={ changeInfo ? this.showInfo :
              () => history.push(`/developer/aggregateSDK/adManagement/${mediationSdkSlotUid}`)
            }>
          取消
          </Button>
        </div>
      </Fragment>
    );
  }
}

export default withStyles(s)(Priority);