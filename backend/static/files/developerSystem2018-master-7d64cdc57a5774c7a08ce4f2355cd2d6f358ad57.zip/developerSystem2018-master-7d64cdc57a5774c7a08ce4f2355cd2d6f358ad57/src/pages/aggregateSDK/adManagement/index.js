import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Modal } from 'antd';
import IfComp from 'if-comp';
import AdList from '../adManagement/adList';
import Advertising from '../adManagement/advertising';
import AdEdit from '../../../containers/aggregateSDK/adEdit';
import Link from '../../../components/Link';
import history from '../../../history';
import { OperationStatus } from '../../../constants/MenuTypes';
import s from './index.less';

const { confirm } = Modal;

class AdManagement extends Component {
  static propTypes = {
    type: PropTypes.array.isRequired,
    list: PropTypes.array.isRequired,
    total: PropTypes.number.isRequired,
    deleteSlotList: PropTypes.func.isRequired,
    status: PropTypes.oneOf(Object.keys(OperationStatus)).isRequired,
    mediationSdkSlotName: PropTypes.string.isRequired,
    advertisingList: PropTypes.array.isRequired,
    addSlotList: PropTypes.func.isRequired,
    editSlotName: PropTypes.func.isRequired,
    deleteAdvertisingList: PropTypes.func.isRequired,
    getAdvertisingList: PropTypes.func.isRequired,
    upSetPriority: PropTypes.func.isRequired,
    changeInfo: PropTypes.bool
  }

  static defaultProps = {
    changeInfo: false
  }

  constructor(props) {
    super(props);
    const {  
      type
    } = props;
    this.state = { 
      type
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      type: nextProps.type
    });
  }

  showInfo = path => {
    confirm({
      title: '你有编辑信息尚未保存，确定要离开当前页面吗？',
      content: '',
      okText: '确认',
      cancelText: '取消',
      onOk:() => {
        history.push(path);
      }
    });
  }
  
  render() {
    const {
      list,
      total,
      deleteSlotList,
      status,
      mediationSdkSlotName,
      advertisingList,
      addSlotList,
      editSlotName,
      deleteAdvertisingList,
      getAdvertisingList,
      upSetPriority,
      changeInfo
    } = this.props;
    const { 
      type
    } = this.state;
    return (
      <IfComp
        expression={type.length === 1}
        trueComp={
          <Fragment>
            <div className={s.titleContainer}>
              <h3>广告位列表</h3>
            </div>
            <AdList 
              list={list}
              total={total}
              deleteSlotList={deleteSlotList}
              status={status}
            />
          </Fragment>
        }
        falseComp={
          <IfComp
            expression={type.length === 2}
            trueComp={
              <Fragment>
                <div className={s.titleContainer}>
                  <h3><Link to={`/developer/aggregateSDK/${type[0]}`}>广告位列表&nbsp;</Link></h3>
                  <h3>&gt;&nbsp;广告位</h3>
                </div>
                <Advertising 
                  type={type[1]}
                  status={status}
                  mediationSdkSlotName={mediationSdkSlotName}
                  advertisingList={advertisingList}
                  addSlotList={addSlotList}
                  editSlotName={editSlotName}
                  deleteAdvertisingList={deleteAdvertisingList}
                  getAdvertisingList={getAdvertisingList}
                  upSetPriority={upSetPriority}
                />
              </Fragment>
            }
            falseComp={
              <Fragment>
                <div className={s.titleContainer}>
                  <h3>
                    <a
                      onClick={
                        changeInfo
                          ? () => this.showInfo(`/developer/aggregateSDK/${type[0]}`)
                          : () => history.push(`/developer/aggregateSDK/${type[0]}`)
                      }
                    >
                      广告位列表&nbsp;
                    </a>
                  </h3>
                  <h3>&gt;&nbsp;
                    <a
                      onClick={
                        changeInfo 
                          ? () => this.showInfo(`/developer/aggregateSDK/${type[0]}/${type[1]}`)
                          : () => history.push(`/developer/aggregateSDK/${type[0]}/${type[1]}`)
                      }
                    >
                      广告位&nbsp;
                    </a>
                  </h3>  
                  <h3>&gt;&nbsp;优先级配置</h3>
                </div>
                <AdEdit 
                  mediationSdkSlotUid={type[1]}
                  settingId={type[2]}
                />
              </Fragment>
            }
          />
        }
      />
    );
  }
}

export default withStyles(s)(AdManagement);
