import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Table, Button, Popconfirm, message } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../../../../components/Link';
import history from '../../../../history';
import s from '../index.less';

message.config({
  top: 100
});

class AdList extends Component {
  static propTypes = {
    list: PropTypes.array.isRequired,
    deleteSlotList: PropTypes.func.isRequired
  }
  
  constructor(props){
    super(props);
    this.state = {};
  }

  handleDelete = (mediationSdkSlotUid, index) => {
    this.props.deleteSlotList(mediationSdkSlotUid, index);
  }

  handleAdd = () => {
    const { list } = this.props;
    list.length >= 20
      ? message.warning('最多可建20个广告位!')
      : setTimeout(() => {
        history.push('/developer/aggregateSDK/adManagement/newslot');
      }, 0);
  }

  render() {
    const columns = [{
      title:'序号',
      dataIndex:'number'
    },
    {
      title:'广告位名称',
      dataIndex:'mediationSdkSlotName'
    },
    {
      title: '配置ID',
      dataIndex: 'mediationSdkSlotUid'
    },
    {
      title:'操作',
      dataIndex:'operation',
      width: '300px',
      render: (text, record, index) => (
        <span>
          <Popconfirm 
            title="删除的信息将无法恢复，你确定要删除吗？" 
            okText="确认" 
            cancelText="取消" 
            onConfirm={ () => this.handleDelete(record.mediationSdkSlotUid, index)}
          >
            <a>删除</a>&nbsp;&nbsp;&nbsp;    
          </Popconfirm>  
          <span>
            <Link to={`/developer/aggregateSDK/adManagement/${record.mediationSdkSlotUid}`}>编辑</Link>
          </span>
        </span>
      )
    }];

    const { list } = this.props;

    return (
      <Fragment>
        <div className={s.btnContainer}>
          <Button type='primary' onClick={this.handleAdd} ghost>新增</Button>
        </div>
        <Table 
          dataSource={list} 
          columns={columns} 
          bordered 
          rowKey={record => record.mediationSdkSlotUid}
          pagination={false}
        />
      </Fragment>
    );
  }
}

export default withStyles(s)(AdList);
