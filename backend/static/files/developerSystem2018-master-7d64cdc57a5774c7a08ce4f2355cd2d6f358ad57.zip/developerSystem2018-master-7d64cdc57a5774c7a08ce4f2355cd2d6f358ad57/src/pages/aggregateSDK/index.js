import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import AdManagement from '../../containers/aggregateSDK/adManagement';
import Description from './description/index';
import SelectionBar from '../../components/Common/SelectionBar';
import s from './index.less';

export const selectionBarList = [
  {
    name: 'adManagement',
    title: '广告位管理',
    link: '/developer/aggregateSDK/adManagement'
  },
  {
    name: 'description',
    title: '文档说明',
    link: '/developer/aggregateSDK/description'
  }
];

class AggregateSDK extends Component {
  static propTypes = {
    type: PropTypes.array.isRequired
  };

  constructor(props) {
    super(props);
    const { 
      type
    } = props;
    this.state = { 
      type
    };
  }

  componentWillReceiveProps(nextProps){
    this.setState({
      type: nextProps.type
    });
  }

  render() {
    const { 
      type
    } = this.state;

    return (
      <div className={s.root}>
        <div className={s.container}>
          <SelectionBar selectedItem={type[0]} itemList={selectionBarList} />
          <div className={s.contentContainer}>
            <IfComp
              expression={type[0] === 'description'}
              trueComp={<Description />}
              falseComp={
                <AdManagement type={ type } />
              }
            />
          </div>
        </div>
      </div>
    );
  }
} 




export default withStyles(s)(AggregateSDK);
