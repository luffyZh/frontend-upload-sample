import React, { Component } from 'react';
import { Button } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from '../index.less';

class Description extends Component {
  render() {
    return (
      <div className={s.contentWrapper}>
        <div className={s.content}>
          <span>Android 聚合SDK</span>
          <Button type="primary">
            <a target="__blank" href="https://download.ydstatic.com/ead/youdao_mediationsdk_1_0_0.aar">
              下载 - v1.0.0
            </a>
          </Button>
        </div>
        <div className={s.desc}>
          <a target="__blank" href="https://download.ydstatic.com/ead/youdao_mediationsdkdemo_1_0_0.zip">
            DEMO
          </a>
          <a target="__blank" href="https://download.ydstatic.com/ead/android_mediationsdk_doc.pdf">
            说明文档
          </a>
          <a target="__blank" href="https://download.ydstatic.com/ead/YoudaoAndroid聚合SDK更新记录.txt">
            更新记录
          </a>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Description);
