import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Button, Tooltip } from 'antd';
import PriorityConfig from './priorityConfig';
import {
  dataSourceMap
} from '../../../../constants/MenuTypes';
import s from '../index.less';

class Details extends Component {
  static propTypes = {
    mediationSdkSlotUid: PropTypes.string.isRequired,
    mediationSdkSlotName: PropTypes.string.isRequired,
    platformPriorities: PropTypes.array.isRequired,
    editPlatformPriority: PropTypes.func.isRequired,
    deletePlatformPriority: PropTypes.func.isRequired,
    addPlatformPriority: PropTypes.func.isRequired,
    platformEditing: PropTypes.func.isRequired,
    platformAdding: PropTypes.func.isRequired,
    platformDelete: PropTypes.func.isRequired,
    platformValueChange: PropTypes.func.isRequired,
    platformAddRow: PropTypes.func.isRequired,
    platformDeleteRow: PropTypes.func.isRequired,
    platformRowSave: PropTypes.func.isRequired,
    platformRowEdit: PropTypes.func.isRequired
  }

  constructor(props) {
    super(props);
    const {
      platformPriorities
    } = props;
    this.state = {
      platformPriorities
    };
  }   

  componentWillReceiveProps(nextProps) {
    this.setState({
      platformPriorities: nextProps.platformPriorities
    });
  }

  handleAdd = () => {
    const {
      platformPriorities
    } = this.state;
    const {
      mediationSdkSlotUid,
      editPlatformPriority
    } = this.props;
    this.props.platformAdding(true, true);
    platformPriorities.map((item, index) => item.editStatus === true && item.newAdd === false
      ? editPlatformPriority(
        mediationSdkSlotUid, 
        item.platformPriorityId, 
        item.platformPriorityName, 
        dataSourceMap(item.configs, {isRowEdit: false}),
        false,
        index + 1
      )
      : item
    );
  }

  handleDelete = index => {
    const {
      platformDelete
    } = this.props;
    const {
      platformPriorities
    } = this.state;
    if (platformPriorities[index].newAdd === true) {
      platformDelete(false, index);
      this.setState({
        platformPriorities: platformPriorities.length !== 0
          ? platformPriorities.filter((item, _index) => _index !== index)
          : []
      });
    }
  }
  
  render() {
    const {
      mediationSdkSlotName,
      mediationSdkSlotUid,
      editPlatformPriority,
      addPlatformPriority,
      deletePlatformPriority,
      platformEditing,
      platformValueChange,
      platformAddRow,
      platformDeleteRow,
      platformRowSave,
      platformRowEdit
    } = this.props;
    const {
      platformPriorities
    } = this.state;
    return(
      <Fragment>
        <h2>广告平台优先级配置</h2>
        <div className={s.newContainer} style={{marginBottom: '30px'}}>
          <p>广告位名称：{mediationSdkSlotName}</p>
          <Tooltip title='一次只能新增一个平台优先级配置，保存后在进行新增操作' 
            onClick={
              platformPriorities.map(item => item.newAdd).includes(true)
                ? null
                : this.handleAdd
            }
          >
            <Button type='primary' ghost>新增平台优先级配置</Button>
          </Tooltip>
        </div>
        { 
          platformPriorities.length !== 0
            ? platformPriorities.map((item, index) => 
              <PriorityConfig
                handleDelete={this.handleDelete}
                mediationSdkSlotUid={mediationSdkSlotUid} 
                platformPriorityName={item.platformPriorityName}
                key={item.platformPriorityId}
                index={index}
                editStatus={item.editStatus}
                platformPriorityId={item.platformPriorityId}
                editPlatformPriority={editPlatformPriority}
                addPlatformPriority={addPlatformPriority}
                deletePlatformPriority={deletePlatformPriority}
                platformEditing={platformEditing}
                dataSource={item.configs}
                platformValueChange={platformValueChange}
                platformAddRow={platformAddRow}
                platformDeleteRow={platformDeleteRow}
                platformRowSave={platformRowSave}
                platformRowEdit={platformRowEdit}
              />
            ) : []
        }
      </Fragment>
    );
  }
}

export default withStyles(s)(Details);