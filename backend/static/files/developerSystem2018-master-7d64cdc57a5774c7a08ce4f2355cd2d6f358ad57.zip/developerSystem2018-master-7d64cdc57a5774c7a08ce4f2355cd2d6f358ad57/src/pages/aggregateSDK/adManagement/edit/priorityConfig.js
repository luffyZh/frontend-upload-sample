import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Button, Input, Table, Select, Icon, message, Popconfirm, InputNumber } from 'antd';
import { 
  isNull,
  dataSourceMap,
  dataSourceIndex
} from '../../../../constants/MenuTypes';
import s from '../index.less';

const { Option } = Select;

const rowSource = {
  priority: 1,
  ad_source: 'Facebook',
  ad_type: '原生广告',
  placement_id: '',
  timeout: 1,
  isRowEdit: true
};

class PriorityConfig extends Component {
  static propTypes = {
    mediationSdkSlotUid: PropTypes.string.isRequired,
    addPlatformPriority: PropTypes.func.isRequired,
    editPlatformPriority: PropTypes.func.isRequired,
    deletePlatformPriority: PropTypes.func.isRequired,
    platformEditing: PropTypes.func.isRequired,
    dataSource: PropTypes.array.isRequired,
    index: PropTypes.number.isRequired,
    handleDelete: PropTypes.func.isRequired,
    editStatus: PropTypes.bool.isRequired,
    platformPriorityName: PropTypes.string,
    platformPriorityId: PropTypes.any.isRequired,
    platformValueChange: PropTypes.func.isRequired,
    platformAddRow: PropTypes.func.isRequired,
    platformDeleteRow: PropTypes.func.isRequired,
    platformRowSave: PropTypes.func.isRequired,
    platformRowEdit: PropTypes.func.isRequired
  }

  static defaultProps = {
    platformPriorityName: ''
  }

  constructor(props) {
    super(props);
    const {
      editStatus,
      dataSource,
      platformPriorityName
    } = props;
    this.state = {
      editStatus,
      platformPriorityName,
      dataSource,
      strLength: '',
      inputStyle: { color: '#545454' }
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      dataSource: nextProps.dataSource
    });
  }

  onInputChange = e => {
    this.setState({
      platformPriorityName: e.target.value,
      strLength: e.target.value.trim().split('').length
    }, () => {
      this.state.strLength > 25 || this.state.strLength === 0 ?
        this.setState({
          inputStyle: { color: 'red' }
        }) : this.setState({
          inputStyle: { color: '#545454' }
        });
    });
  }

  btnEdit = () => {
    const {
      index
    } = this.props;
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: dataSourceMap(dataSource, {isRowEdit :true}),
      editStatus: true
    }, () => {
      this.props.platformEditing(this.state.editStatus, index, this.state.dataSource);
    });
  }

  btnSave = () => {
    const {
      mediationSdkSlotUid,
      addPlatformPriority,
      editPlatformPriority,
      platformPriorityId,
      index
    } = this.props;
    const {
      dataSource,
      strLength,
      platformPriorityName
    } = this.state;
    if (platformPriorityId === 'Facebook' + 1) {
      if (dataSource.length !== 0 && 
        isNull(dataSource).includes(true) === false && 
        platformPriorityName !== '' && 
        strLength <= 25
      ) {
        this.setState({
          dataSource: dataSourceMap(dataSource, {isRowEdit: false}, {ad_type: 'native'}),
          editStatus: false
        }, () => {
          addPlatformPriority(mediationSdkSlotUid, platformPriorityName, this.state.dataSource, false, false);
        });
      }
    } else {
      if (dataSource.length !== 0 && 
        isNull(dataSource).includes(true) === false && 
        platformPriorityName !== '' &&
        strLength <= 25
      ) {
        this.setState({
          dataSource: dataSourceMap(dataSource, {isRowEdit: false}, {ad_type: 'native'}),
          editStatus: false
        }, () => {
          editPlatformPriority(
            mediationSdkSlotUid, 
            platformPriorityId, 
            platformPriorityName, 
            this.state.dataSource, 
            false,
            index
          );
        });
      }
    }
    if (isNull(dataSource).includes(true)) {
      message.warning('当前配置信息不完整！');
    }
    if (dataSource.length === 0) {
      message.warning('当前无可用平台优先级配置！');
    }
    if (platformPriorityName === '') {
      message.warning('平台优先级配置名称不能为空！');
    }
    if (strLength > 25) {
      message.warning('平台优先级配置名称最多25个字！');
    }
  }

  btnDelete = () => {
    const {
      mediationSdkSlotUid,
      deletePlatformPriority,
      platformPriorityId,
      index
    } = this.props;
    platformPriorityId !== 'Facebook' + 1 ?
      deletePlatformPriority(mediationSdkSlotUid, platformPriorityId, {index: index})
      : this.props.handleDelete(index);
  }

  btnDetermine = index => {
    const {
      dataSource
    } = this.state;
    isNull(dataSource)[index] ? message.warning('当前配置信息不完整！') :
      this.setState({
        dataSource: dataSourceIndex(dataSource, index, {isRowEdit: false})
      }, () => {
        this.props.platformRowSave(this.state.dataSource, this.props.index);
      });
  }

  btnRowEdit = index => {
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: dataSourceIndex(dataSource, index, {isRowEdit: true})
    }, () => {
      this.props.platformRowEdit(this.state.dataSource, this.props.index);
    });
  }

  btnRowDelete = index => {
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: dataSource.filter((item, _index) => index !== _index)
    }, () => {
      this.props.platformDeleteRow(this.state.dataSource, this.props.index);
    });
  }

  handleAddRow = () => {
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: [...dataSource, rowSource]
    }, () => {
      this.props.platformAddRow(this.state.dataSource, this.props.index);
    });
  }

  changeValue = (object1, index) => {
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: dataSourceIndex(dataSource, index, object1)
    });
  }
  
  render() {
    const { 
      dataSource,
      platformPriorityName,
      inputStyle
    } = this.state;
    const {
      editStatus,
      platformValueChange
    } = this.props;
    const columns = [
      {
        title: '优先级',
        dataIndex: 'priority',
        key: 'priority',
        render: ( text, record, index ) => (
          record.isRowEdit ? 
            <InputNumber
              min={1}
              step='1'
              placeholder='请输入优先级'
              value={record.priority === 1 ? 1 : record.priority}
              onChange={value => this.changeValue({priority: value}, index)}
              onBlur={() => platformValueChange({configs: dataSource}, this.props.index)}
              formatter={value => isNaN(parseInt(`${value}`)) ? '' : parseInt(`${value}`)}
            />
            : record.priority
        )
      },
      {
        title: '平台名称',
        dataIndex: 'ad_source',
        key: 'ad_source',
        render: ( text, record, index) => (
          record.isRowEdit ? 
            (<Select 
              value={record.ad_source === '' ? 'Facebook' : record.ad_source}
              placeholder='请选择平台名称'
              onChange={ value => this.changeValue({ad_source: value}, index) }
              onBlur={ () => platformValueChange({configs: dataSource}, this.props.index) }
            >
              <Option value='Facebook'>Facebook</Option>
              <Option value='Admob'>Admob</Option>
              <Option value='Zhixuan'>Zhixuan</Option>
              <Option value='Baidu'>Baidu</Option>
            </Select>)
            : record.ad_source
        )
      },
      {
        title: '广告类型',
        dataIndex: 'ad_type',
        key: 'ad_type',
        render: ( text, record, index) => (
          record.isRowEdit ?
            <Select 
              defaultValue='原生广告'
              placeholder='请选择广告类型'
              onChange={ value => this.changeValue({ad_type: value}, index) }
              onBlur={ () => platformValueChange({configs: dataSource}, this.props.index) }
            >
              <Option value='原生广告'>
                { record.ad_type === 'native' ? '原生广告' : '原生广告' }
              </Option>
            </Select>
            : '原生广告'
        )
      },
      {
        title: '广告ID',
        dataIndex: 'placement_id',
        key: 'placement_id',
        render: ( text, record, index) => (
          record.isRowEdit ? 
            <Fragment>
              <Input 
                placeholder='请输入广告位ID'
                value={record.placement_id === '' ? '' : record.placement_id}
                onChange={ e => this.changeValue({ placement_id: e.target.value }, index) }
                onBlur={
                  () => {
                    platformValueChange({ configs: dataSource }, this.props.index);
                  }
                }
              /> 
            </Fragment>
            : record.placement_id
        )
      },
      {
        title: '返回时间限制(ms)',
        dataIndex: 'timeout',
        key: 'timeout',
        render: ( text, record, index) => (
          record.isRowEdit ? 
            <InputNumber
              min={1}
              step='1'
              placeholder='请输入返回时间' 
              value={record.timeout === 1 ? 1 : record.timeout}
              onChange={ value => this.changeValue({timeout: value}, index) }
              onBlur={ () => platformValueChange({configs: dataSource}, this.props.index) }
              formatter={ value => isNaN(parseInt(`${value}`)) ? '' : parseInt(`${value}`) }
            />  
            : record.timeout
        )
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        render: (text, record, index)=> (
          <span>
            { record.isRowEdit ? 
              <a onClick={ () => this.btnDetermine(index) }>确定</a> :
              <a onClick={ () => this.btnRowEdit(index) }>编辑</a>
            }
            &nbsp;&nbsp;&nbsp;<a onClick={ () => this.btnRowDelete(index) }>删除</a>
          </span>
        )
      }
    ];

    return(
      <div
        style={
          editStatus ? 
            { backgroundColor: '#F2F2F2', padding: '10px', marginBottom: '15px' } 
            : { marginBottom: '20px' }
        }
      >
        <div className={s.slotNameStyle}>
          <div className={s.inputContainer}>
            <span style={{ marginRight: '20px' }}>平台优先级配置名称:</span>
            {
              editStatus ? 
                <Input 
                  maxLength='26' 
                  placeholder= '请输入平台优先级配置名称'
                  value={platformPriorityName}
                  onChange={this.onInputChange}
                  onBlur={ e => platformValueChange({'platformPriorityName': e.target.value}, this.props.index) }
                />
                : platformPriorityName
            }
          </div>
          <div className={s.btn}>
            <Popconfirm title="删除的信息将无法恢复，你确定要删除吗？" okText="确认"  
              cancelText="取消" onConfirm={ index => this.btnDelete(index) }>
              <Button style={{ marginRight: '20px' }}>删除</Button>   
            </Popconfirm>  
            {editStatus ? 
              <Button type='primary' onClick={this.btnSave} ghost>保存</Button> :
              <Button type='primary' onClick={this.btnEdit} ghost>编辑</Button>
            }
          </div>
        </div>
        <div style={ editStatus ? 
          { margin: '0px 0px 10px 170px', display: 'block' }
          : 
          { display: 'none' }}>
          <span style={inputStyle}>必填，最多25个字</span>
        </div>
        <Table 
          className={s.jsonEdit}
          columns={editStatus ? columns : columns.slice(0, 5)}
          dataSource={dataSource}
          bordered
          rowKey={(r, i) => i}
          pagination={{
            pageSize: 50
          }}
        />  
        <a
          style={ editStatus ? { marginTop: '20px', display: 'block', width: '40px' } : { display: 'none' } }
          onClick={dataSource.length > 49 ? () =>
            message.warning('最多可建50条优先级!')
            : this.handleAddRow}
        >
          <Icon type='plus' />
          &nbsp;新增
        </a>
      </div>
    );
  }
}
  
export default withStyles(s)(PriorityConfig);
  