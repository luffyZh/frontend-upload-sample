import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Table, Button, Input, Popconfirm, message } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../../../../components/Link';
import { OperationStatus } from '../../../../constants/MenuTypes';
import s from '../index.less';

class Advertising extends Component{
  static propTypes = {
    status: PropTypes.oneOf(Object.keys(OperationStatus)).isRequired,
    type: PropTypes.string.isRequired,
    mediationSdkSlotName: PropTypes.string.isRequired,
    advertisingList: PropTypes.array.isRequired,
    addSlotList: PropTypes.func.isRequired,
    editSlotName: PropTypes.func.isRequired,
    deleteAdvertisingList: PropTypes.func.isRequired,
    getAdvertisingList: PropTypes.func.isRequired,
    upSetPriority: PropTypes.func.isRequired
  }

  constructor(props){
    super(props);
    const { mediationSdkSlotName } = props;
    this.state = {
      strLength: 0,
      inputStyle: {marginLeft: '100px'},
      mediationSdkSlotName,
      btnDisabled: mediationSdkSlotName === ''
    };
  }
 
  componentWillReceiveProps(nextProps) {
    const { mediationSdkSlotName } = nextProps;
    this.setState({ btnDisabled: mediationSdkSlotName === '' });
    if (this.props.status === OperationStatus.loading) {
      this.setState({
        mediationSdkSlotName: mediationSdkSlotName
      });
    }
  }

  componentDidUpdate() {
    if (this.props.status === OperationStatus.load_success) {
      this.props.getAdvertisingList(this.props.type);
    }
  }
  
  inputChange = e => {
    e.preventDefault();
    this.setState({
      strLength: e.target.value.trim().split('').length,
      mediationSdkSlotName: e.target.value
    }, () => {
      this.state.strLength > 25 || this.state.strLength === 0
        ? this.setState({
          inputStyle: { marginLeft: '100px', color: 'red' },
          btnDisabled: true
        })
        : this.setState({
          inputStyle: { marginLeft: '100px' },
          btnDisabled: false
        });
    });
  }

  handleAddList = () => {
    const {
      mediationSdkSlotName
    } = this.state;
    const {
      type
    } = this.props;
    type !== 'newslot'
      ? this.props.editSlotName(mediationSdkSlotName.trim(), type)
      : this.props.addSlotList(mediationSdkSlotName.trim());
  } 

  handleDelete = settingId => {
    const {
      type
    } = this.props;
    this.props.deleteAdvertisingList(type, settingId);
  }
  
  render() {
    const { 
      type,
      advertisingList
    } = this.props;
    const {
      mediationSdkSlotName,
      btnDisabled
    } = this.state;
    const columns = [
      {
        title: '优先级',
        dataIndex: 'priority'
      },
      {
        title: '优先级配置名称',
        dataIndex: 'settingName'
      },
      {
        title: '生效时间',
        dataIndex: 'startTime'
      },
      {
        title: '过期时间',
        dataIndex: 'endTime',
        render: (text, record)=> (
          record.endTime === '3000-01-01 00:00:00' ?
            <span>无结束时间</span> : record.endTime
        )
      },
      {
        title: '平台优先级配置',
        dataIndex: 'platformPriorityName',
        render: (text, record)=> (
          record.platformPriorityName !== null ?
            record.platformPriorityName : <span style={{color: 'red'}}>无对应配置</span>
        )
      },
      {
        title: '选项',
        dataIndex: 'operation',
        width: '300px',
        render: (text, record, index)=> (
          <span>
            <a onClick={ () => index !== 0 ?
              this.props.upSetPriority(
                advertisingList[index - 1].settingId,
                advertisingList[index - 1].priority,
                record.settingId,
                record.priority
              ) : ''} 
            >上移</a>&nbsp;&nbsp;&nbsp;
            <a onClick={ () => index !== advertisingList.length - 1 ?
              this.props.upSetPriority(
                record.settingId,
                record.priority,
                advertisingList[index + 1].settingId,
                advertisingList[index + 1].priority
              ) : '' }
            >下移</a>&nbsp;&nbsp;&nbsp;
            <Popconfirm 
              title="删除的信息将无法恢复，你确定要删除吗？" 
              okText="确认" 
              cancelText="取消" 
              onConfirm={ () => this.handleDelete(record.settingId)}
            >
              <a>删除</a>&nbsp;&nbsp;&nbsp;    
            </Popconfirm>  
            <Link to= {`/developer/aggregateSDK/adManagement/${type}/${record.settingId}`}>编辑</Link>
          </span>
        )
      }];

    return (
      <Fragment>
        <div className={s.inputContainer}>
          <span style={{marginRight: '30px'}}>广告位名称</span>
          <Input 
            maxLength='26'
            placeholder= '请输入广告位名称'
            value={mediationSdkSlotName}
            id={type}
            onChange={this.inputChange}
            onBlur={
              e => {
                const { value } = e.target;
                value.length < 25 && value.length > 0
                  ? this.handleAddList()
                  : () => {
                    message.warning('广告位名称不合要求！');
                    this.setState({
                      inputStyle: { marginLeft: '100px', color: 'red' },
                      btnDisabled: true
                    });
                  };
              }
            }
          /> 
        </div>
        <div style={this.state.inputStyle}>
          必填，最多25个字
        </div>
        <div className={s.newContainer}>
          <p>优先级信息</p>
          <Button type='primary' ghost disabled={btnDisabled}>
            <Link 
              to= {`/developer/aggregateSDK/adManagement/${type}/newedit?mediationSdkSlotName=${mediationSdkSlotName}`}
            >
            新增
            </Link>
          </Button>
        </div>
        <Table 
          bordered
          dataSource={advertisingList}
          columns={columns}
          rowKey={record => record.settingId}
          pagination={false}
        />
      </Fragment>
    );
  }
}

export default withStyles(s)(Advertising);
