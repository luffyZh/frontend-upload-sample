import React, { Component, Fragment } from 'react';
import { Modal, message } from 'antd';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Details from './Details';
import EditModal from './editModal';
import Priority from './priority';
import { OperationStatus, modalTitle } from '../../../../constants/MenuTypes';
import s from '../index.less';

class AdEdit extends Component {
  static propTypes = {
    priorityList: PropTypes.object.isRequired,
    detailsInfo: PropTypes.array.isRequired,
    mediationSdkSlotUid: PropTypes.string.isRequired,
    settingId: PropTypes.string.isRequired,
    mediationSdkSlotName: PropTypes.string.isRequired,
    platformPriorities: PropTypes.array.isRequired,
    getDetailsInfo: PropTypes.func.isRequired,
    getPlatformList: PropTypes.func.isRequired,
    platformAdding: PropTypes.func.isRequired,
    addPlatformPriority: PropTypes.func.isRequired,
    platformEditing: PropTypes.func.isRequired,
    platformValueChange: PropTypes.func.isRequired,
    platformAddRow: PropTypes.func.isRequired,
    platformDeleteRow: PropTypes.func.isRequired,
    platformRowSave: PropTypes.func.isRequired,
    platformRowEdit: PropTypes.func.isRequired,
    platformDelete: PropTypes.func.isRequired,
    editPlatformPriority: PropTypes.func.isRequired,
    deletePlatformPriority: PropTypes.func.isRequired,
    getOptionList: PropTypes.func.isRequired,
    osList: PropTypes.array.isRequired,
    appList: PropTypes.array.isRequired,
    channelList: PropTypes.array.isRequired,
    languageList: PropTypes.array.isRequired,
    countryList: PropTypes.array.isRequired,
    osVersionIds: PropTypes.array.isRequired,
    appVersionIds: PropTypes.array.isRequired,
    channelNoIds: PropTypes.array.isRequired,
    countryIds: PropTypes.array.isRequired,
    sysLanguageIds: PropTypes.array.isRequired,
    status: PropTypes.oneOf(Object.keys(OperationStatus)).isRequired,
    radioChange: PropTypes.func.isRequired,
    getLanguageList: PropTypes.func.isRequired,
    getCountryList: PropTypes.func.isRequired,
    emitEditModal: PropTypes.func.isRequired,
    optionType: PropTypes.number.isRequired,
    toDeleteIds: PropTypes.array.isRequired,
    toAddValues: PropTypes.array.isRequired,
    editOption: PropTypes.func.isRequired,
    changeEditModalValue: PropTypes.func.isRequired,
    editPriorityConfig: PropTypes.func.isRequired,
    addPriorityConfig: PropTypes.func.isRequired,
    changeSelectedList: PropTypes.func.isRequired,
    changeInfo: PropTypes.bool,
    onCascadingKeywordChange: PropTypes.func.isRequired,
    disabledValue: PropTypes.object.isRequired
  };

  static defaultProps = {
    changeInfo: false
  }

  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      editVisible: false,
      parentEdit: false,
      dataSource: []
    };
  }

  showModal = () => {
    const {
      mediationSdkSlotUid,
      getPlatformList
    } = this.props;
    this.setState({
      visible: true
    });
    getPlatformList(mediationSdkSlotUid);
  }

  showEditModal = optionType => {
    const { 
      emitEditModal,
      osList,
      appList,
      channelList
    } = this.props;
    emitEditModal(optionType);
    this.setState({
      editVisible: true
    });
    if (optionType === 1) {
      this.setState({
        dataSource: osList
      });
    } else if(optionType === 2) {
      this.setState({
        dataSource: appList
      });
    } else {
      this.setState({
        dataSource: channelList
      });
    }
  }

  handleOk = () => {
    const {
      getDetailsInfo,
      mediationSdkSlotUid,
      platformPriorities
    } = this.props;
    platformPriorities.map(item => item.editStatus).includes(true) ?
      message.warn('当前页面有未保存消息！', 4) :
      this.setState({
        visible: false
      }, () => {
        getDetailsInfo(mediationSdkSlotUid);
      });
  }

  changeEdit = isEdit => {
    this.setState({
      parentEdit: isEdit
    });
  }

  handleEditOk = () => {
    const {
      toDeleteIds,
      toAddValues,
      optionType,
      changeEditModalValue
    } = this.props;
    const {
      parentEdit
    } = this.state;
    if(parentEdit === true) {
      message.warn('当前页面有未保存信息！', 4);
    } else {
      this.setState({
        editVisible: false
      });
      changeEditModalValue(optionType, toDeleteIds, toAddValues, true);
    }
  }

  handleCancel = () => {
    this.setState({
      visible: false,
      editVisible: false
    });
  }

  render() {
    const {
      mediationSdkSlotName,
      mediationSdkSlotUid,
      settingId,
      platformAdding,
      addPlatformPriority,
      deletePlatformPriority,
      platformPriorities,
      platformEditing,
      platformDelete,
      editPlatformPriority,
      detailsInfo,
      priorityList,
      getOptionList,
      osList,
      channelList,
      appList,
      status,
      radioChange,
      getLanguageList,
      getCountryList,
      countryList,
      languageList,
      toDeleteIds,
      toAddValues,
      editOption,
      editPriorityConfig,
      addPriorityConfig,
      osVersionIds,
      appVersionIds,
      channelNoIds,
      countryIds,
      sysLanguageIds,
      changeSelectedList,
      changeInfo,
      onCascadingKeywordChange,
      platformValueChange,
      platformAddRow,
      platformDeleteRow,
      platformRowSave,
      platformRowEdit,
      optionType,
      disabledValue
    } = this.props;
    const {
      visible,
      editVisible,
      dataSource
    } = this.state;
    const originMenu = [
      { list: osList, status }, 
      { list: appList, status }, 
      { list: channelList, status }, 
      { list: countryList, status }, 
      { list: languageList, status }
    ];
    return(
      <Fragment>
        <Priority
          mediationSdkSlotUid={mediationSdkSlotUid}
          settingId={settingId}
          detailsInfo={detailsInfo}
          showModal={this.showModal}
          showEditModal={this.showEditModal}
          priorityList={priorityList}
          getOptionList={getOptionList}
          originMenu={originMenu}
          radioChange={radioChange}
          getLanguageList={getLanguageList}
          getCountryList={getCountryList}
          editPriorityConfig={editPriorityConfig}
          addPriorityConfig={addPriorityConfig}
          osVersionIds={osVersionIds}
          appVersionIds={appVersionIds}
          channelNoIds={channelNoIds}
          countryIds={countryIds}
          sysLanguageIds={sysLanguageIds}
          changeSelectedList={changeSelectedList}
          changeInfo={changeInfo}
          onCascadingKeywordChange={onCascadingKeywordChange}
          disabledValue={disabledValue}
        />
        <Modal
          title={`编辑${modalTitle[optionType]}`}
          visible={editVisible}
          onOk={this.handleEditOk}
          onCancel={this.handleCancel}
          okText='保存'
          cancelText='取消'
          maskClosable={false}
          keyboard={false}
          closable={false}
          destroyOnClose='true'
        >
          <EditModal
            dataSource={dataSource}
            toDeleteIds={toDeleteIds}
            toAddValues={toAddValues}
            editOption={editOption}
            changeEdit={this.changeEdit}
            title={modalTitle[optionType]}
          />
        </Modal>
        <Modal
          className={s.detailModal}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          cancelText='取消'
          okText='确定'
          width='1000px'
          maskStyle={{opacity: 0.3}} 
          maskClosable={false}
          keyboard={false}
          closable={false}
          destroyOnClose='true'
        >
          <Details
            mediationSdkSlotName={mediationSdkSlotName}
            platformPriorities={platformPriorities}
            mediationSdkSlotUid={mediationSdkSlotUid}
            addPlatformPriority={addPlatformPriority}
            editPlatformPriority={editPlatformPriority}
            deletePlatformPriority={deletePlatformPriority}
            platformEditing={platformEditing}
            platformAdding={platformAdding}
            platformDelete={platformDelete}
            platformValueChange={platformValueChange}
            platformAddRow={platformAddRow}
            platformDeleteRow={platformDeleteRow}
            platformRowSave={platformRowSave}
            platformRowEdit={platformRowEdit}
          />
        </Modal>
      </Fragment>
    );
  }
}

export default withStyles(s)(AdEdit);
