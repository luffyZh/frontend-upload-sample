import React, { Component, Fragment } from 'react';
import { Icon, Table, Input, Tooltip, message } from 'antd';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { dataSourceIndex } from '../../../../constants/MenuTypes';
import s from '../index.less';

class EditModal extends Component {
  static propTypes = {
    dataSource: PropTypes.array.isRequired,
    toDeleteIds: PropTypes.array.isRequired,
    toAddValues: PropTypes.array.isRequired,
    editOption: PropTypes.func.isRequired,
    changeEdit: PropTypes.func.isRequired,
    title: PropTypes.string.isRequired
  }

  constructor(props) {
    super(props);
    const {
      dataSource,
      toDeleteIds,
      toAddValues
    } = props;
    this.state = {
      toDeleteIds,
      toAddValues,
      dataSource,
      source: {
        isEdit: true,
        id: '',
        name: ''
      }
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      toDeleteIds: nextProps.toDeleteIds,
      toAddValues: nextProps.toAddValues
    });
  }

  handleDelete = (index, recode) => {
    const {
      dataSource,
      toDeleteIds,
      toAddValues
    } = this.state;
    const {
      editOption
    } = this.props;
    this.setState({
      dataSource: dataSource.filter((item, _index) => _index !== index),
      toDeleteIds: toDeleteIds.concat(recode.id)
    }, () => {
      editOption(this.state.toDeleteIds, toAddValues);
    });
  }

  handleAdd = () => {
    const {
      dataSource,
      source
    } = this.state;
    const {
      changeEdit
    } = this.props;
    this.setState({
      dataSource: [...dataSource, source]
    }, () => {
      changeEdit(source.isEdit);
    });
  }

  inputChange = (e, index) => {
    const {
      dataSource
    } = this.state;
    this.setState({
      dataSource: dataSourceIndex(dataSource, index, {name: e.target.value})
    });
  }

  handleDetermine = (recode, index) => {
    const {
      dataSource,
      toDeleteIds,
      toAddValues
    } = this.state;
    const {
      editOption,
      changeEdit
    } = this.props;
    this.setState({
      dataSource: dataSourceIndex(dataSource, index, {isEdit: false}),
      toAddValues: toAddValues.concat(recode.name)
    }, () => {
      editOption(toDeleteIds, this.state.toAddValues);
      changeEdit(this.state.dataSource[index].isEdit);
    });
  }

  render() {
    const {
      dataSource
    } = this.state;
    const {
      title
    } = this.props;
    const columns = [
      {
        dataIndex: 'name',
        render: (text, recode, index) => (
          recode.isEdit ?
            <Input 
              placeholder={`请输入${title}`}
              onChange={e => this.inputChange(e, index)}
            /> 
            : recode.name
        )
      },
      {
        dataIndex: 'option',
        render: (text, recode, index) => (
          recode.isEdit ?
            <a onClick={ () => {
              if (recode.name !== '' && !dataSource.slice(0, index).map(item => item.name).includes(recode.name)) {
                this.handleDetermine(recode, index);
              } else if (recode.name === '') {
                message.warning('输入内容不能为空！');
              } else if (dataSource.slice(0, index).map(item => item.name).includes(recode.name)) {
                message.warning(`${title}名称重复！`);
              }
            }}
            >确定</a> :
            <Icon type='close' onClick={ () => this.handleDelete(index, recode) }/>
        )
      }
    ];

    return(
      <Fragment>
        <Table 
          className={s.modalTable}
          columns={columns}
          dataSource={dataSource}
          rowKey={(r, i) => i}
        />
        <Tooltip 
          title='一次只能新增一个配置，确定后在继续新增操作！'
          style={{ marginTop: '20px' }}
          onClick={
            dataSource.filter(item => item.isEdit === true).length === 1 ? 
              null : this.handleAdd }
        >
          <a><Icon type='plus'/>新增</a>
        </Tooltip>
      </Fragment>
    );
  }
}

export default withStyles(s)(EditModal);