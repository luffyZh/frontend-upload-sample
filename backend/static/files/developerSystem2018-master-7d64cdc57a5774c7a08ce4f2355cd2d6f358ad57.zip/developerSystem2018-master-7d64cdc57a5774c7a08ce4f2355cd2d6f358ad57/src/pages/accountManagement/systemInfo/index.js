import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import _ from 'lodash';
import { Table } from 'antd';
import {
  PageSizeOptions
} from '../../../constants/MenuTypes';
import ic_mail_red from '../../../static/images/ic_mail_red.png';
import ic_mail_grey from '../../../static/images/ic_mail_grey.png';
import s from '../index.less';

const columns = [
  { 
    title: 'InfoIcon',
    dataIndex: 'status',
    key: 'status',
    render: (text, record) => (
      <img
        className={s.infoIcon}
        alt='info'
        src={record.status === 1 ? ic_mail_red : ic_mail_grey}
      />
    ),
    width: 120
  }, {
    title: 'Type',
    dataIndex: 'type',
    key: 'type',
    render: text => <span className={s.systemBold}>{text === 1 ? '系统消息' : '账户消息'}</span> 
  },
  {
    title: 'Title',
    dataIndex: 'title',
    key: 'title',
    width: 120,
    render: text => <span className={s.systemBold}>{text}</span>
  },
  {
    title: 'Date',
    dataIndex: 'date',
    key: 'date',
    render: text => <span className={s.systemBold}>{text}</span>
  }
];

class SystemInfo extends Component {

  static propTypes = {
    systemList: PropTypes.array.isRequired,
    queryCondition: PropTypes.object.isRequired,
    total: PropTypes.number.isRequired,
    onPageNoChange: PropTypes.func.isRequired,
    onPageSizeChange: PropTypes.func.isRequired,
    updateSystemInfo: PropTypes.func.isRequired
  }

  constructor(props) {
    super(props);
    const {
      systemList,
      queryCondition,
      total
    } = props;
    this.state = {
      systemList,
      queryCondition,
      total
    };
  }

  componentWillReceiveProps(nextProps) {
    const {
      systemList,
      queryCondition,
      total
    } = nextProps;
    const newState = {
      systemList,
      queryCondition,
      total
    };
    if (nextProps.systemList !== this.state.systemList
      || nextProps.queryCondition !== this.state.queryCondition
      || nextProps.total !== this.state.total) {
      this.setState(newState);
    }
  }

  expandedRowsChange = expandedRows => {
    const { systemList } = this.state;
    const hasReadArray = [...systemList].map(item => {
      if (item.status === 2) {
        return item.messageId;
      }
    });
    const readInfoId = expandedRows[expandedRows.length - 1];
    const existList = _.includes([...systemList].map(item => item.messageId), readInfoId);
    if (existList
      && _.includes(expandedRows, readInfoId)
      && !_.includes(hasReadArray, readInfoId) // 该消息不是已读状态
    ) {
      this.props.updateSystemInfo(readInfoId);
    }
  }

  render() {
    const {
      onPageNoChange,
      onPageSizeChange
    } = this.props;
    const {
      systemList,
      queryCondition: { pageNo, pageSize },
      total
    } = this.state;
    return (
      <Fragment>
        <Table
          rowKey={record => record.messageId}
          showHeader={false}
          expandRowByClick
          columns={columns}
          dataSource={systemList}
          expandedRowRender={
            record =>
              <div
                style={{ margin: 0 }}
                // eslint-disable-next-line
                dangerouslySetInnerHTML = {{ __html: record.content }}
              />}
          onExpandedRowsChange={this.expandedRowsChange}
          pagination={{
            size: 'small',
            current: pageNo,
            pageSize,
            showSizeChanger: true,
            pageSizeOptions: PageSizeOptions,
            total,
            onChange: onPageNoChange,
            onShowSizeChange: onPageSizeChange
          }}
        />
      </Fragment>
    );
  }
}

export default withStyles(s)(SystemInfo);
