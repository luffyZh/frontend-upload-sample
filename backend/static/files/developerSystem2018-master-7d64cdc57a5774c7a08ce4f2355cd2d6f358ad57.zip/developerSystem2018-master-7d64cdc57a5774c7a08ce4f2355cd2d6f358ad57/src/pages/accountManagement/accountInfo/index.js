import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Button } from 'antd';
import IfComp from 'if-comp';
import _ from 'lodash';
import CompanyComp from './CompanyComp';
import PersonalComp from './PersonalComp';
import { AccountTypeForBE } from '../../../constants/MenuTypes';
import s from '../index.less';

class AccountInfo extends Component {

  static propTypes = {
    user: PropTypes.object.isRequired,
    changeUserInfo: PropTypes.func.isRequired,
    updateAccountInfo: PropTypes.func.isRequired,
    originalUser: PropTypes.object.isRequired
  }

  constructor(props) {
    super(props);
    const { user } = props;
    this.state = {
      user,
      formValid: true
    };
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.user !== this.props.user) {
      this.setState({ user: nextProps.user });
    }
  }

  changeFormValid = valid => this.setState({ formValid: valid });

  updateAccountInfo = () => this.props.updateAccountInfo();

  render() {
    const { changeUserInfo, originalUser } = this.props;
    const { user, formValid } = this.state;
    return (
      <Fragment>
        <div className={s.accountContentContainer}>
          <IfComp
            expression={user.type === AccountTypeForBE.个人}
            trueComp={
              <PersonalComp
                user={user}
                changeUserInfo={changeUserInfo}
                changeFormValid={this.changeFormValid}
              />
            }
            falseComp={
              <CompanyComp
                user={user}
                changeUserInfo={changeUserInfo}
                changeFormValid={this.changeFormValid}
              />
            }
          />
        </div>
        <div className={s.accountBtnContainer}>
          <Button
            type='primary'
            disabled={!formValid}
            onClick={this.updateAccountInfo}
          >保存</Button>
          <Button
            onClick={
              () => {
                changeUserInfo(_.assign({}, originalUser));
                this.setState({ formValid: true });
              }
            }>取消</Button>
        </div>
      </Fragment>
    );
  }
}

export default withStyles(s)(AccountInfo);
