/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import SelectionBar from '../../components/Common/SelectionBar';
import AccountInfo from './accountInfo';
import SystemInfo from './systemInfo';
import DeviceInfo from './deviceInfo';
import {
  accountManagementTabs,
  OperationStatus
} from '../../constants/MenuTypes';
import s from './index.less';

const selectionBarList = [
  {
    name: 'accountInfo',
    title: '账户信息',
    link: '/developer/accountManagement/accountInfo'
  },
  {
    name: 'systemInfo',
    title: '消息中心',
    link: '/developer/accountManagement/systemInfo'
  },
  {
    name: 'deviceInfo',
    title: '自测设备管理',
    link: '/developer/accountManagement/deviceInfo'
  }
];

const QueryConditionShape = PropTypes.shape({
  pageSize: PropTypes.number.isRequired,
  pageNo: PropTypes.number.isRequired
});

class AccountManagement extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired,
    selfDeviceList: PropTypes.array.isRequired,
    changeSelfTestDeviceStatus: PropTypes.func.isRequired,
    getSelfTestDeviceList: PropTypes.func.isRequired,
    addSelfTestDevice: PropTypes.func.isRequired,
    user: PropTypes.object.isRequired,
    originalUser: PropTypes.object.isRequired,
    changeUserInfo: PropTypes.func.isRequired,
    updateAccountInfo: PropTypes.func.isRequired,
    updateDeviceInfo: PropTypes.func.isRequired,
    systemList: PropTypes.array.isRequired,
    queryCondition: QueryConditionShape.isRequired,
    systemInfoTotal: PropTypes.number.isRequired,
    systemInfoStatus: PropTypes.string.isRequired,
    getSystemInfo: PropTypes.func.isRequired,
    onPageNoChange: PropTypes.func.isRequired,
    onPageSizeChange: PropTypes.func.isRequired,
    updateSystemInfo: PropTypes.func.isRequired
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.systemInfoStatus === OperationStatus.initial
      && nextProps.type === accountManagementTabs.systemInfo) {
      this.props.getSystemInfo();
    }
  }

  render() {
    const {
      type,
      selfDeviceList,
      changeSelfTestDeviceStatus,
      getSelfTestDeviceList,
      addSelfTestDevice,
      user,
      originalUser,
      changeUserInfo,
      updateAccountInfo,
      updateDeviceInfo,
      systemList,
      queryCondition,
      systemInfoTotal,
      onPageNoChange,
      onPageSizeChange,
      updateSystemInfo
    } = this.props;
    return (
      <div className={s.root}>
        <div className={s.container}>
          <SelectionBar selectedItem={type} itemList={selectionBarList} />
          <div className={s.contentContainer}>
            <IfComp
              expression={ type === accountManagementTabs.accountInfo }
              trueComp={
                <AccountInfo
                  user={user}
                  originalUser={originalUser}
                  changeUserInfo={changeUserInfo}
                  updateAccountInfo={updateAccountInfo}
                />
              }
              falseComp={
                <IfComp
                  expression={ type === accountManagementTabs.systemInfo }
                  trueComp={
                    <SystemInfo
                      systemList={systemList}
                      queryCondition={queryCondition}
                      total={systemInfoTotal}
                      onPageNoChange={onPageNoChange}
                      onPageSizeChange={onPageSizeChange}
                      updateSystemInfo={updateSystemInfo}
                    />
                  }
                  falseComp={ 
                    <DeviceInfo
                      list={selfDeviceList}
                      changeSelfTestDeviceStatus={changeSelfTestDeviceStatus}
                      getSelfTestDeviceList={getSelfTestDeviceList}
                      addSelfTestDevice={addSelfTestDevice}
                      updateDeviceInfo={updateDeviceInfo}
                    />
                  }
                />
              }
            />
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(AccountManagement);
