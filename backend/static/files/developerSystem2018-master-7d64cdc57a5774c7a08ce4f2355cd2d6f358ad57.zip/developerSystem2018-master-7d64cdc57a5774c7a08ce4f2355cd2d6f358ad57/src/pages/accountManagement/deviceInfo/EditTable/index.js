import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Table, Switch, Select, Icon, Modal, Input, Tooltip } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import EditableCell from './EditableCell';
import { isValidDeviceId, isRepeatDeviceId } from '../../../../core/utils';
import downArrow from '../../../../static/images/ic_arrowdown_blue.png';
import s from './table.css';

const { Option } = Select;
const { TextArea } = Input;
const { warning, confirm } = Modal;

const SHOW_BASE_NUM = 15;

const operationValue = {
  '开启': 0,
  '关闭': 1,
  '删除': 2 
};

class EditTable extends Component {
  static propTypes = {
    list: PropTypes.array.isRequired,
    changeSelfTestDeviceStatus: PropTypes.func.isRequired,
    addSelfTestDevice: PropTypes.func.isRequired,
    updateDeviceInfo: PropTypes.func.isRequired
  }
  constructor(props) {
    super(props);
    const { list } = props;
    this.state = {
      list,
      showList: [...list] && list.slice(0, SHOW_BASE_NUM),
      operateValue: '批量操作',
      selectedRowKeys: [],
      showAll: false,
      visible: false,
      addDeviceId: '',
      addDeviceComment: '',
      deviceIdValid: true,
      deviceIdRepeat: false,
      deviceIdNull: true,
      deviceCommentValid: true
    };
    this.columns = [{
      title: '开关',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (text, record) => (
        <Switch
          checked={!record.status}
          onChange={
            checked => {
              this.props.changeSelfTestDeviceStatus([record.id], checked ? 0 : 1);
              this.setState({ selectedRowKeys: [] });
            }
          }
          disabled={!record.id}
        />
      )
    }, {
      title: '设备号',
      dataIndex: 'deviceId',
      key: 'deviceId',
      width: '600px'
    }, {
      title: '备注',
      dataIndex: 'comment',
      key: 'comment',
      render: (text, record) => (
        <EditableCell
          editTableIndex={`${record.key}0`}
          value={text}
          onCellChange={this.onCellChange(record, 'comment')}
        />
      )
    }];
  }
  
  componentWillReceiveProps(nextProps) {
    const { list } = nextProps;
    const { showAll } = this.state;
    this.setState({ list, showList: showAll ? list : list.slice(0, SHOW_BASE_NUM) });
  }

  // 内容变化的时候
  onCellChange = (record, dataIndex) => value => {
    const dataSource = [...this.state.showList];
    const target = dataSource.find(item => item.deviceId === record.deviceId);
    if (target) {
      target[dataIndex] = value;
      this.setState({ showList: dataSource }, () => {
        this.props.updateDeviceInfo(target.id, value);
      });
    }
  }

  toggleShowList = () => {
    const { showAll, list } = this.state;
    let tempShowList;
    if (!showAll) {
      tempShowList = [...list];
    } else {
      tempShowList = list.slice(0, SHOW_BASE_NUM);
    }
    this.setState({ showAll: !showAll, showList: tempShowList });
  }

  handleAddDeviceOk = () => {
    const {
      addDeviceId,
      addDeviceComment,
      deviceIdRepeat,
      deviceIdValid,
      deviceIdNull,
      deviceCommentValid
    } = this.state;
    const deviceObj = { deviceId: addDeviceId, comment: addDeviceComment };
    if (deviceIdNull) {
      this.setState({ deviceIdValid: false });
      return;
    }
    if (!deviceIdRepeat && deviceIdValid && deviceCommentValid) {
      this.props.addSelfTestDevice(deviceObj);
      this.setState({
        visible: false,
        addDeviceId: '',
        addDeviceComment: '',
        deviceIdNull: true
      });
    }
  }

  handleSelectChange = value => {
    const { selectedRowKeys } = this.state;
    if (selectedRowKeys.length === 0) {
      warning({
        title: '请先勾选表中数据',
        onOk: () => {},
        okText: '确认'
      });
      return;
    } else if (operationValue[value] === 2) {
      confirm({
        title: '确认删除?',
        content: '删除设备号后无法恢复',
        onOk: () => {
          this.props.changeSelfTestDeviceStatus(selectedRowKeys, operationValue[value]);
          this.setState({
            operateValue: '批量操作',
            selectedRowKeys: []
          });
        },
        cancelText: '取消',
        onCancel: () => { this.setState({ operateValue: '批量操作' }); },
        okText: '确认'
      });
    } else {
      this.props.changeSelfTestDeviceStatus(selectedRowKeys, operationValue[value]);
      this.setState({
        operateValue: '批量操作',
        selectedRowKeys: []
      });
    }
  }

  render() {
    const {
      list,
      showList,
      operateValue,
      selectedRowKeys,
      showAll,
      addDeviceId,
      addDeviceComment,
      deviceIdValid,
      deviceIdRepeat,
      deviceIdNull,
      deviceCommentValid
    } = this.state;
    return (
      <Fragment>
        <Modal
          title="增加自测设备"
          visible={this.state.visible}
          onOk={this.handleAddDeviceOk}
          onCancel={
            () => 
              this.setState({
                visible: false,
                addDeviceId: '',
                addDeviceComment: '',
                deviceIdRepeat: false,
                deviceIdValid: true,
                deviceCommentValid: true,
                deviceIdNull: true
              })
          }
          okText='确定'
          cancelText='取消'
        >
          <div className={s.modalRow}>
            <span className={s.modalLabel}>
              设备号&nbsp;
              <Tooltip title="设备号必须是英文字符、数字或-组合而成且长度不能超过100">
                <Icon type="question-circle-o" />
              </Tooltip>
            </span>
            <Input
              value={addDeviceId}
              placeholder='请输入设备号'
              onChange={
                ({ target: { value } }) => {
                  this.setState({
                    addDeviceId: value,
                    deviceIdValid: isValidDeviceId(value),
                    deviceIdRepeat: isRepeatDeviceId(value, list),
                    deviceIdNull: value.trim().length === 0
                  });
                }
              }
            />
            <span
              style={{ display: (!deviceIdValid || deviceIdRepeat) ? 'inline-block' : 'none' }}
              className={s.modalHint}
            >
              <IfComp
                expression={deviceIdRepeat}
                trueComp='设备号填写重复'
                falseComp={deviceIdNull ? '设备号不能为空' : '设备号填写不合法'}
              />
            </span>
          </div>
          <div className={s.modalRow}>
            <span className={s.modalLabel}>备注</span>
            <TextArea
              autosize={{ minRows: 3, maxRows: 4 }}
              value={addDeviceComment}
              placeholder='请输入备注'
              onChange={
                ({ target: { value } }) => {
                  this.setState({
                    addDeviceComment: value,
                    deviceCommentValid: value.trim().length < 100
                  });
                }
              }
            />
            <span
              style={{ display: !deviceCommentValid ? 'inline-block' : 'none' }}
              className={s.modalHint}
            >
              备注填写不合法，请输入100字符以内的内容
            </span>
          </div>
        </Modal>
        <div className={s.borderHeader}>
          <div className={s.addDeviceButton} onClick={() => this.setState({ visible: true })}>
            <Icon
              type='plus-circle'
              style={{ marginRight: '10px' }}
            />
            添加自测设备
          </div>
          <Select
            value={operateValue}
            onChange={this.handleSelectChange}
          >
            <Option value="开启">开启</Option>
            <Option value="关闭">关闭</Option>
            <Option value="删除">删除</Option>
          </Select>
        </div>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: selectedRowKeys => this.setState({ selectedRowKeys }),
            getCheckboxProps: record => ({
              disabled: !record.id
            })
          }}
          rowKey={record => record.id}
          bordered
          dataSource={showList}
          columns={this.columns}
          pagination={false}
        />
        <div
          className={s.showMore}
          style={{ display: list.length > 15 ? 'flex' : 'none' }}
          onClick={this.toggleShowList}
        >
          <span>{showAll ? '收起' : '展开全部'}</span>
          <img
            alt='arrow'
            src={downArrow}
            style={{ transform: showAll ? 'rotate(180deg)' : '' }}
          />
        </div>
      </Fragment>
    );
  }
}

export default withStyles(s)(EditTable);
