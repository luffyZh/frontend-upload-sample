import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Input, Icon } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './table.css';

class EditableCell extends Component {
  static propTypes = {
    onCellChange: PropTypes.func.isRequired,
    value: PropTypes.string
  }

  static defaultProps = {
    value: ''
  }

  state = {
    value: this.props.value,
    editable: false
  }
  componentWillReceiveProps(nextProps) {
    const {
      value
    } = nextProps;
    this.setState({ value });
  }

  handleChange = e => {
    const { value } = e.target;
    this.setState({ value });
  }

  check = () => {
    this.setState({ editable: false });
    if (this.props.onCellChange) {
      this.props.onCellChange(this.state.value);
    }
  }

  edit = () => this.setState({ editable: true });

  render() {
    const { value, editable } = this.state;
    return (
      <div className={s['editable-cell']}>
        {
          editable ? (
            <Input
              value={value}
              onChange={this.handleChange}
              onPressEnter={this.check}
              onBlur={this.check}
              suffix={
                <Icon
                  type='check'
                  className={s['editable-cell-icon-check']}
                  onClick={this.check}
                />
              }
            />
          ) : (
            <div style={{ paddingRight: 24 }}>
              {value || ' '}
              <Icon
                type='edit'
                className={s['editable-cell-icon']}
                onClick={this.edit}
              />
            </div>
          )
        }
      </div>
    );
  }
}

export default withStyles(s)(EditableCell);
