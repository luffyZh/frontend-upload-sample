import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import DebounceInput from 'react-debounce-input';
import { Input } from 'antd';
import cx from 'classnames';
import { AccountTypeForFE } from '../../../constants/MenuTypes';
import {
  checkPhoneIsValid,
  checkUsernameIsValid,
  checkEmailIsValid,
  checkAddressIsValid
} from '../../../core/utils';
import s from '../index.less';

class CompanyComp extends Component {
  static propTypes = {
    user: PropTypes.object.isRequired,
    changeUserInfo: PropTypes.func.isRequired,
    changeFormValid: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const { user } = props;
    this.state = { user };
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.user !== this.props.user) {
      this.setState({ user: nextProps.user });
    }
  }

  render() {
    const { changeUserInfo, changeFormValid } = this.props;
    const { user } = this.state;
    return (
      <Fragment>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>开发者类型</span>
          <span>{AccountTypeForFE[user.type]}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>公司名称</span>
          <span>{user.company}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>联系人</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkUsernameIsValid(user.name)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.name}
            onChange={
              ({ target: { value } }) => {
                user.name = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkUsernameIsValid(user.name));
                });
              }
            }
          />
          <span
            style={{ display: checkUsernameIsValid(user.name) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>联系地址</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkAddressIsValid(user.address)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.address}
            onChange={
              ({ target: { value } }) => {
                user.address = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkAddressIsValid(user.address));
                });
              }
            }
          />
          <span
            style={{ display: checkAddressIsValid(user.address) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>联系电话</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkPhoneIsValid(user.phone)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.phone}
            onChange={
              ({ target: { value } }) => {
                user.phone = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkPhoneIsValid(user.phone));
                });
              }
            }
          />
          <span
            style={{ display: checkPhoneIsValid(user.phone) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>电子邮箱</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkEmailIsValid(user.email)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.email}
            onChange={
              ({ target: { value } }) => {
                user.email = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkEmailIsValid(user.email));
                });
              }
            }
          />
          <span
            style={{ display: checkEmailIsValid(user.email) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
      </Fragment>
    );
  }
}

export default withStyles(s)(CompanyComp);