import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import DebounceInput from 'react-debounce-input';
import { Input } from 'antd';
import cx from 'classnames';
import { AccountTypeForFE, CidTypeForFE } from '../../../constants/MenuTypes';
import {
  checkPhoneIsValid,
  checkEmailIsValid
} from '../../../core/utils';
import s from '../index.less';

class PersonalComp extends Component {
  static propTypes = {
    user: PropTypes.object.isRequired,
    changeUserInfo: PropTypes.func.isRequired,
    changeFormValid: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const { user } = props;
    this.state = { user };
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.user !== this.props.user) {
      this.setState({ user: nextProps.user });
    }
  }

  render() {
    const { changeUserInfo, changeFormValid } = this.props;
    const { user } = this.state;
    return (
      <Fragment>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>账户类型</span>
          <span>{AccountTypeForFE[user.type]}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>账户姓名</span>
          <span>{user.name}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>证件类型</span>
          <span>{CidTypeForFE[user.cidType]}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>证件号</span>
          <span>{user.cid}</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>联系电话</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkPhoneIsValid(user.phone)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.phone}
            onChange={
              ({ target: { value } }) => {
                user.phone = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkPhoneIsValid(user.phone));
                });
              }
            }
          />
          <span
            style={{ display: checkPhoneIsValid(user.phone) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
        <div className={s.accountRow}>
          <span className={s.accountLabel}>电子邮箱</span>
          <DebounceInput
            className={cx({
              [s.accountInput]: true,
              [s.inputError]: !checkEmailIsValid(user.email)
            })}
            element={Input}
            debounceTimeout={600}
            value={user.email}
            onChange={
              ({ target: { value } }) => {
                user.email = value;
                this.setState({ user }, () => {
                  changeUserInfo(user);
                  changeFormValid(checkEmailIsValid(user.email));
                });
              }
            }
          />
          <span
            style={{ display: checkEmailIsValid(user.email) ? 'none' : 'inline-block' }}
            className={s.errorHint}
          >格式出错</span>
        </div>
      </Fragment>
    );
  }
}

export default withStyles(s)(PersonalComp);