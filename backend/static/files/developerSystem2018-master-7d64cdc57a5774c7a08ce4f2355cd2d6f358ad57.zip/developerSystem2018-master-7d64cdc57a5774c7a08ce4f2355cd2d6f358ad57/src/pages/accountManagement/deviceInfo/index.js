import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../../../components/Link';
import EditTable from './EditTable/index';
import s from '../index.less';

class DeviceInfo extends Component {

  static propTypes = {
    list: PropTypes.array.isRequired,
    changeSelfTestDeviceStatus: PropTypes.func.isRequired,
    addSelfTestDevice: PropTypes.func.isRequired,
    updateDeviceInfo: PropTypes.func.isRequired
  }

  render() {
    const { list } = this.props;
    return (
      <Fragment>
        <div className={s.deviceDescription}>
          <h3>说明 </h3>
          接入完成后，进入集成与自测阶段，SDK与API接入需要添加自测设备的设备号，JSSDK对接则无需再添加自测设备号，
          添加之后，等待十五分钟左右，即可请求到自测广告，如有疑问，请参考
          <Link to='/developer/helpCenter' target='_blank'>帮助中心</Link>
          查看详细指导
        </div>
        <div className={s.deviceDescription}>
          <h3>添加自测设备 </h3>
          <EditTable
            list={list}
            changeSelfTestDeviceStatus={this.props.changeSelfTestDeviceStatus}
            addSelfTestDevice={this.props.addSelfTestDevice}
            updateDeviceInfo={this.props.updateDeviceInfo}
          />
        </div> 
      </Fragment>
    );
  }
}

export default withStyles(s)(DeviceInfo);
