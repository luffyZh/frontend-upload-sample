import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Upload, Icon, Modal } from 'antd';
import _ from 'lodash';
import { componentUpdateByState } from '../../../../core/utils';
import s from './index.less';

const { error } = Modal;

const uploadBtn = text => (
  <div className={s['image-uploader-picture-card']}>
    <Icon type="upload" />
    <div className={s['image-uploader-text']}>{text}</div>
  </div>
);

const acceptImageType = ['image/jpg', 'image/jpeg', 'image/png'];

/* eslint-disable no-param-reassign */
// 根据 antd Upload 组件的文件对象的状态更新上传结果
const updateUploadResult = (imgInfo, file) => {
  if (!imgInfo) return;

  const { status, response } = file;

  imgInfo.file = file;
  if (status === 'done' && response) {
    const { resData } = response;
    if (response.errcode === 0) {
      imgInfo.valid = true;
      imgInfo.value = resData.src;
      if (!file.thumbUrl) {
        file.thumbUrl = resData.src;
      }
    } else {
      // 样式设置为错误样式
      file.status = 'error';
      imgInfo.file = undefined;
      imgInfo.valid = false;
      imgInfo.value = '';
      file.response = response.errmsg;
      error({
        title: response.errmsg,
        okText: '确定'
      });
    }
  } else if (status === 'removed') {
    imgInfo.file = undefined;
    imgInfo.value = '';
    imgInfo.valid = false;
  } else if (status === 'error') {
    imgInfo.valid = false;
    imgInfo.value = '';
    // response 为 object 的时候，
    // upload 组件内部会报错
    file.response = response.errmsg;
    error({
      title: '图片上传失败，请稍后重试',
      content: response.errmsg,
      okText: '确定'
    });
  }
};

class ImageUploader extends Component {
  static propTypes = {
    imageInfoList: PropTypes.arrayOf(PropTypes.object.isRequired),
    onImageChange: PropTypes.func,
    maxSize: PropTypes.number.isRequired,
    text: PropTypes.string.isRequired
  };

  static defaultProps = {
    imageInfoList: [],
    onImageChange: null
  };

  constructor(props) {
    super(props);
    const { imageInfoList } = props;
    this.state = {
      imageInfoList,
      previewImageSrc: '',
      previewVisible: false
    };
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentDidMount() {
    const deleteDom = document.getElementsByClassName('anticon-delete');
    Array.from(deleteDom).map(item => {
      item.style.display = 'none';
    });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      imageInfoList: nextProps.imageInfoList
    });
  }

  componentDidUpdate() {
    const deleteDom = document.getElementsByClassName('anticon-delete');
    Array.from(deleteDom).map(item => {
      item.style.display = 'none';
    });
  }

  onPreviewImage = file => {
    this.setState({
      previewImageSrc: file.url || file.thumbUrl,
      previewVisible: true
    });
  };

  onCancelPreview = () => {
    this.setState({
      previewVisible: false
    });
  };

  onImageChange = (index, file) => {
    const { imageInfoList: list } = this.state;
    updateUploadResult(list[index], file);

    const imageInfoList = [...list];
    this.setState(
      {
        imageInfoList
      },
      () => {
        this.props.onImageChange(imageInfoList);
      },
    );
  };

  beforeUploadSingle = file => {
    /* eslint-disable */
    const validType = _.includes(acceptImageType, file.type);
    const validSize = file.size <= this.props.maxSize;
    const valid = validType && validSize;

    const errmsg = [
      validType ? '' : `${file.name}不符合要求`,
      validSize
        ? ''
        : `图片大小（${(file.size / 1024 / 1024).toFixed(2)}MB）不符合要求`,
    ]
      .filter(Boolean)
      .join('，');

    if (!valid) {
      error({
        title: `${errmsg}, 请重新上传！`,
        okText: '确定',
        onOk: () => {
          const { imageInfoList: list} = this.state;
          delete list[0].file;
          const imageInfoList = [...list];
          this.setState({
            imageInfoList
          }, () => this.props.onImageChange(imageInfoList))
        }
      });
      return false;
    }
    return true;
  };

  render() {
    const { imageInfoList, previewImageSrc, previewVisible } = this.state;
    return (
      <div className={s['uploader-area-wrapper']}>
        {imageInfoList.map((imgInfo, index) => {
          let { file } = imgInfo;
          if (!file && imgInfo.valid && imgInfo.value) {
            file = {
              uid: -1,
              name: imgInfo.name,
              status: 'done',
              url: imgInfo.value,
            };
          }
          return (
            <div key={`${imgInfo.id}`} className={s['uploader-wrapper']}>
              <Upload
                action={`/developer/api/appManagement/uploadSlotImageAuditSource`}
                name={`slotAuditImageSource`}
                listType="picture-card"
                fileList={file ? [file] : []}
                withCredentials
                beforeUpload={file => this.beforeUploadSingle(file)}
                onPreview={this.onPreviewImage}
                onChange={({ file: f }) => {
                  this.onImageChange(index, f);
                }}
              >
                {file ? null : uploadBtn(this.props.text)}
              </Upload>
            </div>
          );
        })}
        <Modal
          wrapClassName={s['upload-image-preview-modal']}
          visible={previewVisible}
          footer={null}
          onCancel={this.onCancelPreview}
        >
          <img alt="preview" style={{ width: '100%' }} src={previewImageSrc} />
        </Modal>
      </div>
    );
  }
}

export default ImageUploader;
