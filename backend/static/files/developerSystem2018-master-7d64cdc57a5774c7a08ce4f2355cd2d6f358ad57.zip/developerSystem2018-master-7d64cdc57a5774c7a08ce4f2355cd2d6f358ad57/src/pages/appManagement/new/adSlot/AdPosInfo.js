import React, { Component } from 'react';
import PropTypes from 'prop-types';
import DebounceInput from 'react-debounce-input';
import { Input, Radio, Tooltip, Icon } from 'antd';
import IfComp from 'if-comp';
import {
  classnames,
  updateComponentStateByKeys,
  componentUpdateByState,
  isValidAppAdPosEntityName
} from '../../../../core/utils';
import {
  AdPosObject,
  SlotOpStatusMapForFE,
  AppOs2Label
} from '../../../../constants/MenuTypes';
import s from '../index.less';

const { Group: RadioGroup } = Radio;

const adPosTypeItems = AdPosObject.slice(1).map(t => (
  <Radio
    className={s.radio}
    key={t.value}
    value={t.value}
  >
    {t.name}
  </Radio>
));

const checkAdPosNameValidity = value => isValidAppAdPosEntityName(value);

const settingStyle = {
  marginBottom: '20px',
  paddingBottom: '20px',
  borderBottom: '1px solid #ddd'
};

/* eslint-disable react/no-unused-prop-types */
class AdPosInfo extends Component {
  static propTypes = {
    appName: PropTypes.string,
    adPosName: PropTypes.string.isRequired,
    adPosType: PropTypes.string.isRequired,
    slotCallbackUrl: PropTypes.string,
    onAdPosNameChange: PropTypes.func.isRequired,
    onAdPosTypeChange: PropTypes.func.isRequired,
    onCallBackUrlChange: PropTypes.func.isRequired,
    adPosNameValid: PropTypes.bool.isRequired,
    nameConflict: PropTypes.bool.isRequired,
    isEdit: PropTypes.bool.isRequired,
    slotOpStatus: PropTypes.number.isRequired,
    appOs: PropTypes.number.isRequired
  };

  static defaultProps = {
    appName: '',
    slotCallbackUrl: ''
  };

  constructor(props) {
    super(props);
    const stateKeys = [
      'appName',
      'appPackageName',
      'adPosName',
      'adPosType',
      'slotCallbackUrl',
      'adPosNameValid',
      'nameConflict',
      'adAuditStatus',
      'slotOpStatus',
      'appOs'
    ];
    this.state = {};
    stateKeys.forEach(key => {
      this.state[key] = props[key];
    });
    this.hasFocusAdPosName = false;
    this.hasFocusAppType = false;
    this.componentWillReceiveProps = updateComponentStateByKeys(stateKeys);
    this.shouldComponentUpdate = componentUpdateByState;
  }

  onAdPosNameFocus = () => {
    this.setState({ adPosNameValid: true });
    this.hasFocusAdPosName = true;
  };

  onAdPosNameChange = e => {
    const { value } = e.target;
    this.setState(
      {
        adPosNameValid: checkAdPosNameValidity(value.trim())
      },
      () => {
        this.props.onAdPosNameChange(value.trim());
      },
    );
  };

  onAdPosTypeChange = e => {
    const { value } = e.target;
    this.props.onAdPosTypeChange(value);
  };

  onCallBackUrlChange = e => {
    const { value } = e.target;
    this.props.onCallBackUrlChange(value);
  };

  render() {
    const {
      appName,
      appPackageName,
      adPosName,
      adPosType,
      slotCallbackUrl,
      adPosNameValid,
      nameConflict,
      adAuditStatus,
      slotOpStatus,
      appOs
    } = this.state;
    const { isEdit } = this.props;
    const showAdPosNameError = !adPosNameValid && this.hasFocusAdPosName;
    // 删除状态不可编辑，编辑状态且样式不是草稿不可编辑
    const slotNameDisabled = (slotOpStatus === SlotOpStatusMapForFE.已删除) || (isEdit && (adAuditStatus !== -1));
    return (
      <div className={s.setting} style={settingStyle}>
        <div className={s.setting__title}>广告位信息</div>
        <div className={s['setting-item']}>
          <div className={s['setting-item__name']}>应用名称</div>
          <div className={s['setting-item__value']}>
            <div className={s.appAdPosName}>{appName}</div>
          </div>
        </div>
        <div className={s['setting-item']}>
          <div className={s['setting-item__name']}>{AppOs2Label[appOs]}</div>
          <div className={s['setting-item__value']}>
            <div className={s.appAdPosName}>{appPackageName}</div>
          </div>
        </div>
        <div style={{ paddingTop: 6 }}>
          <div className={s['setting-item']}>
            <div className={s['setting-item__name']}>
              广告位名称&nbsp;
              <Tooltip title='开屏类型广告直接填写“开屏”，其他类型广告位建议按此规范填写：所处页面+所处屏数（用户滑至第几屏可见广告位）+广告位类型，如“新闻页二屏信息流”、“发现页一屏焦点图”'>
                <Icon type="question-circle-o" />
              </Tooltip>
            </div>
            <div className={s['setting-item__value']}>
              <DebounceInput
                element={Input}
                debounceTimeout={600}
                ref={input => {
                  this.entityName = input;
                }}
                value={adPosName}
                className={classnames({
                  [s.input]: true,
                  [s['adentity-name-input']]: true,
                  [s.error]: nameConflict || showAdPosNameError
                })}
                onChange={this.onAdPosNameChange}
                onFocus={this.onAdPosNameFocus}
                onBlur={
                  ({ target: { value } }) =>
                    this.setState({ adPosNameValid: checkAdPosNameValidity(value) })
                }
                disabled={slotNameDisabled}
              />
              <div
                className={classnames({
                  [s['input-hint']]: true,
                  [s.error]: nameConflict || showAdPosNameError
                })}
              >
                {nameConflict ? '广告位名称重复' : '必填，最多 15 个字'}
              </div>
            </div>
          </div>
          <div className={s['setting-item']}>
            <div
              className={classnames({
                [s['setting-item__name']]: true,
                [s['radio']]: true
              })}
            >
              广告位类型
            </div>
            <div className={s['setting-item__value']}>
              <RadioGroup
                size="large"
                value={adPosType}
                onChange={this.onAdPosTypeChange}
                disabled={isEdit}
              >
                {adPosTypeItems}
              </RadioGroup>
            </div>
          </div>
          <IfComp
            expression={adPosType === AdPosObject[5].value}
            trueComp={
              <div className={s['setting-item']}>
                <div className={s['setting-item__name']}>回调地址</div>
                <div className={s['setting-item__value']}>
                  <DebounceInput
                    element={Input}
                    value={slotCallbackUrl}
                    debounceTimeout={600}
                    className={classnames({
                      [s.input]: true,
                      [s['android-item_value']]: true
                    })}
                    onChange={this.onCallBackUrlChange}
                    disabled={isEdit && (adAuditStatus !== -1)}
                  />
                  <div
                    className={classnames({
                      [s['input-hint']]: true
                    })}
                  >
                  该项视需求选填，是callback_url字段链接，相应的callback_url_secret_key会线下沟通发送
                  </div>
                </div>
              </div>
            }
          />
        </div>
      </div>
    );
  }
}

export { AdPosInfo as default, checkAdPosNameValidity };
