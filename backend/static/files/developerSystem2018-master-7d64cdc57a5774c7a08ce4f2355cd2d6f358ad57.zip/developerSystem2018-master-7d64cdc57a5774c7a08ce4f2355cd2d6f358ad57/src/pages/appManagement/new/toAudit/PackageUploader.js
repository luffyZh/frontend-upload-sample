import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Upload, Icon, Modal } from 'antd';
import _ from 'lodash';
import IfComp from 'if-comp';
import { componentUpdateByState } from '../../../../core/utils';
import DownloadFile from './DownloadFile';
import UploadProgress from './UploadProgress';
import s from './index.less';

const { error } = Modal;

const uploadBtn = text => (
  <div className={s['image-uploader-picture-card']}>
    <Icon type="upload" />
    <div className={s['image-uploader-text']}>{text}</div>
  </div>
);

/* eslint-disable no-param-reassign */
// 根据 antd Upload 组件的文件对象的状态更新上传结果
const updateUploadResult = (packageInfo, file) => {
  if (!packageInfo) return;

  const { status, response } = file;

  packageInfo.file = file;
  if (status === 'done' && response) {
    const { resData } = response;
    if (response.errcode === 0 && resData.success) {
      packageInfo.valid = true;
      packageInfo.value = resData.appPackage;
      packageInfo.name = file.name;
    } else {
      // 样式设置为错误样式
      file.status = 'error';
      packageInfo.file = undefined;
      packageInfo.valid = false;
      packageInfo.value = '';
      file.response = response.errmsg;
      error({
        title: '安装包上传失败，请稍后重试',
        okText: '确定'
      });
    }
  } else if (status === 'removed') {
    packageInfo.file = undefined;
    packageInfo.value = '';
    packageInfo.valid = false;
  } else if (status === 'error') {
    packageInfo.file = undefined;
    packageInfo.valid = false;
    packageInfo.value = '';
    // response 为 object 的时候，
    file.response = response.errmsg;
    error({
      title: '安装包上传失败，请稍后重试',
      content: response.errmsg,
      okText: '确定'
    });
  }
};

class PackageUploader extends Component {
  static propTypes = {
    packageInfoList: PropTypes.arrayOf(PropTypes.object.isRequired),
    onPackageChange: PropTypes.func.isRequired,
    maxSize: PropTypes.number.isRequired,
    text: PropTypes.string.isRequired,
    slotUdid: PropTypes.string.isRequired,
    packageType: PropTypes.number.isRequired
  };

  static defaultProps = {
    packageInfoList: []
  };

  constructor(props) {
    super(props);
    const { packageInfoList } = props;
    this.state = {
      packageInfoList
    };
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      packageInfoList: nextProps.packageInfoList
    });
  }

  onPackageChange = (index, file, event) => {
    const { packageInfoList: list } = this.state;
    updateUploadResult(list[index], file);
    const progress = this.getUploadProgress(list[index].valid, event);
    const packageInfoList = [...list];
    this.setState(
      {
        packageInfoList,
        progress
      },
      () => {
        this.props.onPackageChange(packageInfoList);
      },
    );
  };

  getUploadProgress = (backRes, event) => {
    const { progress } = this.state;
    if (backRes) {
      return 100;
    }
    const frontProgress = (event && event.percent) || 0;
    return frontProgress === 100
      ? progress
      : parseInt(frontProgress, 10);
  }

  beforeUploadSingle = file => {
    const { packageType } = this.props;
    const acceptPackageType = [
      'application/vnd.android.package-archive',
      'application/iphone-package-archive',
      'application/x-itunes-ipa',
      ''
    ];
    const acceptPackagePrefix = [packageType === 0 ? '.ipa' : '.apk'];
    /* eslint-disable */
    const validType = _.includes(acceptPackageType, file.type)
    const validSize = file.size <= this.props.maxSize;
    const validPrefix = _.includes(acceptPackagePrefix, file.name.substring(file.name.lastIndexOf('.'), file.name.length));
    const valid = validType && validSize && validPrefix;
    const errmsg = [
      (validType && validPrefix) ? '' : `${file.name} 不符合要求`,
      validSize
        ? ''
        : `安装包大小（${(file.size / 1024 / 1024).toFixed(2)}MB）不符合要求`,
    ]
      .filter(Boolean)
      .join('，');

    if (!valid) {
      /*  排查线上问题，线下从未出现过 */
      window.localStorage.setItem('ead-youdao-package-type', file.type);
      window.localStorage.setItem('ead-youdao-package-name', file.name);
      error({
        title: `${errmsg}, 请重新上传！`,
        okText: '确定',
        onOk: () => {
          const { packageInfoList: list} = this.state;
          delete list[0].file;
          const packageInfoList = [...list];
          this.setState({
            packageInfoList
          }, () => this.props.onPackageChange(packageInfoList))
        },
      });
      return false;
    }
    return true;
  };

  deletePackage = () => {
    const { packageInfoList: list } = this.state;
    const packageInfoList = [...list];
    packageInfoList[0].name = 'app-package';
    delete packageInfoList[0].file;
    packageInfoList[0].valid = false;
    this.setState(
      {
        packageInfoList,
      },
      () => {
        this.props.onPackageChange(packageInfoList);
      },
    );
  }

  render() {
    const { slotUdid, canDelete } = this.props;
    const { packageInfoList, progress } = this.state;
    return (
      <div className={s['uploader-area-wrapper']}>
        {packageInfoList.map((packageInfo, index) => {
          let { file } = packageInfo;
          if (!file && packageInfo.valid && packageInfo.value) {
            file = {
              uid: -1,
              name: packageInfo.name,
              status: 'done',
              url: packageInfo.value,
            };
          }
          return (
            <div key={`${packageInfo.id}`} className={s['uploader-wrapper']}>
              <IfComp
                expression={(file && packageInfo.valid)}
                trueComp={
                  <DownloadFile
                    canDelete={canDelete}
                    filename={file && file.name}
                    slotUdid={slotUdid}
                    deletePackage={this.deletePackage}
                    packageName={packageInfo.name}
                  />
                }
                falseComp={
                  <Upload
                    action={`/developer/api/appManagement/uploadSlotPackageAuditSource/${slotUdid}`}
                    name={`slotAuditPackageSource`}
                    listType="picture-card"
                    fileList={file ? [file] : []}
                    showUploadList={false}
                    withCredentials
                    beforeUpload={file => this.beforeUploadSingle(file)}
                    onChange={({ file: f, event }) => {
                      this.onPackageChange(index, f, event);
                    }}
                  >
                    {file ? <UploadProgress progress={progress} /> : uploadBtn(this.props.text)}
                  </Upload>
                }
              />
            </div>
          );
        })}
      </div>
    );
  }
}

export default PackageUploader;
