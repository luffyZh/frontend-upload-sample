import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './index.less';

class UploadProgress extends Component {
  static propTypes = {
    progress: PropTypes.number
  }
  static defaultProps = {
    progress: 0
  }
  constructor(props) {
    super(props);
    const {
      progress
    } = props;
    this.state = {
      progress
    };
  }

  componentWillReceiveProps({ progress }) {
    this.setState({ progress });
  }

  render() {
    const { progress } = this.state;
    return (
      <div className={s.progressContainer}>
        <span className={s.downloadText}>{progress}%</span>
        <span className={s.downloadText}>正在上传...</span>
        <div className={s.progressHover}>
          <div className={s.wave} style={{ height: `${100 + progress}%` }} />
        </div>
      </div>
    );
  }
}
export default withStyles(s)(UploadProgress);