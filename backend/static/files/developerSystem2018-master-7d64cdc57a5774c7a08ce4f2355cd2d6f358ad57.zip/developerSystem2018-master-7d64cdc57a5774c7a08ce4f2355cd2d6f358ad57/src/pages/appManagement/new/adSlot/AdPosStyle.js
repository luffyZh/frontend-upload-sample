import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import DebounceInput from 'react-debounce-input';
import { Icon, Input, Radio, Tooltip } from 'antd';
import {
  AdPosAuditStatus,
  objectTypeItems,
  imageElemsMapKey,
  textElemsMapKey,
  videoElemsMapKey,
  flowStyleItems,
  AdPosObject,
  AdPosTypeForFE,
  SlotAuditStatusForFE,
  AppAdposStyleNewMapForFE,
  AppAdposNewMapForBE,
  SlotOpStatusMapForFE
} from '../../../../constants/MenuTypes';
import {
  classnames,
  updateComponentStateByKeys,
  componentUpdateByState,
  isValidAppAdPosEntityName,
  generateStyleTotalKeyMap
} from '../../../../core/utils';
import DataGrid from './DataGrid';
import s from '../index.less';
import s2 from './index.less';

const { Group: RadioGroup, Button: RadioButton } = Radio;
const objectTypes = objectTypeItems.map(t => (
  <RadioButton value={t.value} key={t.value}>
    <Icon className={s2['checked-object']} type="check-circle" />
    {t.name}
  </RadioButton>
));

const appVersionTip = (
  <Tooltip title="如果APP的某个版本及以上才支持该广告位样式，则需修改填写相应版本号（格式为N.N.N.，如5.7.3），如果没有版本限制，则默认为0.0.0，无需修改此项。">
    <Icon type="question-circle-o" />
  </Tooltip>
);

const checkStyleNameValidity = value => isValidAppAdPosEntityName(value);

/* eslint-disable react/no-unused-prop-types */
class AdPosStyle extends Component {
  static propTypes = {
    styleTitle: PropTypes.string.isRequired,
    styleAuditStatus: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    styleType: PropTypes.number.isRequired,
    minSupportVersion: PropTypes.string,
    imageElemsList: PropTypes.arrayOf(PropTypes.string.isRequired),
    imageElements: PropTypes.arrayOf(PropTypes.object),
    textElemsList: PropTypes.arrayOf(PropTypes.string.isRequired),
    textElements: PropTypes.arrayOf(PropTypes.object),
    videoElemsList: PropTypes.arrayOf(PropTypes.string.isRequired),
    videoElements: PropTypes.arrayOf(PropTypes.object),
    adPosType: PropTypes.string.isRequired,
    onAddElem: PropTypes.func,
    onDelStyle: PropTypes.func,
    isShowDel: PropTypes.bool.isRequired,
    isEdit: PropTypes.bool.isRequired,
    styleName: PropTypes.string,
    schemaStandardTemplateName: PropTypes.string,
    styleStandardTemplateId: PropTypes.number,
    onStyleNameChange: PropTypes.func.isRequired,
    onStyleNameBlur: PropTypes.func.isRequired,
    onObjectChange: PropTypes.func.isRequired,
    onAppVersionChange: PropTypes.func.isRequired,
    onElemInfoItemChange: PropTypes.func.isRequired,
    styleNameValid: PropTypes.bool,
    presetStandardData: PropTypes.object.isRequired,
    slotOpStatus: PropTypes.number.isRequired,
    styleNameRepeat: PropTypes.bool.isRequired,
    versionValid: PropTypes.bool.isRequired
  };

  static defaultProps = {
    imageElements: [],
    textElements: [],
    videoElements: [],
    imageElemsList: [],
    textElemsList: [],
    videoElemsList: [],
    onAddElem: null,
    onDelStyle: null,
    styleName: '',
    schemaStandardTemplateName: '',
    styleStandardTemplateId: 1,
    styleNameValid: true,
    minSupportVersion: ''
  };

  constructor(props) {
    super(props);
    const {
      styleTitle,
      styleName,
      styleAuditStatus,
      styleType,
      minSupportVersion,
      schemaStandardTemplateName,
      styleStandardTemplateId,
      imageElemsList,
      imageElements,
      textElemsList,
      textElements,
      videoElemsList,
      videoElements,
      adPosType,
      isShowDel,
      styleNameValid,
      presetStandardData,
      slotOpStatus,
      styleNameRepeat,
      versionValid
    } = this.props;
    this.state = {
      slotOpStatus,
      styleTitle,
      styleName,
      styleAuditStatus,
      styleType,
      minSupportVersion,
      schemaStandardTemplateName,
      styleStandardTemplateId,
      imageElemsList,
      imageElements,
      textElemsList,
      textElements,
      videoElemsList,
      videoElements,
      adPosType,
      isShowDel,
      styleNameValid,
      presetStandardData,
      styleNameRepeat,
      versionValid
    };
    this.componentWillReceiveProps = updateComponentStateByKeys([
      'styleTitle',
      'styleName',
      'styleAuditStatus',
      'styleType',
      'minSupportVersion',
      'schemaStandardTemplateName',
      'styleStandardTemplateId',
      'imageElemsList',
      'imageElements',
      'textElemsList',
      'textElements',
      'videoElemsList',
      'videoElements',
      'adPosType',
      'isShowDel',
      'styleNameValid',
      'presetStandardData',
      'slotOpStatus',
      'styleNameRepeat',
      'versionValid'
    ]);
    this.shouldComponentUpdate = componentUpdateByState;
    this.hasFocusStyleName = false;
  }

  onStyleNameFocus = () => {
    this.hasFocusStyleName = true;
  };

  onStyleNameChange = e => {
    const { value } = e.target;
    this.setState(
      {
        styleNameValid: checkStyleNameValidity(value)
      },
      () => {
        this.props.onStyleNameChange(value, checkStyleNameValidity(value));
      },
    );
  };

  onStyleNameBlur = e => {
    const { value } = e.target;
    const { styleNameValid } = this.state;
    this.props.onStyleNameBlur(value, styleNameValid);
  }

  // 判断广告位是否是可编辑的广告位
  checkIsAbleEdit = (slotOpStatus, styleAuditStatus) => {
    const { isEdit } = this.props;
    // 如果是已删除，直接返回不可编辑
    if (slotOpStatus === SlotOpStatusMapForFE.已删除) {
      return false;
    }
    // 如果是新建状态直接返回可编辑， 否则编辑状态下如果是草稿和审核不通过的广告位返回的是可编辑
    return (!isEdit)
      ? true
      : (SlotAuditStatusForFE[styleAuditStatus] === AdPosAuditStatus[1].name)
        || (SlotAuditStatusForFE[styleAuditStatus] === AdPosAuditStatus[4].name); 
  }

  render() {
    const {
      styleTitle,
      styleName,
      styleAuditStatus,
      styleType,
      minSupportVersion,
      schemaStandardTemplateName,
      styleStandardTemplateId,
      imageElemsList,
      imageElements,
      textElemsList,
      textElements,
      videoElemsList,
      videoElements,
      adPosType,
      isShowDel,
      styleNameValid,
      presetStandardData,
      slotOpStatus,
      styleNameRepeat,
      versionValid
    } = this.state;

    const {
      onAddElem,
      onDelStyle,
      onObjectChange,
      onAppVersionChange,
      onElemInfoItemChange
    } = this.props;
    const styleTitleName =
      styleTitle === AdPosObject[1].value
        ? (flowStyleItems.find(t => t.value === AdPosTypeForFE[styleStandardTemplateId])
          && flowStyleItems.find(t => t.value === AdPosTypeForFE[styleStandardTemplateId]).name || '信息流')
        : (AdPosObject.find(t => t.value === styleTitle)
          && AdPosObject.find(t => t.value === styleTitle).name) || '自定义';
    const isAbleAddAndDel = slotOpStatus !== SlotOpStatusMapForFE.已删除 && // 不是已删除可以添加
      (SlotAuditStatusForFE[styleAuditStatus] === AdPosAuditStatus[1].name ||
        SlotAuditStatusForFE[styleAuditStatus] === AdPosAuditStatus[4].name) && // 草稿状态和审核不通过状态可以添加
      adPosType !== AdPosObject[5].value; // 不是视频视频可以添加
    const isAbleEdit = this.checkIsAbleEdit(slotOpStatus, styleAuditStatus);
    console.log('样式是否可以编辑', isAbleEdit);
    console.log('是否可以添加样式', isAbleAddAndDel);
    console.log('样式名重复', styleNameRepeat);
    const showStyleNameError = !styleNameValid || styleNameRepeat; // && this.hasFocusStyleName;
    return (
      <div className={s2.setting__body_common}>
        <div className={s2.setting__body_header}>
          <div className={s2.setting__body_header_left}>
            <span>{styleTitleName}样式</span>
            <span>审核状态： {SlotAuditStatusForFE[styleAuditStatus]}</span>
          </div>
          <IfComp
            expression={
              styleAuditStatus === AdPosAuditStatus[1].name && isShowDel
            }
            trueComp = {
              <div className={s2.setting__body_header_right}>
                <Icon type="close" onClick={onDelStyle} />
              </div>
            }
          />
        </div>
        <div className={s2.setting__body_content}>
          <div className={s2['setting__body_item']}>
            <div className={s2['setting__body_item__name']}>
              样式名称&nbsp;
              <Tooltip title='建议以推广位名称+样式类型命名，如信息流一屏首页-落地页、信息流一屏搜索页-搜索-一键下载类等'>
                <Icon type="question-circle-o" />
              </Tooltip>
            </div>
            <div className={s2['setting__body_item__value']}>
              <DebounceInput
                element={Input}
                debounceTimeout={600}
                ref={input => {
                  this.entityName = input;
                }}
                className={classnames({
                  [s.input]: true,
                  [s2['adentity-name-input']]: true,
                  [s.error]: showStyleNameError
                })}
                value={styleName || schemaStandardTemplateName}
                onChange={this.onStyleNameChange}
                onBlur={this.onStyleNameBlur}
                onFocus={this.onStyleNameFocus}
                disabled={!isAbleEdit}
              />
              <div
                className={classnames({
                  [s['input-hint']]: true,
                  [s.error]: showStyleNameError
                })}
              >
                {styleNameRepeat ? '样式名称重复' : '必填，最多 15 个字'}
              </div>
            </div>
          </div>
          <div
            className={classnames({
              [s2['setting__body_item']]: true
            })}
            style={{ paddingTop: 6 }}
          >
            <div className={s2['setting__body_item__name']}>
              推广标的类型&nbsp;
              <IfComp
                expression={styleType === 3}
                trueComp={
                  <Tooltip title='仅支持打开网页链接，含普通网页和在落地页下载 APP 的网页'>
                    <Icon type="question-circle-o" />
                  </Tooltip>
                }
              />
              <IfComp
                expression={styleType === 1}
                trueComp={
                  <Tooltip title='安卓端：支持点击APP安装包链接直接下载；iOS端：跳转至App Store 下载链接进行APP下载'>
                    <Icon type="question-circle-o" />
                  </Tooltip>
                }
              />
            </div>
            <div className={s2['setting__body_item__value']}>
              <RadioGroup
                size="large"
                value={AppAdposStyleNewMapForFE[styleType]}
                onChange={e => onObjectChange(AppAdposNewMapForBE[e.target.value])}
                disabled={!isAbleEdit}
              >
                {objectTypes}
              </RadioGroup>
            </div>
          </div>
          <div className={s2['setting__body_item']}>
            <div className={s2['setting__body_item__name']}>
              可兼容的最低版本号 {appVersionTip}
            </div>
            <div className={s2['setting__body_item__value']}>
              <DebounceInput
                debounceTimeout={600}
                element={Input}
                ref={input => {
                  this.entityName = input;
                }}
                className={classnames({
                  [s.input]: true,
                  [s2['minSupportVersion-name-input']]: true
                })}
                value={minSupportVersion}
                onChange={e => {
                  onAppVersionChange(e.target.value);
                }}
                onFocus={this.onAppNameFocus}
                disabled={!isAbleEdit}
              />
              <div
                className={classnames({
                  [s['input-hint']]: true,
                  [s.error]: !versionValid
                })}
              >
                {versionValid ? '此版本及以上版本支持该样式' : '版本号填写不合法'}
              </div>
            </div>
          </div>
          <div className={s2.setting__body_elems}>
            <DataGrid
              standardElements={presetStandardData.standardElements}
              isAbleAddAndDel={isAbleAddAndDel}
              isAbleEdit={isAbleEdit}
              elemType="图片元素"
              elemItems={imageElemsList}
              elems={imageElements}
              elemsMapKey={imageElemsMapKey}
              onAddElem={onAddElem}
              onDelElem={onAddElem}
              adPosType={adPosType}
              styleStandardTemplateId={styleStandardTemplateId}
              onElemInfoItemChange={elems =>
                onElemInfoItemChange('imageElements', elems)
              }
              totalElementsKeys={generateStyleTotalKeyMap(imageElements, textElements, videoElements)}
            />
          </div>
          <div className={s2.setting__body_elems}>
            <DataGrid
              standardElements={presetStandardData.standardElements}
              isAbleAddAndDel={isAbleAddAndDel}
              isAbleEdit={isAbleEdit}
              elemType="文字元素"
              elemItems={textElemsList}
              elems={textElements}
              elemsMapKey={textElemsMapKey}
              onAddElem={onAddElem}
              onDelElem={onAddElem}
              adPosType={adPosType}
              styleStandardTemplateId={styleStandardTemplateId}
              onElemInfoItemChange={elems =>
                onElemInfoItemChange('textElements', elems)
              }
              totalElementsKeys={generateStyleTotalKeyMap(imageElements, textElements, videoElements)}
            />
          </div>
          <IfComp
            expression={
              adPosType === AdPosObject[5].value ||
              adPosType === AdPosObject[7].value ||
              (adPosType === AdPosObject[1].value &&
                AdPosTypeForFE[styleStandardTemplateId] === flowStyleItems[3].value)
            }
            trueComp={
              <div className={s2.setting__body_elems}>
                <DataGrid
                  standardElements={presetStandardData.standardElements}
                  isAbleAddAndDel={
                    false ||
                    (adPosType === AdPosObject[7].value &&
                      SlotAuditStatusForFE[styleAuditStatus] === AdPosAuditStatus[1].name &&
                      slotOpStatus !== SlotOpStatusMapForFE.已删除
                    ) // 自定义可以添加视频
                  }
                  isAbleEdit={false}
                  elemType="视频元素"
                  elemItems={videoElemsList}
                  elems={videoElements}
                  elemsMapKey={videoElemsMapKey}
                  adPosType={adPosType}
                  onAddElem={onAddElem}
                  onDelElem={onAddElem}
                />
              </div>
            }
          />
        </div>
      </div>
    );
  }
}

export default withStyles(s2)(AdPosStyle);
