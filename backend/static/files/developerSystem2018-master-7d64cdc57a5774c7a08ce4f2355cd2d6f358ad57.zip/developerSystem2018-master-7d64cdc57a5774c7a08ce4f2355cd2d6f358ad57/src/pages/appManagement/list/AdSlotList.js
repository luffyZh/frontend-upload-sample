import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Table, LocaleProvider, Switch } from 'antd';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import IfComp from 'if-comp';
import _ from 'lodash';
import cx from 'classnames';
import Link from '../../../components/Link';
import {
  AppTabTypes,
  PageSizeOptions,
  OperationStatus,
  AppAdposListMapForFE as StatusForFE,
  AppEntitySwitchStatusMapForFE,
  SlotOpStatusForFE,
  SlotAuditStatusForFE,
  SlotOpStatusMapForFE
} from '../../../constants/MenuTypes';
import TableColumns from './TableColumns';
import s from './index.less';

const { appTab, adPosTab, appAdPosTab } = AppTabTypes;

const getColumns = (type, onSwitchChange) => {
  switch (type) {
    case appTab:
      return [
        TableColumns.switchBtn(type, onSwitchChange),
        TableColumns.appName(type),
        TableColumns.osType,
        TableColumns.reqAdNum,
        TableColumns.resAdNum,
        TableColumns.fillRate,
        TableColumns.imprNum,
        TableColumns.imprRate,
        TableColumns.clickNum,
        TableColumns.clickRate
        // TableColumns.ecpm,
        // TableColumns.cpc,
        // TableColumns.estimateProfit
      ];
    case adPosTab:
    case appAdPosTab:
      return [
        TableColumns.switchBtn(type, onSwitchChange),
        TableColumns.adPosName(type),
        TableColumns.onApp(type),
        TableColumns.adPosId(type),
        TableColumns.adPosType,
        TableColumns.auditStatus,
        TableColumns.reqAdNum,
        TableColumns.resAdNum,
        TableColumns.fillRate,
        TableColumns.imprNum,
        TableColumns.imprRate,
        TableColumns.clickNum,
        TableColumns.clickRate
        // TableColumns.ecpm,
        // TableColumns.cpc,
        // TableColumns.estimateProfit
      ];
    default:
      return [];
  }
};

const getTableRowClassName = record =>
  record.status === StatusForFE.暂停 ? s.deleted : '';

const appListShape = PropTypes.shape({
  status: PropTypes.oneOf(_.keys(OperationStatus)).isRequired,
  total: PropTypes.number.isRequired,
  list: PropTypes.array.isRequired
});

const getTableRowCheckboxProps = record => ({
  disabled: record.slotOpStatus === SlotOpStatusMapForFE.已删除
});

const getTableData = data =>
  data.map(item => {
    return {
      ...item,
      key: item.slotUdid
    };
  });

class AdSlotList extends Component {
  static propTypes = {
    tabType: PropTypes.oneOf(_.keys(AppTabTypes)).isRequired,
    data: appListShape.isRequired,
    pageSize: PropTypes.number.isRequired,
    pageNo: PropTypes.number.isRequired,
    selectedRowKeys: PropTypes.array.isRequired,
    onRowSelectionChange: PropTypes.func.isRequired,
    onPageSizeChange: PropTypes.func.isRequired,
    onPageNoChange: PropTypes.func.isRequired,
    onSwitchChange: PropTypes.func,
    onStyleSwitchChange: PropTypes.func.isRequired,
    appName: PropTypes.string.isRequired
  };
  static defaultProps = {
    onSwitchChange: null
  };

  constructor(props) {
    super(props);
    const {
      tabType,
      data,
      pageSize,
      pageNo,
      onSwitchChange,
      selectedRowKeys
    } = props;
    this.state = {
      columns: getColumns(tabType, onSwitchChange),
      list: data.list.length === 0 ? [] : getTableData(data.list, tabType),
      total: data.total,
      pageSize,
      pageNo,
      selectedRowKeys
    };
  }

  componentWillReceiveProps({
    tabType,
    data,
    pageSize,
    pageNo,
    onSwitchChange,
    selectedRowKeys
  }) {
    const newState = {
      total: data.total,
      pageSize,
      pageNo,
      selectedRowKeys
    };
    if (data.statisticList.length > 0) {
      const { statisticList } = data;
      data.list.map(item => {
        const dataItem = statisticList.find(ele => ele.slotUdid === item.slotUdid);
        item = _.assign(item, dataItem);
      });
    }
    if (tabType !== this.props.tabType) {
      newState.columns = getColumns(tabType, onSwitchChange);
    }
    if (data !== this.props.data) {
      newState.list =
        data.list.length === 0 ? [] : getTableData(data.list);
    }
    this.setState(newState);
  }

  expandedRowRender = record => {
    return (
      <div className={s.styleContent}>
        <div className={s.styleRow}>
          <div style={{ display: 'inline-block', width: '56px' }} />
          <div className={cx(s.styleH, s.styleNameH)}>样式名称</div>
          <div className={cx(s.styleH, s.styleIdH)}>样式ID</div>
          <div className={cx(s.styleH, s.styleAuditStatusH)}>审核状态</div>
        </div>
        <IfComp
          expression={!!record.styleList}
          trueComp={
            record.styleList && record.styleList.map(st => (
              <div key={st.styleId} className={s.styleRow}>
                <div className={s.styles}>
                  <div className={s.styleSwitch}>
                    <Switch
                      size="small"
                      disabled={
                        SlotOpStatusForFE[st.styleOpStatus] === AppEntitySwitchStatusMapForFE.已禁用
                      }
                      checked={SlotOpStatusForFE[st.styleOpStatus] === AppEntitySwitchStatusMapForFE.已开启}
                      onChange={checked => {
                        this.props.onStyleSwitchChange(
                          record.slotUdid,
                          st.styleId,
                          checked,
                        );
                      }}
                      key={st.slotId}
                    />
                  </div>
                  <div className={s.schemaStandardTemplateName}>{st.styleName}</div>
                  <div className={s.styleId}>{st.styleId}</div>
                  <div className={s.styleAuditStatus}>{SlotAuditStatusForFE[st.styleAuditStatus]}</div>
                </div>
              </div>
            ))
          }
          falseComp={
            <div className={s.styleRow}>
              当前广告位样式已删除
            </div>
          }
        />
        
      </div>
    );
  };

  render() {
    const {
      onRowSelectionChange,
      onPageSizeChange,
      onPageNoChange,
      tabType
    } = this.props;
    const {
      loading,
      selectedRowKeys,
      columns,
      list,
      total,
      pageSize,
      pageNo
    } = this.state;

    // const xScroll = tabType === AppTabTypes.appTab ? 1460 : 1960;
    const xScroll = columns.map(x => parseInt(x.width, 10)).reduce((acc, cur) => acc + cur) + 100;
    // const xScroll = tabType === AppTabTypes.appTab ? 1460 : 1780;

    return (
      <Fragment>
        <IfComp
          expression={tabType === AppTabTypes.appAdPosTab}
          trueComp={
            <div className={s.locationBar}>
              <span className={s.title}>当前位置:</span>&nbsp;&nbsp;
              <Link to='/developer/appManagement/app'>应用列表</Link>
                &nbsp;&nbsp;&gt;&nbsp;&nbsp;
              <span>{this.props.appName}</span>
            </div>
          }
        />
        <section className={s.list}>
          <LocaleProvider locale={zhCN}>
            <IfComp
              expression={tabType === AppTabTypes.appTab}
              trueComp={
                <Table
                  rowSelection={{
                    selectedRowKeys,
                    getCheckboxProps: getTableRowCheckboxProps,
                    onChange: onRowSelectionChange
                  }}
                  rowClassName={getTableRowClassName}
                  columns={columns}
                  dataSource={list}
                  bordered
                  loading={loading}
                  scroll={{ x: xScroll }}
                  pagination={{
                    size: 'small',
                    current: pageNo,
                    pageSize,
                    showSizeChanger: true,
                    pageSizeOptions: PageSizeOptions,
                    total,
                    onChange: onPageNoChange,
                    onShowSizeChange: onPageSizeChange
                  }}
                />
              }
              falseComp={
                <Table
                  rowSelection={{
                    selectedRowKeys,
                    getCheckboxProps: getTableRowCheckboxProps,
                    onChange: onRowSelectionChange
                  }}
                  rowClassName={getTableRowClassName}
                  columns={columns}
                  dataSource={list}
                  bordered
                  loading={loading}
                  scroll={{ x: xScroll }}
                  pagination={{
                    size: 'small',
                    current: pageNo,
                    pageSize,
                    showSizeChanger: true,
                    pageSizeOptions: PageSizeOptions,
                    total,
                    onChange: onPageNoChange,
                    onShowSizeChange: onPageSizeChange
                  }}
                  expandedRowRender={this.expandedRowRender}
                />
              }
            />
          </LocaleProvider>
        </section>
      </Fragment>
    );
  }
}

export { AdSlotList as default, appListShape };
