import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import _ from 'lodash';
import AdPosInfo, { checkAdPosNameValidity } from './AdPosInfo';
import StyleInfo, { checkStyleInfoValidity } from './StyleInfo';
import FormFooterActionBar from '../FormFooterActionBar';
import {
  NewAdPosSettingItems,
  OperationStatus,
  saveButtonText,
  AdPosTypeForBE
} from '../../../../constants/MenuTypes';
import {
  componentUpdateByState,
  checkStyleInfoNameIsRepeat,
  checkVersionIsValid
} from '../../../../core/utils';
import s from '../index.less';
import s2 from './index.less';

class AdSlot extends Component {
  static propTypes = {
    status: PropTypes.oneOf(_.keys(OperationStatus)).isRequired,
    appTag: PropTypes.bool.isRequired,
    adPosTag: PropTypes.bool.isRequired,
    adPosInfo: PropTypes.shape({}).isRequired,
    styleObj: PropTypes.object.isRequired,
    onSaveData: PropTypes.func.isRequired,
    onAdPosAddElem: PropTypes.func,
    onAddOrDelStyle: PropTypes.func,
    onDataChange: PropTypes.func.isRequired,
    onGoToAppList: PropTypes.func.isRequired,
    isEdit: PropTypes.bool.isRequired,
    getAppNameById: PropTypes.func.isRequired,
    changeSaveType: PropTypes.func.isRequired,
    getAdSlotInfo: PropTypes.func.isRequired,
    auditStyleInfo: PropTypes.array.isRequired,
    getAdSlotAuditInfo: PropTypes.func.isRequired,
    installPackage: PropTypes.object
  };

  static defaultProps = {
    onAdPosAddElem: null,
    onAddOrDelStyle: null,
    installPackage: null
  };

  constructor(props) {
    super(props);
    const { status, adPosInfo, styleObj, auditStyleInfo, installPackage } = props;
    // 取消新建后跳转的路径
    this.subItemValidity = Object.create(null);
    this.setValidity(props);
    this.state = {
      status,
      adPosInfo,
      styleInfo: styleObj.styleInfo,
      presetStandardData: styleObj.presetStandardData,
      formValid: this.getFormValid(),
      auditStyleInfo,
      installPackage
    };
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentDidMount() {
    const { isEdit, adPosInfo: { adPosId } } = this.props;
    // 获取名称的同时，获取安装包类型
    this.props.getAppNameById(this.state.adPosInfo.appId);
    (!isEdit && adPosId) ? this.props.getAdSlotInfo(adPosId) : null;
    (isEdit && adPosId) ? this.props.getAdSlotAuditInfo(adPosId) : null;
  }

  componentWillReceiveProps(nextProps) {
    this.setValidity(nextProps);
    this.setState({
      status: nextProps.status,
      adPosInfo: nextProps.adPosInfo,
      styleInfo: nextProps.styleObj.styleInfo,
      presetStandardData: nextProps.styleObj.presetStandardData,
      formValid: this.getFormValid(),
      auditStyleInfo: nextProps.auditStyleInfo,
      installPackage: nextProps.installPackage
    });
    console.log('表单是否合法：', this.getFormValid());
  }

  onSave = btnText => {
    // true 保存；false: 保存并继续
    const saveType = btnText === saveButtonText[0];
    this.props.changeSaveType(saveType);
    this.props.onSaveData(saveType, this.props.isEdit);
  };

  onCancel = () => {
    // 点击取消后，点击确定按钮，跳转到对应的页面
    this.props.onGoToAppList('adPos');
  };

  // itemType: 当前编辑的项，如：广告位名称； value：当前编辑项的值
  onAdPosInfoChange = (itemType, itemValue) => {
    this.props.onDataChange(NewAdPosSettingItems[0].value, itemType, itemValue);
  };

  // 修改广告位的样式信息
  onAdPosStyleInfoChange = (itemType, itemValue, itemIndex) => {
    this.props.onDataChange(
      NewAdPosSettingItems[1].value,
      itemType,
      itemValue,
      itemIndex,
    );
  };

  onAdPosNameChange = value => {
    this.onAdPosInfoChange('adPosName', value);
  };

  onAdPosTypeChange = value => {
    this.onAdPosInfoChange('adPosType', value);
  };

  onCallBackUrlChange = value => {
    this.onAdPosInfoChange('slotCallbackUrl', value);
  };

  onFlowInfoTypeChange = (value, index) => {
    this.onAdPosStyleInfoChange('styleStandardTemplateId', AdPosTypeForBE[value], index);
  };

  onStyleNameChange = (value, valid, index) => {
    this.onAdPosStyleInfoChange('styleName', value, index);
    this.onAdPosStyleInfoChange('schemaStandardTemplateName', value, index);
    this.onAdPosStyleInfoChange('styleNameValid', valid, index);
  };

  onStyleNameBlur = (value, valid, index) => {
    const { styleInfo } = this.state;
    let styleNameRepeat = false;
    if (styleInfo.length > 1) {
      styleNameRepeat = checkStyleInfoNameIsRepeat(styleInfo.filter((item, key) => key !== index), value);
      console.log('名字重复了：', styleNameRepeat);
    }
    this.onAdPosStyleInfoChange('styleNameRepeat', styleNameRepeat, index);
  };


  onObjectChange = (value, index) => {
    this.onAdPosStyleInfoChange('styleType', value, index);
  };

  onAppVersionChange = (value, index) => {
    this.onAdPosStyleInfoChange('minSupportVersion', value, index);
    this.onAdPosStyleInfoChange('versionValid', checkVersionIsValid(value), index);
  };

  setValidity = data => {
    this.setAdPosInfoValidity(data.adPosInfo);
    this.setStyleInfoValidity(data.styleObj.styleInfo);
  };

  setAdPosInfoValidity = posi => {
    this.subItemValidity.adPosInfo = [
      checkAdPosNameValidity(posi.adPosName) && !(posi.nameConflict) // 广告名是否合法
    ];
  };

  setStyleInfoValidity = si => {
    this.subItemValidity.styleInfo = [checkStyleInfoValidity(si)];
  };

  getFormValid = () => 
    _.values(this.subItemValidity)
      .map(subArr => subArr.reduce((a, b) => a && b))
      .reduce((a, b) => a && b);
  

  render() {
    const { 
      status,
      adPosInfo,
      styleInfo,
      formValid,
      presetStandardData,
      auditStyleInfo,
      installPackage
    } = this.state;
    const { onAdPosAddElem, onAddOrDelStyle, isEdit } = this.props;
    const cancelHintText = `您当前正在${
      isEdit ? '修改' : '新建'
    }广告位，确定要取消${isEdit ? '修改' : '编辑'}吗？`;
    const {
      adPosInfo: adPosInfoValidity,
      styleInfo: styleInfoValidity
    } = this.subItemValidity;

    return (
      <div className={s.main}>
        <AdPosInfo
          {...adPosInfo}
          isEdit={isEdit}
          adPosNameValid={adPosInfoValidity[0]}
          onAdPosNameChange={this.onAdPosNameChange}
          onAdPosTypeChange={this.onAdPosTypeChange}
          onCallBackUrlChange={this.onCallBackUrlChange}
          osType={installPackage.packageType}
        />
        <StyleInfo
          isEdit={isEdit}
          styleInfo={styleInfo}
          presetStandardData={presetStandardData}
          styleInfoValid={styleInfoValidity[0]}
          {...adPosInfo}
          onAddElem={onAdPosAddElem}
          onAddOrDelStyle={onAddOrDelStyle}
          onFlowInfoTypeChange={this.onFlowInfoTypeChange}
          onStyleNameChange={this.onStyleNameChange}
          onStyleNameBlur={this.onStyleNameBlur}
          onObjectChange={this.onObjectChange}
          onAppVersionChange={this.onAppVersionChange}
          onElemInfoItemChange={this.onAdPosStyleInfoChange}
          auditStyleInfo={auditStyleInfo}
          installPackage={installPackage}
        />
        <FormFooterActionBar
          status={status}
          cancelHintText={cancelHintText}
          saveButtonText={saveButtonText}
          saveButtonValid={status !== OperationStatus.load_fail && formValid}
          onSave={this.onSave}
          onCancel={this.onCancel}
        />
      </div>
    );
  }
}

export default withStyles(s2)(AdSlot);
