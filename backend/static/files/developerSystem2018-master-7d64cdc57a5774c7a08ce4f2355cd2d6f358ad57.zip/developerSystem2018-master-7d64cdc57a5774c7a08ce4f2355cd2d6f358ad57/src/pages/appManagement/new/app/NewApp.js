import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Radio, Icon, Input, Select } from 'antd';
import DebounceInput from 'react-debounce-input';
import Icons from '../../../../components/Icons';
import { AppOsTypeZH, NewAppClassify, AppAdposListMapForFE } from '../../../../constants/MenuTypes';
import {
  classnames,
  updateComponentStateByKeys,
  componentUpdateByState,
  isValidAppAdPosEntityName
} from '../../../../core/utils';
import s from '../index.less';

const { Group: RadioGroup, Button: RadioButton } = Radio;
const { Option } = Select;

const RadioButtonStyle = { width: '118px', marginRight: '20px' };

const RadioButtonCheckStyle = {
  position: 'absolute',
  top: 0,
  right: 0,
  transform: 'translate(50%, -50%)',
  color: '#5a9ee2'
};

const checkAppNameValidity = value => isValidAppAdPosEntityName(value);

const checkAppTypeValidity = value =>
  Object.prototype.toString.call(value) === '[object Array]' &&
  value.length === 2 &&
  value[0] !== NewAppClassify.一级分类 &&
  value[1] !== NewAppClassify.二级分类;

const checkAppPackageOrItunesValidity = value => (typeof value === 'string' && value.length > 0);

/* eslint-disable react/no-unused-prop-types */
class NewApp extends Component {
  static propTypes = {
    appName: PropTypes.string.isRequired,
    osType: PropTypes.string.isRequired,
    appType: PropTypes.arrayOf(PropTypes.any.isRequired).isRequired,
    nameConflict: PropTypes.bool.isRequired,
    appNameValid: PropTypes.bool.isRequired,
    appTypeValid: PropTypes.bool.isRequired,
    androidOrItunes: PropTypes.string.isRequired,
    categories: PropTypes.arrayOf(
      PropTypes.shape({
        categoryId: PropTypes.number.isRequired,
        categoryName: PropTypes.string.isRequired,
        subcategories: PropTypes.array
      }).isRequired,
    ).isRequired,
    isCreate: PropTypes.bool.isRequired,
    onAppNameChange: PropTypes.func.isRequired,
    onOsTypeChange: PropTypes.func.isRequired,
    onCategoryChange: PropTypes.func.isRequired,
    onAndroidOrItunesChange: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const stateKeys = [
      'appName',
      'osType',
      'appType',
      'nameConflict',
      'androidOrItunes',
      'categories',
      'appNameValid',
      'appTypeValid',
      'status',
      'isCreate'
    ];
    this.state = {
      // topCategory: { name: props.appType[0] },
      topCategory:
        props.appType[0] === NewAppClassify.一级分类
          ? { categoryName: NewAppClassify.一级分类 }
          : props.categories.find(t => t.categoryId === props.appType[0])
    };
    stateKeys.forEach(key => {
      this.state[key] = props[key];
    });
    this.hasFocusAppName = false;
    this.hasFocusAppType = false;
    this.componentWillReceiveProps = updateComponentStateByKeys(stateKeys);
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentDidUpdate(_, prevState) {
    const { nameConflict } = this.state;
    // 用于广告实体名字重复时候的滚动操作
    if (nameConflict && !prevState.nameConflict) {
      this.entityName.input.scrollIntoViewIfNeeded();
    }
  }

  onAppNameFocus = () => {
    this.setState({ appNameValid: true });
    this.hasFocusAppName = true;
  };

  onAppNameChange = e => {
    const { value } = e.target;
    this.setState(
      {
        appNameValid: checkAppNameValidity(value)
      },
      () => {
        this.props.onAppNameChange(value);
      },
    );
  };

  onOsTypeChange = e => {
    this.props.onOsTypeChange(e.target.value);
  };

  onTopCategoryChange = value => {
    const topCategory = this.state.categories.find(t => t.categoryId === value);
    this.setState({
      topCategory,
      appTypeValid: false
    });
    this.hasFocusAppType = true;
    this.props.onCategoryChange([value, NewAppClassify.二级分类]);
  };

  onSecCategoryChange = value => {
    this.setState(
      {
        appTypeValid: true
      },
      () => {
        this.props.onCategoryChange([this.state.appType[0], value]);
      },
    );
  };

  onAndroidOrItunesChange = e => {
    this.props.onAndroidOrItunesChange(e.target.value);
  };

  osTypeItems = () => AppOsTypeZH.map(t => (
    <RadioButton style={RadioButtonStyle} value={t.value} key={t.value}>
      <Icon
        style={{
          ...RadioButtonCheckStyle,
          display: (this.state.osType === t.value ? 'block' : 'none'),
          background: this.state.isCreate ? '#fff' : ''
        }}
        type="check-circle"
      />
      {Icons[t.value]} &nbsp;{t.name}
    </RadioButton>
  ));

  CategorieItems = () =>
    this.state.categories.map(t => (
      <Option value={t.categoryId} key={t.categoryId}>
        {t.categoryName}
      </Option>
    ));

  SubCategorieItems = () =>
    this.state.topCategory.subcategories &&
    this.state.topCategory.subcategories.map(t => (
      <Option value={t.categoryId} key={t.categoryId}>
        {t.categoryName}
      </Option>
    ));

  render() {
    const {
      appName,
      osType,
      appType,
      nameConflict,
      androidOrItunes,
      topCategory,
      appNameValid,
      appTypeValid,
      isCreate
    } = this.state;

    const showAppNameError = !appNameValid && this.hasFocusAppName;
    const showTopCategoryError =
      appType[0] === NewAppClassify.一级分类 && this.hasFocusAppType;
    const showSecCategoryError =
      (showTopCategoryError || !appTypeValid) && this.hasFocusAppType;
    return (
      <div className={s.setting}>
        <div className={s.setting__title}>新建应用</div>
        <div style={{ paddingTop: 6 }}>
          <div className={s['setting-item']}>
            <div className={s['setting-item__name']}>应用名称</div>
            <div className={s['setting-item__value']}>
              <DebounceInput
                element={Input}
                debounceTimeout={600}
                ref={input => {
                  this.entityName = input;
                }}
                className={classnames({
                  [s.input]: true,
                  [s['adentity-name-input']]: true,
                  [s.error]: nameConflict || showAppNameError
                })}
                value={appName}
                onChange={this.onAppNameChange}
                onFocus={this.onAppNameFocus}
                onBlur={({ target: { value } }) => {
                  this.setState({ appNameValid: checkAppNameValidity(value) });
                }}
                disabled={!isCreate}
              />
              <div
                className={classnames({
                  [s['input-hint']]: true,
                  [s.error]: showAppNameError
                })}
              >
                请在应用名称后增加操作系统后缀，例如：-安卓、-ios，最多15个字 
              </div>
            </div>
          </div>
          <div
            className={classnames({
              [s['setting-item']]: true,
              [s['setting-item__osType']]: true
            })}
            style={{ paddingTop: 6 }}
          >
            <div className={s['setting-item__name']}>平台</div>
            <div className={s['setting-item__value']}>
              <RadioGroup
                size='default'
                value={osType}
                onChange={this.onOsTypeChange}
                disabled={!isCreate}
              >
                {this.osTypeItems()}
              </RadioGroup>
            </div>
          </div>
          <div className={s['setting-item']}>
            <div className={s['setting-item__name']}>应用类型</div>
            <div className={s['setting-item__value']}>
              <div style={{ display: 'inline-block', marginRight: '16px' }}>
                <Select
                  style={{ width: 120 }}
                  className={classnames({
                    [s['error']]: showTopCategoryError
                  })}
                  value={appType[0]}
                  onChange={this.onTopCategoryChange}
                  disabled={!isCreate}
                >
                  {this.CategorieItems()}
                </Select>
              </div>
              <Select
                style={{ width: 120 }}
                className={classnames({
                  [s.error]: showSecCategoryError
                })}
                value={appType[1]}
                onChange={this.onSecCategoryChange}
                disabled={topCategory.categoryName === NewAppClassify.一级分类 || !isCreate}
              >
                {this.SubCategorieItems()}
              </Select>
            </div>
          </div>
          <div className={s['setting-item']}>
            <div className={s['setting-item__name']}>
              {osType === AppAdposListMapForFE.Android ? 'Android包名' : 'iTunes链接'}
            </div>
            <div className={s['setting-item__value']}>
              <DebounceInput
                element={Input}
                debounceTimeout={600}
                className={classnames({
                  [s.input]: true,
                  [s['android-item_value']]: true
                })}
                value={androidOrItunes}
                placeholder={
                  osType === AppAdposListMapForFE.Android
                    ? '例: com.youdao.dict' :
                    '例: https://itunes.apple.com/cn/app/id450748070'
                }
                onChange={this.onAndroidOrItunesChange}
                disabled={!isCreate}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export { NewApp as default, checkAppNameValidity, checkAppTypeValidity, checkAppPackageOrItunesValidity };
