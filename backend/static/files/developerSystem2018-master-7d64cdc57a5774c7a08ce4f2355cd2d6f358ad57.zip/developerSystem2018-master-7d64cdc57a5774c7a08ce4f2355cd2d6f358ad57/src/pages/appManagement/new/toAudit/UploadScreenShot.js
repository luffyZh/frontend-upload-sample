import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Tooltip, Icon } from 'antd';
import { classnames } from '../../../../core/utils';
import ImageUploader from './ImageUploader';
import {
  SlotAuditStatusForFE
} from '../../../../constants/MenuTypes';
import s from '../index.less';
import s2 from './index.less';

const getHasAuditedArr = styleInfo => {
  let resArr = [];
  styleInfo.map((item, index) => {
    (item.styleAuditStatus !== -1 &&
    item.styleAuditStatus !== 2) ? resArr.push(index) : null;
  });
  return resArr;
};
class UploadScreenShot extends Component {
  static propTypes = {
    adPosName: PropTypes.string.isRequired,
    styleInfo: PropTypes.array.isRequired,
    changeSlotAuditSource: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const { adPosName, styleInfo } = props;
    this.state = {
      adPosName,
      styleInfo
    };
  }

  componentWillReceiveProps({ adPosName, styleInfo }) {
    this.setState({ adPosName, styleInfo });
  }

  onImageChange = (styleIndex, imageInfoList) => {
    this.props.changeSlotAuditSource(styleIndex, imageInfoList, 'image');
  };

  getImageComponent = (styleIndex, screenShots) => {
    return (
      <div className={s['setting-item__value']}>
        <div
          className={classnames({
            [s['input-hint']]: true,
            [s2['mainimage-hint']]: true
          })}
        >
          支持格式：JPG、PNG，最大 1MB
        </div>
        <ImageUploader
          hasAuditedArr={getHasAuditedArr(this.props.styleInfo)}
          imageInfoList={screenShots}
          onImageChange={imageInfoList => {
            this.onImageChange(styleIndex, imageInfoList);
          }}
          maxSize={1 * 1024 * 1024}
          text="上传图片"
          type='Image'
        />
      </div>
    );
  };

  render() {
    const { adPosName, styleInfo } = this.state;
    return (
      <div className={s.setting}>
        <div className={s.setting__title}>上传截图</div>
        <div className={s['setting-item']}>
          <div className={s['setting-item__name']}>广告位名称</div>
          <div className={s['setting-item__value']}>
            <div className={s.appAdPosName}>{adPosName}</div>
          </div>
        </div>
        {styleInfo.map((style, index) => {
          return (
            <div key={index.toString()}>
              <div style={{ paddingTop: 6 }}>
                <div className={s['setting-item']}>
                  <div className={s['setting-item__name']}>样式名称</div>
                  <div className={s['setting-item__value']}>
                    <div className={s.appAdPosName}>{style.styleName}</div>
                  </div>
                </div>
              </div>
              <div style={{ paddingTop: 6 }}>
                <div className={s['setting-item']}>
                  <div className={s['setting-item__name']}>样式状态</div>
                  <div className={s['setting-item__value']}>
                    <div className={s.appAdPosName}>{SlotAuditStatusForFE[style.styleAuditStatus]}</div>
                  </div>
                </div>
              </div>
              <div style={{ paddingTop: 6 }}>
                <div className={s['setting-item']}>
                  <div className={s['setting-item__name']}>
                    样式截图&nbsp;
                    <Tooltip title="该样式截图将展示给广告主，请上传真实样式截图，否则会导致审核失败。">
                      <Icon type="question-circle-o" />
                    </Tooltip>
                  </div>
                  {this.getImageComponent(index, style.styleScreenshot)}
                </div> 
              </div> 
            </div>
          );
        })}
      </div>
    );
  }
}

export default withStyles(s, s2)(UploadScreenShot);
