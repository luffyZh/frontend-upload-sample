import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { classnames } from '../../../../core/utils';
import PackageUploader from './PackageUploader';
import s from '../index.less';
import s2 from './index.less';

class UploadInstallPackage extends Component {
  static propTypes = {
    installPackage: PropTypes.shape({}).isRequired,
    adPosId: PropTypes.string.isRequired,
    changeSlotAuditSource: PropTypes.func.isRequired,
    styleInfo: PropTypes.array.isRequired
  };

  constructor(props) {
    super(props);
    const { installPackage } = props;
    this.state = {
      installPackage
    };
  }

  onPackageChange = packageInfo => {
    this.props.changeSlotAuditSource(0, packageInfo, 'package');
  };

  getInstallPackageComponent = installPackage => (
    <div className={s['setting-item__value']}>
      <div
        className={classnames({
          [s['input-hint']]: true,
          [s2['mainimage-hint']]: true
        })}
      >
          支持格式：{installPackage.packageType === 1 ? 'APK' : 'IPA'}，最大 400MB
      </div>
      <PackageUploader
        canDelete={
          this.props.styleInfo.some(item => item.styleAuditStatus === -1 || item.styleAuditStatus === 2)
        }
        packageInfoList={this.generateInstallPackage(installPackage)}
        onPackageChange={pak => {
          this.onPackageChange(pak);
        }}
        packageType={installPackage.packageType}
        maxSize={400 * 1024 * 1024}
        text="上传安装包"
        slotUdid={this.props.adPosId}
      />
    </div>
  );

  generateInstallPackage = installPackage => {
    const { styleInfo } = this.props;
    const hasAudited = styleInfo.some(item => item.styleAuditStatus !== -1 && item.styleAuditStatus !== 2);
    (hasAudited && installPackage.name !== 'app-package') ? installPackage.file = [] : null;
    return [installPackage];
  }

  render() {
    const { installPackage } = this.state;
    return (
      <div className={s.setting}>
        <div className={s.setting__title}>上传安装包</div>
        <div className={s['setting-item']}>
          <div className={s['setting-item__name']}>上传安装包</div>
          {this.getInstallPackageComponent(installPackage)}
        </div>
      </div>
    );
  }
}

export default withStyles(s, s2)(UploadInstallPackage);
