/* eslint-disable no-shadow, react/prop-types */
import React from 'react';
import { Switch, Tooltip, Icon } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import Link from '../../../components/Link';
import {
  AppEntitySwitchStatusMapForFE,
  AppOsForFE,
  SlotAuditStatusForFE,
  AppStatusForFE,
  SlotOpStatusForFE,
  SlotStyleForFE,
  AppTabTypes,
  SlotOpStatusMapForFE
} from '../../../constants/MenuTypes';
import {
  numberFormat,
  getAppEntityPath
} from '../../../core/utils';
import s from './index.less';

// const formatFloat = numberFormat(2) || '--';
const formatInteger = numberFormat(0) || '--';

const nonEditableAppEntityNameRender = (tabType, bool) => record => {
  const { appName, appId, slotName, slotUdid, slotOpStatus } = record;
  const toPath = getAppEntityPath(tabType, appId, slotUdid, slotOpStatus);
  return tabType !== AppTabTypes.appTab
    ? <IfComp
      expression={(slotOpStatus !== SlotOpStatusMapForFE.已删除)}
      trueComp={
        <Link to={toPath}>{slotName}</Link>
      }
      falseComp={
        <span>{slotName}</span>
      }
    />
    : <IfComp
      expression={bool}
      trueComp={<span style={{ fontWeight: 'bolder' }}>{appName}</span>}
      falseComp={<Link to={`${toPath}?appName=${appName}`}>{appName}</Link>}
    />
  ;
};

const TableColumns = {
  switchBtn: (type, onChange) => ({
    title: '开关',
    key: type === AppTabTypes.appTab ? 'appStatus' : 'slotOpStatus',
    fixed: 'left',
    // width: '74px',
    width: '70px',
    render: record => {
      return (type === AppTabTypes.appTab)
        ? (
          <Switch
            size='small'
            style={{ width: '40px' }}
            disabled={record.appStatus === SlotOpStatusMapForFE.已删除}
            checked={AppStatusForFE[record.appStatus] === AppEntitySwitchStatusMapForFE.已开启}
            onChange={checked => onChange(type, record.appId, checked)}
          />
        )
        : (
          <Switch
            size='small'
            style={{ width: '40px' }}
            disabled={SlotOpStatusForFE[record.slotOpStatus] === AppEntitySwitchStatusMapForFE.已禁用}
            checked={SlotOpStatusForFE[record.slotOpStatus] === AppEntitySwitchStatusMapForFE.已开启}
            onChange={checked => onChange(type, record.slotUdid, checked)}
          />
        );
    }
  }),
  appName: tabType => ({
    title: '应用名称',
    key: 'appName',
    fixed: 'left',
    // width: '94px',
    width: '174px',
    render: nonEditableAppEntityNameRender(tabType)
  }),
  osType: {
    title: '平台',
    key: 'osType',
    fixed: 'left',
    // width: '94px',
    width: '130px',
    render: record => {
      const { appOs } = record;
      return <span>{AppOsForFE[appOs]}</span>;
    }
  },
  adPosName: tabType => ({
    title: '广告位名称',
    key: 'adPosName',
    fixed: 'left',
    // width: '100px',
    width: '160px',
    render: nonEditableAppEntityNameRender(tabType)
  }),
  adPosId: () => ({
    title: '广告位ID',
    key: 'adPosId',
    width: '260px',
    render: record => {
      const { slotUdid } = record;
      return <span>{slotUdid}</span>;
    }
  }),
  onApp: tabType => ({
    title: '所在应用',
    key: 'onApp',
    fixed: 'left',
    // width: '94px',
    width: '120px',
    render: nonEditableAppEntityNameRender(AppTabTypes.appTab, tabType !== AppTabTypes.adPosTab)
  }),
  adPosType: {
    title: '广告位类型',
    key: 'slotStyle',
    width: '100px',
    render: record => <span>{SlotStyleForFE[record.slotStyle]}</span>
  },
  auditStatus: {
    title: '审核状态',
    key: 'auditStatus',
    width: '94px',
    render: record => <span>{SlotAuditStatusForFE[record.slotAuditStatus]}</span>
  },
  reqAdNum: {
    title: (<span>
      请求广告数&nbsp;
      <Tooltip title='媒体请求的广告总数（单次请求可能包含多条广告)'>
        <Icon type='question-circle-o' />
      </Tooltip>
    </span>),
    dataIndex: 'requestAdNum',
    key: 'requestAdNum',
    render: formatInteger,
    // width: '140px',
    width: '200px',
    sorter: (a, b) => a.requestAdNum - b.requestAdNum
  },
  resAdNum: {
    title: (<span>
      返回广告数&nbsp;
      <Tooltip title='广告平台实际返回给媒体的广告数量'>
        <Icon type='question-circle-o' />
      </Tooltip>
    </span>),
    dataIndex: 'bid',
    key: 'bid',
    // width: '140px',
    width: '200px',
    render: formatInteger,
    sorter: (a, b) => a.bid - b.bid
  },
  fillRate: {
    title: (<span>
      填充率&nbsp;
      <Tooltip title='填充率=返回广告数/请求广告数'>
        <Icon type='question-circle-o' />
      </Tooltip>
    </span>),
    dataIndex: 'bidRate',
    key: 'bidRate',
    // width: '90px',
    width: '120px',
    render: text => <span>{text || '--'}</span>,
    sorter: (a, b) => {
      if (a.bidRate === '--' && b.bidRate === '--') {
        return 0;
      } else if (a.bidRate === '--') {
        return -1;
      } else if (b.bidRate === '--') {
        return 1;
      }
      return parseFloat(a.bidRate, 10) - parseFloat(b.bidRate, 10);
    }
  },
  imprNum: {
    title: '展示数',
    dataIndex: 'impr',
    key: 'impr',
    width: '98px',
    render: formatInteger,
    sorter: (a, b) => a.impr - b.impr
  },
  imprRate: {
    title: '展示率',
    dataIndex: 'imprRate',
    key: 'imprRate',
    width: '98px',
    // render: formatFloat,
    sorter: (a, b) => {
      if (a.imprRate === '--' && b.imprRate === '--') {
        return 0;
      } else if (a.imprRate === '--') {
        return -1;
      } else if (b.imprRate === '--') {
        return 1;
      }
      return parseFloat(a.imprRate, 10) - parseFloat(b.imprRate, 10);
    }
  },
  clickNum: {
    title: '点击数',
    dataIndex: 'click',
    key: 'click',
    width: '98px',
    render: formatInteger,
    sorter: (a, b) => a.click - b.click
  },
  clickRate: {
    title: '点击率',
    dataIndex: 'clickRate',
    key: 'clickRate',
    width: '98px',
    // render: val => (typeof val === 'number' ? `${val}%` : '--'),
    sorter: (a, b) => {
      if (a.clickRate === '--' && b.clickRate === '--') {
        return 0;
      } else if (a.clickRate === '--') {
        return -1;
      } else if (b.clickRate === '--') {
        return 1;
      }
      return parseFloat(a.clickRate, 10) - parseFloat(b.clickRate, 10);
    }
  },
  ecpm: {
    title: '估算千次展示收入',
    dataIndex: 'ecpm',
    key: 'ecpm',
    width: '158px',
    // render: formatFloat,
    sorter: (a, b) => a.ecpm - b.ecpm
  },
  cpc: {
    title: '估算单次点击收入',
    dataIndex: 'cpc',
    key: 'cpc',
    width: '158px',
    // render: formatFloat,
    sorter: (a, b) => a.cpc - b.cpc
  },
  estimateProfit: {
    title: '估算收入',
    dataIndex: 'estimateProfit',
    key: 'estimateProfit',
    width: '108px',
    // render: formatFloat,
    sorter: (a, b) => a.estimateProfit - b.estimateProfit
  }
};

export default withStyles(s)(TableColumns);
