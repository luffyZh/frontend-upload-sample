import React, { Fragment } from 'react';
import { Input, Select, InputNumber, Tooltip, Icon } from 'antd';
import DebounceInput from 'react-debounce-input';
import IfComp from 'if-comp';
import _ from 'lodash';
import {
  imageElemsMapKey,
  elemsWordNum,
  styleElemName
} from '../../../../constants/MenuTypes';
import {
  classnames,
  generatePictureRadioSelect,
  checkTextLength,
  checkCustomStyleValueValid
} from '../../../../core/utils';
import heightMonitor from '../../../../static/images/ic_add_subtract_grey.png';
import heightMonitorUp from '../../../../static/images/ic_add_subtract_blue_up.png';
import heightMonitorDown from '../../../../static/images/ic_add_subtract_blue_down.png';
import s from './index.less';
import s2 from '../index.less';

const { Option } = Select;

const ratioRatioItems = pictureElemRatio => 
  _.keys(pictureElemRatio).map(t => (
    <Option key={t.toString()} value={t.toString()}>
      {t}
    </Option>
  ));

const wordNumRatioItems = elementKey => {
  return elemsWordNum[elementKey] && elemsWordNum[elementKey].map(t => (
    <Option key={t.toString()} value={t}>
      {t}
    </Option>
  ));
};

const getSizeMonitorIcon = sizeMonitor => {
  if (sizeMonitor === 'up') {
    return heightMonitorUp;
  }
  return sizeMonitor === 'down' ? heightMonitorDown : heightMonitor;
};

const Columns = {
  elementKey: (elems, isAbleEdit, elemType, onKeyChange, totalElementKeys) => ({
    title: '元素Key',
    key: 'elementKey',
    className: s.elementKey,
    render: record => {
      if (elemType === styleElemName[2] || record.isStandard || !isAbleEdit) {
        return (<span>{record.elementKey}</span>);
      }
      return (
        <Fragment>
          <DebounceInput
            element={Input}
            debounceTimeout={600}
            value={record.elementKey}
            className={classnames({ [s.error]: !record.keyValid })}
            onChange={e => {
              const { value } = e.target;
              console.log(value, totalElementKeys);
              const isValid = !(
                _.values(imageElemsMapKey)
                  .slice(0, 7)
                  .includes(value) ||
                elems.findIndex(t => t.elementKey === value) > -1 ||
                !checkTextLength(value, 0.5, 30) ||
                !checkCustomStyleValueValid(value) ||
                _.includes(totalElementKeys, value)
              );
              onKeyChange(
                'elementKey',
                value,
                record.key,
                record.nameValid,
                isValid,
                record.isStandard
              );
            }}
          />
          <div
            style={{ display: record.keyValid ? 'none' : 'inline-block' }}
            className={classnames({
              [s2['input-hint']]: true,
              [s2.error]: !record.keyValid
            })}
          >
            元素Key填写不合法&nbsp;
            <Tooltip title='英文字符、下划线以及数字并且不能与任何元素key值重复'>
              <Icon type="question-circle-o" />
            </Tooltip>
          </div>
        </Fragment>
      );
    }
  }),
  ratio: (isAbleEdit, onRatioChange, standardElements) => ({
    title: '比例',
    key: 'ratio',
    className: s.ratio,
    render: record => {
      const pictureElemRatio = (typeof standardElements.imageElements !== 'undefined' && 
        generatePictureRadioSelect(record.elementKey, standardElements.imageElements));
      if (isAbleEdit) {
        // 这个地方需要判断的是审核状态
        return (
          <IfComp
            expression={record.isStandard}
            trueComp={
              <Select
                style={{ width: 80 }}
                value={record.ratio}
                onChange={value =>
                  onRatioChange(
                    'ratio',
                    value,
                    record.key,
                    record.nameValid,
                    record.keyValid,
                    record.isStandard
                  )
                }
              >
                {ratioRatioItems(pictureElemRatio)}
              </Select>
            }
          /> 
        );
      }
      return <span>{record.ratio}</span>;
    }
  }),
  size: (isAbleEdit, onSizeChange) => ({
    title: '尺寸',
    key: 'size',
    className: s.size,
    render: record => {
      if (!isAbleEdit) {
        return (
          <div style={{ margin: '0 auto' }}>
          宽 {record.width}
          &nbsp;&nbsp; 高 {record.height}
          </div>
        );
      }
      if (!record.isStandard) {
        return (
          <div style={{ margin: '0 auto' }}>
            宽<InputNumber
              style={{ width: 62, marginLeft: 4 }}
              min={1}
              max={9999}
              value={record.width}
              onChange={value =>
                onSizeChange(
                  'attr',
                  {
                    width: value,
                    height: record.height,
                    sizeMonitor: ''
                  },
                  record.key,
                  record.nameValid,
                  record.keyValid,
                  record.isStandard
                )
              }
            />
            &nbsp;&nbsp; 高<InputNumber
              style={{ width: 62, marginLeft: 4 }}
              min={1}
              max={9999}
              value={record.height}
              onChange={value =>
                onSizeChange(
                  'attr',
                  {
                    width: record.width,
                    height: value,
                    sizeMonitor: ''
                  },
                  record.key,
                  record.nameValid,
                  record.keyValid,
                  record.isStandard,
                )
              }
            />
            <div
              style={{ display: (record.width !== '' && record.height !== '') ? 'none' : 'inline-block' }}
              className={classnames({
                [s2['input-hint']]: true,
                [s2.error]: !(record.width !== '' && record.height !== '')
              })}
            >
              宽、高请填写4位以内的阿拉伯数字
            </div>
          </div>
        );
      }
      const { width, height, sizeMonitor } = record;
      const ratioArr = record.ratio.split(':');
      const ratio = parseInt(ratioArr[0]) / parseInt(ratioArr[1]);
      const maxHeight = parseInt(
        ((width / ratio).toFixed(0) * 1.05).toFixed(0),
      );
      const minHeight = parseInt(
        ((width / ratio).toFixed(0) * 0.95).toFixed(0),
      );
      const sizeMonitorIcon = getSizeMonitorIcon(sizeMonitor);

      if (isAbleEdit) {
        return (
          <div style={{ margin: '0 auto' }}>
            宽<InputNumber
              style={{ width: 62, marginLeft: 4 }}
              min={1}
              max={9999}
              value={record.width}
              onChange={value =>
                onSizeChange(
                  'attr',
                  {
                    width: value,
                    height: (
                      parseInt(value) /
                      (parseInt(record.ratio.split(':')[0]) /
                        parseInt(record.ratio.split(':')[1]))
                    ).toFixed(0),
                    sizeMonitor: ''
                  },
                  record.key,
                  record.nameValid,
                  record.keyValid,
                  record.isStandard
                )
              }
            />
            &nbsp;&nbsp; 高<div className={s.sizeMonitor}>
              <Input
                style={{ width: 62, marginLeft: 4 }}
                value={record.height}
                onChange={() => {}}
              />
              <img
                src={sizeMonitorIcon}
                alt=""
                style={{
                  position: 'absolute',
                  right: '6px',
                  top: '9px',
                  pointerEvents: 'none'
                }}
              />
              <span
                className={s.up}
                onClick={() => {
                  if (parseInt(height) < maxHeight) {
                    onSizeChange(
                      'attr',
                      {
                        width,
                        height: parseInt(height) + 1,
                        sizeMonitor: 'up'
                      },
                      record.key,
                      record.nameValid,
                      record.keyValid,
                      record.isStandard
                    );
                  }
                }}
                onKeyDown={() => {}}
                role="none"
              />
              <span
                className={s.down}
                onClick={() => {
                  if (parseInt(height) > minHeight) {
                    onSizeChange(
                      'attr',
                      {
                        width,
                        height: parseInt(height) - 1,
                        sizeMonitor: 'down'
                      },
                      record.key,
                      record.nameValid,
                      record.keyValid,
                      record.isStandard
                    );
                  }
                }}
                onKeyDown={() => {}}
                role="none"
              />
            </div>
            <div
              style={{ display: (record.width !== '' && record.height !== '') ? 'none' : 'inline-block' }}
              className={classnames({
                [s2['input-hint']]: true,
                [s2.error]: !(record.width !== '' && record.height !== '')
              })}
            >
              宽、高请填写4位以内的阿拉伯数字
            </div>
          </div>
        );
      }
    }
  }),
  wordNum: (isAbleEdit, onWordNumChange) => ({
    title: '字数',
    key: 'wordNum',
    className: s.wordNum,
    render: record => {
      if (!isAbleEdit) {
        return <span>{record.length}&nbsp;以内</span>;
      }
      if (!record.isStandard) {
        return (
          <Fragment>
            <div className={s.wordWrap}>
              <InputNumber
                value={record.length}
                min={1}
                max={99}
                onChange={
                  value => {
                    onWordNumChange(
                      'length',
                      value,
                      record.key,
                      record.nameValid,
                      record.keyValid,
                      record.isStandard
                    );
                  }
                }
              />
              <span className={s.wordTip}>以内</span>
            </div>
            <div
              style={{ display: (/^[1-9][0-9]*$/.test(record.length)) ? 'none' : 'block' }}
              className={classnames({
                [s2['input-hint']]: true,
                [s2.error]: true
              })}
            >
            请填写100以内的阿拉伯数字
            </div>
          </Fragment>
        );
      }
      return (
        <div className={s.wordWrap}>
          <Select
            style={{ width: 80 }}
            value={record.length}
            onChange={value =>
              onWordNumChange(
                'length',
                parseInt(value, 10),
                record.key,
                record.nameValid,
                record.keyValid,
                record.isStandard
              )
            }
          >
            {wordNumRatioItems(record.elementKey)}
          </Select>
          <span className={s.wordTip}>以内</span>
        </div>
      );
    }
  }),
  operate: onDelElem => ({
    title: '操作',
    key: 'operate',
    className: s.operate,
    render: record => (
      <div
        onClick={() => onDelElem(record)}
        onKeyDown={() => onDelElem(record)}
        role="presentation"
      >
        删除
      </div>
    )
  })
};

export default Columns;
