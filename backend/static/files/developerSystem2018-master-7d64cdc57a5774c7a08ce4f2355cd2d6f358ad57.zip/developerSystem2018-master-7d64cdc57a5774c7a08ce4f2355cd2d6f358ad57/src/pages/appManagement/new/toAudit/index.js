import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import UploadScreenShot from './UploadScreenShot';
import UploadInstallPackage from './UploadInstallPackage';
import FormFooterActionBar from '../FormFooterActionBar';
import {
  OperationStatus,
  SlotAndStyleStatusText
} from '../../../../constants/MenuTypes';
import s from '../index.less';

const checkAuditValid = (styleInfo, installPackage) => {
  const allIsAudit = styleInfo.every(item => 
    item.styleAuditStatus !== -1 &&
    item.styleAuditStatus !== 2
  );
  if (allIsAudit) {
    return {
      formValid: false,
      saveText: SlotAndStyleStatusText.已审核
    };
  } 
  return {
    formValid: styleInfo.every(item => 
      item.styleScreenshot.some(item => item.valid)
    ) && installPackage.valid,
    saveText: SlotAndStyleStatusText.提交审核
  };
};

class ToAudit extends Component {
  static propTypes = {
    uploadScreenShot: PropTypes.shape({
      adPosName: PropTypes.string.isRequired,
      styleInfo: PropTypes.array.isRequired
    }).isRequired,
    uploadInstallPackage: PropTypes.shape({
      installPackage: PropTypes.object.isRequired
    }).isRequired,
    onSaveData: PropTypes.func.isRequired,
    onGoToAppList: PropTypes.func.isRequired,
    getAdSlotAuditInfo: PropTypes.func.isRequired,
    isEdit: PropTypes.bool.isRequired,
    changeSlotAuditSource: PropTypes.func.isRequired,
    hasAudit: PropTypes.bool.isRequired,
    hasGoToAudit: PropTypes.func.isRequired
  };
  constructor(props) {
    super(props);
    const {
      uploadScreenShot: { adPosName, adPosId, styleInfo },
      uploadInstallPackage: { installPackage }
    } = props;
    this.state = {
      adPosName,
      adPosId,
      styleInfo,
      installPackage
    };
  }

  componentDidMount() {
    if (!this.props.hasAudit) {
      // 从adPos处获取styleList
      this.props.getAdSlotAuditInfo(this.state.adPosId);
    }
    this.props.hasGoToAudit();
  }

  componentWillReceiveProps(nextProps) {
    const { uploadScreenShot, uploadInstallPackage } = nextProps;
    const { adPosName, adPosId, styleInfo } = uploadScreenShot;
    this.setState({ 
      adPosId,
      adPosName,
      styleInfo,
      installPackage: uploadInstallPackage.installPackage
    });
  }

  onCancel = () => {
    // 点击取消后，点击确定按钮，跳转到对应的页面
    this.props.onGoToAppList('adPos');
  };

  render() {
    const {
      onSaveData,
      isEdit,
      changeSlotAuditSource
    } = this.props;
    const { adPosName, adPosId, styleInfo, installPackage } = this.state;
    const saveObj = checkAuditValid(styleInfo, installPackage);
    const hintText = isEdit ? '修改' : '新建';
    const cancelHintText = `您当前正在${hintText}广告位的提交审核步骤，确定要取消吗？`;
    const { formValid, saveText } = saveObj;
    const saveButtonText = [saveText];

    return (
      <div className={s.main}>
        <UploadScreenShot
          adPosName={adPosName}
          styleInfo={styleInfo}
          changeSlotAuditSource={changeSlotAuditSource}
        />
        <UploadInstallPackage
          styleInfo={styleInfo}
          adPosId={adPosId}
          installPackage={installPackage}
          changeSlotAuditSource={changeSlotAuditSource}
        />
        <FormFooterActionBar
          status="load_success"
          cancelHintText={cancelHintText}
          saveButtonText={saveButtonText}
          saveButtonValid={status !== OperationStatus.load_fail && formValid}
          onSave={onSaveData}
          onCancel={this.onCancel}
          changeSlotAuditSource={changeSlotAuditSource}
        />
      </div>
    );
  }
}

export default withStyles(s)(ToAudit);
