import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Table, Dropdown, Menu, Icon } from 'antd';
import _ from 'lodash';
import {
  styleElemName
} from '../../../../constants/MenuTypes';
import Columns from './Columns';
import {
  changePictureRatioElem,
  addDefaultStyleItem,
  changeTextLengthElem,
  changeCustomHeight,
  reNewAddItem
} from '../../../../core/utils';
import s from './index.less';

const MenuItem = Menu.Item;

const getElemItemsMenu = (elemItems, onChooseElemItems) => (
  <Menu>
    {
      elemItems.filter(e => e.toString() !== '').map(t => (
        <MenuItem
          key={t.toString()}
          onClick={onChooseElemItems}>
          {t}
        </MenuItem>
      ))
    }
  </Menu>
);

const getColumns = (
  elems,
  elemType, // 图片元素、文字元素、视频元素之一
  isAbleAddAndDel,
  isAbleEdit,
  elemItems, // 添加元素的类型，包括自定义
  elemsMapKey, // 元素与key组合
  onElemInfoItemChange, // 元素名、元素key、比例、尺寸、字数
  onAddElem, // 添加元素时
  onDelElem, // 删除元素时
  standardElements,
  totalElementsKeys
) => {
  const operateRow = Columns.operate(onDelElem);
  switch (elemType) {
    case styleElemName[0]: {
      const table = [
        Columns.elementKey(elems, isAbleEdit, elemType, onElemInfoItemChange, totalElementsKeys),
        Columns.ratio((isAbleEdit && isAbleAddAndDel), onElemInfoItemChange, standardElements),
        Columns.size((isAbleEdit && isAbleAddAndDel), onElemInfoItemChange)
      ];
      isAbleAddAndDel && table.push(operateRow);
      return table;
    }
    case styleElemName[1]: {
      const table = [
        Columns.elementKey(elems, isAbleAddAndDel, elemType, onElemInfoItemChange, totalElementsKeys),
        Columns.wordNum((isAbleEdit && isAbleAddAndDel), onElemInfoItemChange)
      ];
      isAbleAddAndDel && table.push(operateRow);
      return table;
    }
    case styleElemName[2]: {
      const table = [
        Columns.elementKey(elems, false, elemType, onElemInfoItemChange),
        Columns.wordNum(false, onElemInfoItemChange)
      ];
      isAbleAddAndDel && table.push(operateRow);
      return table;
    }
  }
};

class DataGrid extends Component {
  static propTypes = {
    isAbleAddAndDel: PropTypes.bool.isRequired,
    isAbleEdit: PropTypes.bool.isRequired,
    elemType: PropTypes.string.isRequired,
    elemItems: PropTypes.arrayOf(PropTypes.string.isRequired).isRequired,
    elemsMapKey: PropTypes.shape({}).isRequired,
    onAddElem: PropTypes.func,
    onDelElem: PropTypes.func,
    elems: PropTypes.arrayOf(PropTypes.object),
    adPosType: PropTypes.string.isRequired,
    totalElementsKeys: PropTypes.array,
    styleStandardTemplateId: PropTypes.number,
    onElemInfoItemChange: PropTypes.func,
    standardElements: PropTypes.object
  };

  static defaultProps = {
    onAddElem: null,
    onDelElem: null,
    elems: [],
    styleStandardTemplateId: 1,
    onElemInfoItemChange: null,
    standardElements: {},
    totalElementsKeys: []
  };

  constructor(props) {
    super(props);
    const {
      isAbleAddAndDel,
      isAbleEdit,
      elemType,
      elemItems,
      elemsMapKey,
      onAddElem,
      elems,
      standardElements,
      totalElementsKeys
    } = this.props;
    this.state = {
      elems,
      elemType,
      elemItems,
      isAbleAddAndDel,
      standardElements,
      totalElementsKeys,
      columns: getColumns(
        elems,
        elemType,
        isAbleAddAndDel,
        isAbleEdit,
        elemItems,
        elemsMapKey,
        this.onElemInfoItemChange,
        onAddElem,
        this.onDelElem,
        standardElements,
        totalElementsKeys
      )
    };
  }

  componentWillReceiveProps(nextProps) {
    const {
      elems,
      elemItems,
      elemType,
      isAbleAddAndDel,
      isAbleEdit,
      elemsMapKey,
      onAddElem,
      standardElements,
      totalElementsKeys,
      adPosType
    } = nextProps;
    this.setState({
      elems,
      elemType,
      elemItems,
      isAbleAddAndDel,
      standardElements,
      totalElementsKeys,
      columns: getColumns(
        elems,
        elemType,
        isAbleAddAndDel,
        isAbleEdit,
        elemItems,
        elemsMapKey,
        this.onElemInfoItemChange,
        onAddElem,
        this.onDelElem,
        standardElements,
        totalElementsKeys,
        adPosType
      )
    });
  }

  shouldComponentUpdate(nextProps, nextState) {
    const {
      elems,
      elemType,
      elemItems,
      adPosType,
      styleStandardTemplateId,
      isAbleAddAndDel
    } = this.props;
    const { columns } = this.state;
    return (
      elems !== nextProps.elems ||
      elemType !== nextProps.elemType ||
      elemItems !== nextProps.elemItems ||
      adPosType !== nextProps.adPosType ||
      styleStandardTemplateId !== nextProps.styleStandardTemplateId ||
      columns !== nextState.columns ||
      isAbleAddAndDel !== nextProps.isAbleAddAndDel
    );
  }

  onElemInfoItemChange = (itemType, itemValue, index, nameValid, keyValid, isStandard) => {
    const { elems, standardElements } = this.state;
    const newElems = [...elems];
    newElems[index][itemType] = itemValue;
    // 图片元素标准化发生变化
    if (itemType === 'ratio') {
      newElems[index] = {
        ...newElems[index],
        ...changePictureRatioElem(newElems[index].elementKey, itemValue, standardElements.imageElements)
      };
      isStandard
        ? newElems[index]['attr'] = { width: newElems[index].width, height: newElems[index].height }
        : newElems[index]['attr'] = { width: newElems[index].width, height: changeCustomHeight(newElems[index])};
    }
    // 文字元素标准化发生变化
    if (itemType === 'length') {
      newElems[index] = {
        ...newElems[index],
        ...changeTextLengthElem(newElems[index].elementKey, itemValue, standardElements.textElements)
      };
    }
    newElems[index]['isStandard'] = isStandard;
    newElems[index]['nameValid'] = nameValid;
    newElems[index]['keyValid'] = keyValid;
    this.props.onElemInfoItemChange(newElems);
  };

  onDelElem = record => {
    const newElems = [...this.state.elems];
    newElems.splice(record.key, 1);
    this.props.onDelElem(this.state.elemType, [...newElems]);
  };

  onChooseElemItems = e => {
    const {
      elems,
      elemType,
      standardElements,
      totalElementsKeys
    } = this.state;
    // ant-design dropdown特有属性
    const newItemName = e.item.props.children;

    // 图片元素、文字元素、视频元素的索引分别对应0，1，2
    const addItem = addDefaultStyleItem(elemType, newItemName, standardElements);
    const newItem = {...reNewAddItem(addItem, totalElementsKeys)};
    newItem.attr = { width: newItem.width, height: newItem.height };
    this.props.onAddElem(elemType, elems.concat(newItem));
  };

  render() {
    const { elemType, elems, elemItems, columns, isAbleAddAndDel } = this.state;
    const list = elems.map((t, i) =>
      _.assign({}, t, { operate: '删除' }, { key: i }),
    );
    return (
      <Table
        columns={columns}
        dataSource={list}
        bordered
        locale={{emptyText: '暂无数据'}}
        title={() =>
          !isAbleAddAndDel ? (
            <span className={s.tableTitle} disabled>
              {elemType}
            </span>
          ) : (
            <Dropdown
              overlay={getElemItemsMenu(elemItems, this.onChooseElemItems)}
              trigger={['click']}
            >
              <span className="ant-dropdown-link">
                <Icon type="plus-circle" />
                <span>添加{elemType}</span>
              </span>
            </Dropdown>
          )
        }
      />
    );
  }
}

export default withStyles(s)(DataGrid);
