/* eslint-disable import/no-extraneous-dependencies */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Table } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../../../../components/Link';
import {
  OperationStatus,
  saveButtonText
} from '../../../../constants/MenuTypes';
import {
  classnames,
  componentUpdateByState
} from '../../../../core/utils';
import FormFooterActionBar from '../FormFooterActionBar';
import iconDown from '../../../../static/images/ic_arrowdown_blue_down.png';
import s2 from './index.less';
import s from '../index.less';

const SHOW_BASE_NUMBER = 15;

const columns = [
  {
    title: '设备号',
    dataIndex: 'deviceId',
    className: s2.deviceId,
    render: text => <span>{text}</span>
  },
  {
    title: '备注',
    dataIndex: 'comment',
    className: s2.comment,
    render: text => <span>{text}</span>
  }
];

class SelfTest extends Component {
  static propTypes = {
    selfTestDevice: PropTypes.shape({
      deviceList: PropTypes.arrayOf(PropTypes.object.isRequired)
    }).isRequired,
    onSaveData: PropTypes.func.isRequired,
    onGoToAppList: PropTypes.func.isRequired,
    getSelfTestDeviceList: PropTypes.func.isRequired,
    slotUdid: PropTypes.string.isRequired,
    generateSelfTestMaterial: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const { selfTestDevice: { deviceList }, slotUdid } = this.props;
    this.state = {
      slotUdid,
      showList: [...deviceList] && deviceList.slice(0, SHOW_BASE_NUMBER),
      showAllDevice: false,
      deviceList
    };
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentDidMount() {
    this.props.getSelfTestDeviceList('open');
  }

  componentWillReceiveProps(nextProps) {
    const { selfTestDevice: { deviceList }, slotUdid } = nextProps;
    this.setState({
      slotUdid,
      showList: [...deviceList] && deviceList.slice(0, SHOW_BASE_NUMBER),
      showAllDevice: deviceList.length > SHOW_BASE_NUMBER,
      deviceList
    });
  }

  onSave = btnText => {
    const { slotUdid } = this.state;
    // true 保存；false: 保存并继续
    const saveType = btnText === saveButtonText[0];
    this.props.onSaveData(saveType);
    this.props.generateSelfTestMaterial(slotUdid);
  };

  onCancel = () => {
    // 点击取消后，点击确定按钮，跳转到对应的页面
    this.props.onGoToAppList('adPos');
  };

  showAllDevice = type => {
    const { showAllDevice, deviceList } = this.state;
    this.setState({
      showAllDevice: !showAllDevice,
      showList: type === 'expand' ? [...deviceList] : [...deviceList].slice(0, SHOW_BASE_NUMBER)
    });
  };

  render() {
    const { slotUdid, showAllDevice, showList, deviceList } = this.state;
    const cancelHintText = '您当前正在新建广告位的自测步骤，确定要取消新建吗？';
    const formValid = true;
    return (
      <div className={s.main}>
        <div
          className={classnames({
            [s.setting]: true,
            [s2.integration]: true
          })}
        >
          <div className={s.setting__title}>
            集成
            <div className={s2['integration_content']}>
              恭喜您已经成功创建广告位及样式，请根据如下步骤接入和自测；
              <br />
              1 &nbsp; 请使用该广告位ID进行接入：<strong>{slotUdid}</strong>
              <br />
              2 &nbsp;
              接入完成之后，进入集成与自测阶段，SDK与API接入需要添加自测设备的设备号，JSSDK对接则无需再添加自测设备号
              <br />
              3 &nbsp;
              确认自测设备列表并保存（或保存并继续）之后，等待15分钟左右，即可请求到自测广告，如有疑问，请参考<Link target='_blank' to='/developer/helpCenter'>
                帮助中心
              </Link>查看详情指导
            </div>
          </div>
        </div>
        <div
          className={classnames({
            [s.setting]: true,
            [s2.deviceTable]: true
          })}
        >
          <div className={s.setting__title}>
            确认自测设备
            <div className={s2.selfDevice}>
              请确认自测设备的设备号已经在下表中，如需进行添加/删除/修改等操作，请前往<Link target='_blank' to='/developer/accountManagement/deviceInfo'>
                账户管理-自测设备管理
              </Link>
            </div>
            <Table
              rowKey={record => record.id}
              columns={columns}
              dataSource={showList}
              pagination={false}
              bordered
            />
            <div
              style={{ display: deviceList.length > 15 ? 'inline-block' : 'none' }}
              className={s2.openBtn}
              onClick={() => this.showAllDevice(showAllDevice ? 'expand' : 'fold')}
              role="none"
            >
              <div>{showAllDevice ? '展开' : '收起'}</div>
              <img
                src={iconDown}
                alt="arrow"
                className={s2.openIcon}
                style={{ transform: showAllDevice ? '' : 'rotate(180deg)' }}
              />
            </div><br/>
            获取自测物料
            <div className={s2.selfDeviceConfirm} style={{ marginTop: '10px' }}>
              请确认自测设备并保存（或保存并继续）之后，等待15分钟左右，即可请求到自测广告，如有疑问，请参考<Link target='_blank' to='/developer/helpCenter'>
                帮助中心
              </Link>查看详情指导
            </div>
          </div>
        </div>
        <FormFooterActionBar
          status="load_success"
          cancelHintText={cancelHintText}
          saveButtonText={saveButtonText}
          saveButtonValid={status !== OperationStatus.load_fail && formValid}
          onSave={this.onSave}
          onCancel={this.onCancel}
        />
      </div>
    );
  }
}

export default withStyles(s, s2)(SelfTest);
