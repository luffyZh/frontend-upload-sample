import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import _ from 'lodash';
import IfComp from 'if-comp';
import NewApp, { checkAppNameValidity, checkAppTypeValidity, checkAppPackageOrItunesValidity } from './NewApp';
import FormFooterActionBar from '../FormFooterActionBar';
import {
  NewAppSettingItems,
  OperationStatus,
  saveButtonText
} from '../../../../constants/MenuTypes';
import { componentUpdateByState } from '../../../../core/utils';
import s from '../index.less';

class App extends Component {
  static propTypes = {
    status: PropTypes.oneOf(_.keys(OperationStatus)).isRequired,
    appTag: PropTypes.bool.isRequired,
    newApp: PropTypes.shape({}).isRequired,
    onDataChange: PropTypes.func.isRequired,
    onSaveData: PropTypes.func.isRequired,
    onGoToAppList: PropTypes.func.isRequired,
    isCreate: PropTypes.bool.isRequired,
    changeSaveType: PropTypes.func.isRequired
  };

  constructor(props) {
    super(props);
    const { status, newApp, isCreate } = props;
    // 取消新建后跳转的路径
    this.subItemValidity = Object.create(null);
    this.setValidity(props);
    this.state = {
      status,
      newApp,
      formValid: this.getFormValid(),
      isCreate
    };
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentWillReceiveProps(nextProps) {
    this.setValidity(nextProps);
    this.setState({
      status: nextProps.status,
      newApp: nextProps.newApp,
      formValid: this.getFormValid(),
      isCreate: nextProps.isCreate
    });
  }

  // itemType: 当前编辑的项，如：平台； value：当前编辑项的值，如：安卓
  onNewAppChange = (itemType, itemValue) => {
    this.props.onDataChange(NewAppSettingItems[0].value, itemType, itemValue);
  };

  onAppNameChange = value => {
    this.onNewAppChange('appName', value);
  };

  onOsTypeChange = value => {
    this.onNewAppChange('osType', value);
  };

  onCategoryChange = value => {
    this.onNewAppChange('appType', value);
  };
  
  onAndroidOrItunesChange = value => {
    this.onNewAppChange('androidOrItunes', value);
  };

  onSave = btnText => {
    // true 保存；false: 保存并继续
    const saveType = btnText === saveButtonText[0];
    this.props.changeSaveType(saveType);
    this.props.onSaveData(saveType);
  };

  onCancel = () => {
    // 点击取消后，点击确定按钮，跳转到对应的页面
    this.props.onGoToAppList('app');
  };

  setValidity = data => {
    this.setNewAppValidity(data.newApp);
  };

  setNewAppValidity = na => {
    this.subItemValidity.newApp = [
      checkAppNameValidity(na.appName), // appName validity
      checkAppTypeValidity(na.appType), // appType validity
      checkAppPackageOrItunesValidity(na.androidOrItunes)
    ];
  };

  getFormValid = () =>
    _.values(this.subItemValidity)
      .map(subArr => subArr.reduce((a, b) => a && b))
      .reduce((a, b) => a && b);

  render() {
    const { status, newApp, formValid, isCreate } = this.state;
    const cancelHintText = '您当前正在新建应用，确定要取消新建吗？';
    const { newApp: newAppValidity } = this.subItemValidity;

    return (
      <div className={s.main}>
        <NewApp
          {...newApp}
          isCreate={isCreate}
          status={status}
          appNameValid={newAppValidity[0]}
          appTypeValid={newAppValidity[1]}
          onAppNameChange={this.onAppNameChange}
          onOsTypeChange={this.onOsTypeChange}
          onCategoryChange={this.onCategoryChange}
          onAndroidOrItunesChange={this.onAndroidOrItunesChange}
        />
        <IfComp
          expression={isCreate}
          trueComp={
            <FormFooterActionBar
              status={status}
              cancelHintText={cancelHintText}
              saveButtonText={saveButtonText}
              saveButtonValid={status !== OperationStatus.load_fail && formValid}
              onSave={this.onSave}
              onCancel={this.onCancel}
            />
          }
        />
      </div>
    );
  }
}

export default withStyles(s)(App);
