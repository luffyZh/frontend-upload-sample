import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Button, Icon, Modal } from 'antd';
import _ from 'lodash';
import { OperationStatus } from '../../../constants/MenuTypes';
import s from './index.less';

const { confirm } = Modal;
class FormFooterActionBar extends Component {
  static propTypes = {
    status: PropTypes.oneOf(_.keys(OperationStatus)).isRequired,
    cancelHintText: PropTypes.string,
    saveButtonValid: PropTypes.bool.isRequired,
    onCancel: PropTypes.func.isRequired,
    onSave: PropTypes.func.isRequired,
    saveButtonText: PropTypes.arrayOf(PropTypes.string.isRequired).isRequired
  };

  static defaultProps = {
    cancelHintText: '是否取消？'
  };

  onClickCancel = () => {
    confirm({
      title: '提示',
      content: this.props.cancelHintText,
      onOk: () => {
        setTimeout(this.props.onCancel, 300);
      },
      cancelText: '取消',
      onCancel() {},
      okText: '确定'
    });
  };

  onSave = e => {
    const { status } = this.props;
    // 不能再次触发的状态
    if (
      status === OperationStatus.editing ||
      status === OperationStatus.load_success ||
      status === OperationStatus.save_fail
    ) {
      this.props.onSave(e.target.innerText);
    }
  };

  getSaveIcon = (status, valid) => {
    switch (status) {
      case OperationStatus.saving:
        return (
          <Icon
            type="sync"
            style={{
              animation: 'loadingCircle 1s infinite linear'
            }}
          />
        );
      case OperationStatus.save_success:
        return <Icon type="check-circle" />;
      case OperationStatus.save_fail:
        return (
          <Icon
            type="close-circle"
            style={{ color: valid ? '#f04134' : '#e6e6e6' }}
          />
        );
      default:
        return null;
    }
  };

  render() {
    const {
      status,
      saveButtonValid,
      saveButtonText
    } = this.props;

    return (
      <div className={s.actionBar}>
        {saveButtonText[1] && (
          <Button
            size='large'
            type='primary'
            disabled={!saveButtonValid}
            onClick={this.onSave}
          >
            {this.getSaveIcon(status, saveButtonValid)}
            {saveButtonText[1]}
          </Button>
        )}
        <Button
          size='large'
          disabled={!saveButtonValid}
          onClick={this.onSave}
        >
          {this.getSaveIcon(status, saveButtonValid)}
          {saveButtonText[0]}
        </Button>
        <Button size="large" onClick={this.onClickCancel}>
          取消
        </Button>
      </div>
    );
  }
}

export default FormFooterActionBar;
