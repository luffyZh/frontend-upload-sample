import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import packageImage from '../../../../static/images/ic_to_audit_package.png';
import downloadImage from '../../../../static/images/ic_to_audit_download.png';
import deleteImage from '../../../../static/images/ic_to_audit_delete.png';
import s from './index.less';

class DownloadFile extends Component {
  static propTypes = {
    deletePackage: PropTypes.func,
    filename: PropTypes.string,
    slotUdid: PropTypes.string.isRequired,
    packageName: PropTypes.string.isRequired,
    canDelete: PropTypes.bool.isRequired
  }
  static defaultProps = {
    filename: '',
    deletePackage: null
  }
  constructor(props) {
    super(props);
    const {
      filename,
      slotUdid,
      packageName,
      canDelete
    } = props;
    this.state = {
      filename,
      hoverContainerShow: false,
      slotUdid,
      packageName,
      canDelete
    };
  }

  componentWillReceiveProps(nextProps) {
    const {
      filename,
      slotUdid,
      packageName,
      canDelete
    } = nextProps;
    this.setState({
      filename,
      slotUdid,
      packageName,
      canDelete
    });
  }

  render() {
    const { hoverContainerShow, filename, slotUdid, packageName, canDelete } = this.state;
    // eslint-disable-next-line
    const downloadSrc = `${location.href.substring(0, location.href.indexOf('/appManagement'))}/downloadFile/${slotUdid}?packageName=${packageName}`;
    return (
      <div
        className={s.downloadContainer}
        onMouseEnter={() => this.setState({ hoverContainerShow: !hoverContainerShow })}
        onMouseLeave={() => this.setState({ hoverContainerShow: !hoverContainerShow })}
      >
        <iframe
          style={{ display: 'none' }}
          title='downloadIframe'
          name='downloadIframe'
          id='downloadIframe'
        />
        <img className={s.downloadIcon} alt='package' src={packageImage} />
        <span className={s.downloadText}>{filename || packageName}</span>
        <span className={s.downloadText}>上传成功</span>
        <div className={s.hoverContainer} style={{ display: hoverContainerShow ? 'table-cell' : 'none' }}>
          <div className={s.iconContainer}>
            <a
              target='downloadIframe'
              href={downloadSrc}
              className={s.iconButton}
              style={{ display: filename ? 'none' : 'inline-block' }}
            >
              <img
                title='下载安装包'
                className={s.downloadIcon}
                alt='download'
                src={downloadImage}
              />
            </a>
            <div
              className={s.iconButton}
              style={{ display: canDelete ? 'inline-block' : 'none' }}
              onClick={() => this.props.deletePackage()}
            >
              <img
                title='删除安装包'
                className={s.downloadIcon}
                alt='delete'
                src={deleteImage}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default withStyles(s)(DownloadFile);