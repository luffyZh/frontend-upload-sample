import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import _ from 'lodash';
import NewAdSteps from './Steps';
import { AppTabTypes, OperationStatus } from '../../../constants/MenuTypes';
import App from './app';
import AdSlot from './adSlot';
import SelfTest from './selfTest';
import ToAUdit from './toAudit';
import s from './index.less';

// 获取新建页面，左侧导航包含的级数，通过editing、initial判断，以及数组的length
const getStepInfo = (
  tabType,
  appData,
  adPosData,
  selfTestData,
  toAuditData,
) => {
  switch (tabType) {
    case AppTabTypes.appTab:
      return [
        appData.status,
        adPosData.status,
        selfTestData.status,
        toAuditData.status
      ];
    case AppTabTypes.appAdPosTab:
      return [adPosData.status, selfTestData.status, toAuditData.status];
    default:
      throw new Error(`无效参数: ${tabType}`);
  }
};

class New extends Component {
  static propTypes = {
    tabType: PropTypes.oneOf(_.keys(AppTabTypes)).isRequired,
    appData: PropTypes.shape({}).isRequired,
    adPosData: PropTypes.shape({}).isRequired,
    selfTestData: PropTypes.shape({}).isRequired,
    toAuditData: PropTypes.shape({}).isRequired,
    isEdit: PropTypes.bool.isRequired,
    onEditApp: PropTypes.func.isRequired,
    onEditAdPos: PropTypes.func.isRequired,
    onEditSelfTest: PropTypes.func.isRequired,
    onEditToAudit: PropTypes.func.isRequired,
    onAppDataChange: PropTypes.func.isRequired,
    onSaveAppData: PropTypes.func.isRequired,
    onAdPosAddElem: PropTypes.func,
    onAddOrDelStyle: PropTypes.func,
    onAdPosDataChange: PropTypes.func.isRequired,
    onSaveAdPosData: PropTypes.func.isRequired,
    onSaveSelfTestData: PropTypes.func.isRequired,
    onSaveToAuditData: PropTypes.func.isRequired,
    onGoToAppList: PropTypes.func.isRequired,
    getAppNameById: PropTypes.func.isRequired,
    getSelfTestDeviceList: PropTypes.func.isRequired,
    getAdSlotAuditInfo: PropTypes.func.isRequired,
    changeSlotAuditSource: PropTypes.func.isRequired,
    changeSaveType: PropTypes.func.isRequired,
    getAdSlotInfo: PropTypes.func.isRequired,
    generateSelfTestMaterial: PropTypes.func.isRequired
  };

  static defaultProps = {
    onAdPosAddElem: null,
    onAddOrDelStyle: null
  };

  constructor(props) {
    super(props);
    const { tabType, appData, adPosData, selfTestData, toAuditData } = props;
    this.state = {
      steps: getStepInfo(
        tabType,
        appData,
        adPosData,
        selfTestData,
        toAuditData,
      ),
      appData,
      adPosData,
      selfTestData,
      toAuditData,
      jumpTo: -1
    };
    this.getComponentMethodArray = [
      this.getAppComponent,
      this.getAdPosComponent,
      this.getSelfTestComponent,
      this.getToAuditComponent
    ];
    this.hasAudit = false;
  }

  componentWillReceiveProps({
    tabType,
    appData,
    adPosData,
    selfTestData,
    toAuditData
  }) {
    const steps = getStepInfo(
      tabType,
      appData,
      adPosData,
      selfTestData,
      toAuditData,
    );
    const nextState = {
      steps,
      appData,
      adPosData,
      selfTestData,
      toAuditData
    };
    const {
      jumpTo,
      appData: appData2,
      adPosData: adPosData2,
      selfTestData: selfTestData2,
      toAuditData: toAuditData2
    } = this.state;
    if (jumpTo >= 0) {
      const tmp = [appData, adPosData, selfTestData, toAuditData].slice(
        4 - steps.length,
      );
      const tmp2 = [appData2, adPosData2, selfTestData2, toAuditData2].slice(
        4 - steps.length,
      );
      if (
        jumpTo < tmp.length &&
        // 修复bug，这个bug会导致从第二步到第三步的时候无法正常跳转
        (tmp2[jumpTo].status === OperationStatus.saving ||
        tmp[jumpTo].status === OperationStatus.save_success)
      ) {
        nextState.jumpTo = -1;
      }
    }
    this.setState(nextState);
  }

  shouldComponentUpdate = (nextProps, nextState) => {
    const {
      tabType,
      appData,
      adPosData,
      selfTestData,
      toAuditData
    } = this.props;
    const { jumpTo } = this.state;
    return (
      tabType !== nextProps.tabType ||
      appData !== nextProps.appData ||
      adPosData !== nextProps.adPosData ||
      selfTestData !== nextProps.selfTestData ||
      toAuditData !== nextProps.toAuditData ||
      jumpTo !== nextState.jumpTo
    );
  };

  // 点击左侧的导航
  onGoToStep = stepIndex => {
    this.setState(
      {
        jumpTo: stepIndex
      },
      () => {
        const { steps } = this.state;
        const {
          onEditApp,
          onEditAdPos,
          onEditSelfTest,
          onEditToAudit
        } = this.props;
        // eslint-disable-next-line
      const editActionArr = [onEditApp, onEditAdPos, onEditSelfTest, onEditToAudit].slice(4 - steps.length);

        if (stepIndex < editActionArr.length) {
          editActionArr[stepIndex]();
        }
      },
    );
  };

  getAppComponent = (currentIndex, progress) => {
    const { appData } = this.state;
    const { onAppDataChange, onSaveAppData, onGoToAppList, changeSaveType } = this.props;
    return (
      <App
        {...appData}
        isCreate={!(progress > currentIndex)}
        onDataChange={onAppDataChange}
        onSaveData={onSaveAppData}
        onGoToAppList={onGoToAppList}
        changeSaveType={changeSaveType}
      />
    );
  };

  getAdPosComponent = () => {
    const { toAuditData, adPosData } = this.state;
    const {
      uploadScreenShot: { styleInfo: auditStyleInfo },
      uploadInstallPackage: { installPackage }
    } = toAuditData;
    const {
      onAdPosAddElem,
      onAddOrDelStyle,
      onAdPosDataChange,
      onSaveAdPosData,
      onGoToAppList,
      getAppNameById,
      changeSaveType,
      isEdit,
      getAdSlotInfo,
      getAdSlotAuditInfo
    } = this.props;
    return (
      <AdSlot
        {...adPosData}
        isEdit={isEdit}
        onAdPosAddElem={onAdPosAddElem}
        onAddOrDelStyle={onAddOrDelStyle}
        onDataChange={onAdPosDataChange}
        onSaveData={onSaveAdPosData}
        onGoToAppList={onGoToAppList}
        getAppNameById={getAppNameById}
        changeSaveType={changeSaveType}
        getAdSlotInfo={getAdSlotInfo}
        auditStyleInfo={auditStyleInfo}
        getAdSlotAuditInfo={getAdSlotAuditInfo}
        installPackage={installPackage}
      />
    );
  };

  getSelfTestComponent = () => {
    const { selfTestData, adPosData: { adPosInfo: { adPosId } } } = this.state;
    const {
      onSaveSelfTestData,
      onGoToAppList,
      getSelfTestDeviceList,
      generateSelfTestMaterial
    } = this.props;
    return (
      <SelfTest
        {...selfTestData}
        slotUdid={adPosId}
        onSaveData={onSaveSelfTestData}
        onGoToAppList={onGoToAppList}
        getSelfTestDeviceList={getSelfTestDeviceList}
        generateSelfTestMaterial={generateSelfTestMaterial}
      />
    );
  };

  getToAuditComponent = () => {
    const { toAuditData, adPosData } = this.state;
    const { uploadScreenShot } = toAuditData;
    const { styleObj } = adPosData;
    // 修复通过左侧slidebar新增样式回来的时候不现实新增样式，重新获取审核数据
    const isNewAddStyle = uploadScreenShot.styleInfo.length !== styleObj.styleInfo.length;
    const {
      onSaveToAuditData,
      onGoToAppList,
      getAdSlotAuditInfo,
      changeSlotAuditSource,
      isEdit
    } = this.props;
    return (
      <ToAUdit
        {...toAuditData}
        isEdit={isEdit}
        hasAudit={this.hasAudit && !isNewAddStyle}
        hasGoToAudit={this.hasGoToAudit}
        onSaveData={onSaveToAuditData}
        onGoToAppList={onGoToAppList}
        getAdSlotAuditInfo={getAdSlotAuditInfo}
        changeSlotAuditSource={changeSlotAuditSource}
      />
    );
  };

  // 左侧导航当前所在项
  getCurrentIndex = steps => {
    const { length } = steps;
    const { saveType: appSaveType } = this.state.appData.newApp;
    const { saveType: adSlotSaveType } = this.state.adPosData.adPosInfo;
    if (length === 4) {
      if (steps[1] === OperationStatus.initial) {
        return 0;
      }
      if (steps[2] === OperationStatus.initial) {
        return appSaveType ? 0 : 1;
      }
      if (steps[3] === OperationStatus.initial) {
        return 2;
      }
      return 3;
    }
    if (length === 3) {
      if (steps[1] === OperationStatus.initial) {
        return 0;
      }
      if (steps[2] === OperationStatus.initial) {
        // 如果不加saveType判断保存的时候会先跳转到自测页面再弹窗
        return adSlotSaveType ? 0 : 1;
      }
      return 2;
    }
    if (length === 2) {
      if (steps[1] === OperationStatus.initial) {
        return 0;
      }
      return 1;
    }
    return 0;
  };

  getProgress = () => {
    const { appData, adPosData, selfTestData } = this.state;
    switch (this.props.tabType) {
      case AppTabTypes.appTab: {
        if (!appData.appTag) {
          return 0;
        }
        if (!adPosData.adPosTag) {
          return 1;
        }
        if (!selfTestData.selfTestTag) {
          return 2;
        }
        return 3;
      }
      case AppTabTypes.appAdPosTab: {
        if (!adPosData.adPosTag) {
          return 0;
        }
        if (!selfTestData.selfTestTag) {
          return 1;
        }
        return 2;
      }
      default:
        return 0;
    }
  };

  hasGoToAudit = () => (
    this.hasAudit = true
  )

  render() {
    const { isEdit } = this.props;
    const { steps, jumpTo } = this.state;
    const progress = this.getProgress();
    const getComponentMethods = this.getComponentMethodArray.slice(
      4 - steps.length,
    );
    const currentIndex = jumpTo >= 0 ? jumpTo : this.getCurrentIndex(steps);

    return (
      <section className="root">
        <div className={s.container}>
          <NewAdSteps
            total={steps.length}
            current={currentIndex}
            progress={progress}
            onGoToStep={this.onGoToStep}
            isEdit={isEdit}
          />
          {getComponentMethods[currentIndex](currentIndex, progress)}
        </div>
      </section>
    );
  }
}

export default withStyles(s)(New);
