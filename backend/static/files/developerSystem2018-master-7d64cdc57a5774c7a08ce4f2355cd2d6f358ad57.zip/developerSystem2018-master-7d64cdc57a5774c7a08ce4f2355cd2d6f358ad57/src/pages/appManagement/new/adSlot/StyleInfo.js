import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Icon, Radio, Modal } from 'antd';
import _ from 'lodash';
import IfComp from 'if-comp';
import {
  AdPosObject,
  flowStyleItems,
  AdPosTypeForFE,
  SlotStyleFE2BE,
  AdPosTypeForBE,
  SlotStyleAuditStatusForBE,
  SlotOpStatusMapForFE,
  AppAdposListMapForFE
} from '../../../../constants/MenuTypes';
import {
  classnames,
  updateComponentStateByKeys,
  componentUpdateByState,
  generateDetailInfo,
  checkStyleInfoNameIsRepeat,
  renameAddStyleInfo,
  checkVersionIsValid
} from '../../../../core/utils';
import AdPosStyle from './AdPosStyle';
import ImageUploader from './ImageUploader';
import DownloadFile from '../toAudit/DownloadFile';
import pic_banner from '../../../../static/images/pic_banner.png';
import pic_enVideo from '../../../../static/images/pic_enVideo.png';
import pic_focusImg from '../../../../static/images/pic_focusImg.png';
import pic_insertScreen from '../../../../static/images/pic_insertScreen.png';
import pic_openScreen from '../../../../static/images/pic_openScreen.png';
import pic_infoFlow_bigImage from '../../../../static/images/pic_infoFlow_bigImage.png';
import pic_infoFlow_smallImage from '../../../../static/images/pic_infoFlow_smallImage.png';
import pic_infoFlow_exImage from '../../../../static/images/pic_infoFlow_exImage.png';
import pic_infoFlow_video from '../../../../static/images/pic_infoFlow_video.png';
import s from '../index.less';
import s2 from './index.less';

const exampleImgs = {
  pic_banner,
  pic_enVideo,
  pic_focusImg,
  pic_insertScreen,
  pic_openScreen,
  pic_infoFlow_bigImage,
  pic_infoFlow_smallImage,
  pic_infoFlow_exImage,
  pic_infoFlow_video
};

const { Group: RadioGroup } = Radio;
const { confirm } = Modal;

const addContainerStyle = {
  display: 'inline-block',
  cursor: 'pointer'
};

const adPosTypeItems = adPosType =>
  <IfComp
    expression={adPosType === 'infoFlow'}
    trueComp={
      flowStyleItems.map(t => (
        <Radio className={s.radio} key={t.value} value={t.value}>
          {t.name}
        </Radio>
      ))
    }
    falseComp={
      <Radio className={s.radio} key={adPosType} value={adPosType}>
        {SlotStyleFE2BE[adPosType]}
      </Radio>
    }
  />;

// 校验的四点：
// 1. 样式名称不能为空
// 2. 样式名称校验为true，styleNameValid=true
// 3. 图片元素、文字元素、视频元素不可同时置空；
// 4. 图片元素和文本元素存在时，其校验，即nameValid和keyValid均为true
const checkStyleInfoValidity = styinfo =>
  styinfo.every(
    t =>
      (typeof t.schemaStandardTemplateName === 'undefined'
        ? t.styleName.trim() !== '' : t.schemaStandardTemplateName.trim() !== '') &&
      t.styleNameValid &&
      checkVersionIsValid(t.minSupportVersion) &&
      (typeof t.videoElements === 'undefined'
        ? t.imageElements.length + t.textElements.length > 0
        : t.imageElements.length + t.textElements.length + t.videoElements.length > 0) &&
      (t.imageElements.length === 0 ||
        (t.imageElements.length > 0 &&
          t.imageElements.every(p => p.nameValid && p.keyValid && p.width !== '' && p.height !== ''))) &&
      (t.textElements.length === 0 ||
        (t.textElements.length > 0 && t.textElements.every(p => p.nameValid && p.keyValid && /^[1-9][0-9]*$/.test(p.length)))),
  );

/* eslint-disable react/no-unused-prop-types */
class StyleInfo extends Component {
  static propTypes = {
    styleInfo: PropTypes.arrayOf(PropTypes.object.isRequired).isRequired,
    adPosType: PropTypes.string.isRequired,
    presetStandardData: PropTypes.object.isRequired,
    onAddElem: PropTypes.func,
    onAddOrDelStyle: PropTypes.func,
    onFlowInfoTypeChange: PropTypes.func.isRequired,
    onStyleNameChange: PropTypes.func.isRequired,
    onStyleNameBlur: PropTypes.func.isRequired,
    onObjectChange: PropTypes.func.isRequired,
    onAppVersionChange: PropTypes.func.isRequired,
    onElemInfoItemChange: PropTypes.func.isRequired,
    isEdit: PropTypes.bool.isRequired,
    slotOpStatus: PropTypes.number.isRequired,
    auditStyleInfo: PropTypes.array.isRequired,
    installPackage: PropTypes.object.isRequired,
    adPosId: PropTypes.string
  };

  static defaultProps = {
    onAddElem: null,
    onAddOrDelStyle: null,
    adPosId: ''
  };

  constructor(props) {
    super(props);
    const {
      styleInfo,
      adPosType,
      presetStandardData,
      slotOpStatus,
      auditStyleInfo,
      adPosId
    } = this.props;
    this.state = {
      styleInfo,
      adPosType,
      presetStandardData,
      slotOpStatus,
      auditStyleInfo,
      adPosId
    };
    this.componentWillReceiveProps = updateComponentStateByKeys([
      'styleInfo',
      'adPosType',
      'presetStandardData',
      'slotOpStatus',
      'auditStyleInfo',
      'adPosId'
    ]);
    this.shouldComponentUpdate = componentUpdateByState;
  }

  onAddElem = (elemType, elemValue, index) => {
    this.props.onAddElem(elemType, elemValue, index);
  };

  onDelStyle = index => {
    const { styleInfo } = this.state;
    const newStyleInfo = [...styleInfo];
    newStyleInfo.splice(index, 1);
    this.props.onAddOrDelStyle(newStyleInfo);
  };

  addStyle = () => {
    const { styleInfo, adPosType, presetStandardData } = this.state;
    const newStyleInfo = [...styleInfo];
    const addNewStyle = generateDetailInfo(presetStandardData, AdPosTypeForBE[adPosType]);
    newStyleInfo.push(renameAddStyleInfo(newStyleInfo, addNewStyle));
    this.props.onAddOrDelStyle([...newStyleInfo]);
    if (checkStyleInfoNameIsRepeat(styleInfo, addNewStyle.schemaStandardTemplateName)) {
      // 样式名重复
      addNewStyle.styleNameValid = false;
      addNewStyle.styleNameRepeat = true;
      this.props.onStyleNameChange(addNewStyle.schemaStandardTemplateName, false, newStyleInfo.length - 1);
    }
  };

  deleteStyle = index => {
    confirm({
      title: '该操作会永久删除该样式，确定继续吗？',
      content: '',
      onOk:() => {
        const { styleInfo } = this.state;
        const newStyleInfo = [...styleInfo];
        this.props.onAddOrDelStyle(newStyleInfo.filter((item, key) => key !== index));
      },
      cancelText: '取消',
      onCancel: () => { },
      okText: '确认'
    });
  }

  styleStandardTemplateId = (styleStandardTemplateId, index, styleAuditStatus, adPosType, slotOpStatus) => (
    <div className={s['setting-item']}>
      <div
        className={classnames({
          [s['setting-item__name']]: true,
          [s['radio']]: true
        })}
      >
        样式类型
      </div>
      <div
        className={classnames({
          [s['setting-item__value']]: true,
          [s2['setting-item__value']]: true
        })}
      >
        <RadioGroup
          size="large"
          value={AdPosTypeForFE[styleStandardTemplateId]}
          onChange={e => this.props.onFlowInfoTypeChange(e.target.value, index)} // 这里触发函数改变flowInfoStyleType这个store里的值
          disabled={
            slotOpStatus === SlotOpStatusMapForFE.已删除 ||
            !(styleAuditStatus === SlotStyleAuditStatusForBE.草稿 ||
            styleAuditStatus === SlotStyleAuditStatusForBE.审核不通过)
          }
        >
          {adPosTypeItems(adPosType)}
        </RadioGroup>
      </div>
    </div>
  );

  previewImageComponent = (index, auditStyleInfo, styleId) => {
    const imageInfoList = (auditStyleInfo.filter(
      item => item.styleId === styleId).length > 0 && auditStyleInfo.filter(
      item => item.styleId === styleId)[0].styleScreenshot) || [];
    return (
      <div className={s2.styleScreenshotImage}>
        <ImageUploader
          imageInfoList={imageInfoList}
          maxSize={1 * 1024 * 1024}
          text="查看图片"
          type='Image'
        />
      </div>
    );
  };

  render() {
    const {
      adPosType,
      styleInfo,
      presetStandardData,
      slotOpStatus,
      auditStyleInfo,
      adPosId
    } = this.state;
    const {
      onStyleNameChange,
      onObjectChange,
      onAppVersionChange,
      onElemInfoItemChange,
      onStyleNameBlur,
      isEdit,
      installPackage
    } = this.props;
    const newStyleInfo = styleInfo.map((t, i) => {
      t.key = i;
      return t;
    });
    return (
      <div className={s.setting}>
        <div className={s.setting__title}>样式信息</div>
        {newStyleInfo.map((sty, index) => {
          const exampleImgKey = _.keys(exampleImgs).find(t => {
            if (adPosType === AdPosObject[1].value) {
              return t === `pic_${adPosType}_${AdPosTypeForFE[sty.styleStandardTemplateId]}`;
            }
            return t === `pic_${adPosType}`;
          });
          return (
            <div key={index.toString()}>
              <div className={s2.setting__body}>
                <div
                  className={s2.deleteStyleIcon}
                  style={{ display: (styleInfo.length > 1) ? 'block' : 'none' }}
                >
                  <Icon
                    type='close-circle'
                    theme='filled'
                    onClick={() => this.deleteStyle(index)}
                  />
                </div>
                {
                  this.styleStandardTemplateId(
                    sty.styleStandardTemplateId,
                    index,
                    parseInt(sty.styleAuditStatus, 10),
                    adPosType,
                    slotOpStatus
                  )
                }
                <AdPosStyle
                  styleTitle={
                    adPosType === AdPosObject[1].name
                      ? AdPosTypeForFE[sty.styleStandardTemplateId]
                      : adPosType
                  }
                  slotOpStatus={slotOpStatus}
                  isEdit={isEdit}
                  adPosType={adPosType}
                  styleAuditStatus={sty.styleAuditStatus}
                  styleName={sty.styleName}
                  styleNameValid={sty.styleNameValid}
                  versionValid={sty.versionValid}
                  styleNameRepeat={sty.styleNameRepeat}
                  presetStandardData={presetStandardData}
                  schemaStandardTemplateName={sty.schemaStandardTemplateName}
                  styleType={sty.styleType}
                  minSupportVersion={sty.minSupportVersion}
                  styleStandardTemplateId={sty.styleStandardTemplateId}
                  imageElements={sty.imageElements}
                  imageElemsList={sty.imageElemsList}
                  textElements={sty.textElements}
                  textElemsList={sty.textElemsList}
                  videoElements={sty.videoElements}
                  videoElemsList={sty.videoElemsList}
                  onAddElem={(elemType, elemValue) => {
                    this.onAddElem(elemType, elemValue, index);
                  }}
                  onDelStyle={() => this.onDelStyle(index)}
                  isShowDel={styleInfo.length > 1}
                  onStyleNameChange={(value, valid) =>
                    onStyleNameChange(value, valid, index)
                  }
                  onStyleNameBlur={(value, valid) =>
                    onStyleNameBlur(value, valid, index)
                  }
                  onObjectChange={value => onObjectChange(value, index)}
                  onAppVersionChange={value => onAppVersionChange(value, index)}
                  onElemInfoItemChange={(itemType, value) =>
                    onElemInfoItemChange(itemType, value, index)
                  }
                />
                <IfComp
                  expression={
                    (isEdit
                      && parseInt(sty.styleAuditStatus, 10) !== -1
                      && auditStyleInfo[index]
                      && auditStyleInfo[index].styleScreenshot[0].value)
                  }
                  trueComp={
                    <div className={s2.styleScreenshotContainer}>
                      <div className={s2.styleScreenshotName}>样式截图</div>
                      {auditStyleInfo[index] &&
                      this.previewImageComponent(index, auditStyleInfo, sty.styleId)}
                    </div>
                  }
                />
              </div>
              <IfComp
                expression={adPosType !== 'custom' && exampleImgKey}
                trueComp={
                  <div className={s2.setting__body_image}>
                    <img src={exampleImgs[exampleImgKey]} alt="测试图片" />
                  </div>
                }
              />
              <IfComp
                expression={index + 1 !== styleInfo.length}
                trueComp={
                  <div className={s2.splitter} />
                }
              />
            </div>
          );
        })}
        <IfComp
          expression={isEdit && installPackage.value}
          trueComp={
            <Fragment>
              <div className={s2.splitter} />
              <div className={s2.packageContainer}>
                <div className={s2.packageName}>下载安装包</div>
                <div className={s2.packageImage}>
                  <DownloadFile
                    canDelete={false}
                    slotUdid={adPosId}
                    deletePackage={null}
                    packageName={installPackage.name}
                  />
                </div>
              </div>
            </Fragment>
          }
        />
        <div
          style={{
            display: adPosType === AppAdposListMapForFE.激励视频 ? 'none' : 'block'
          }}
          className={s2.setting__footer}
        >
          <div style={addContainerStyle} onClick={this.addStyle}>
            <Icon type="plus-circle" />
            继续添加样式
          </div>
        </div>
      </div>
    );
  }
}

export { StyleInfo as default, checkStyleInfoValidity };
