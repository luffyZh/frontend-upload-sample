import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Dropdown, Menu, Button, Icon, message, Modal } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import _ from 'lodash';
import {
  TrackMultipleOperationItems,
  AppTabTypes
} from '../../../constants/MenuTypes';
import s from './index.less';

const { Item: MenuItem } = Menu;
class MultipleOperationMenu extends Component {
  static propTypes = {
    tabType: PropTypes.oneOf(_.keys(AppTabTypes)).isRequired,
    selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
    onMultipleOperation: PropTypes.func.isRequired
  };
  constructor(props) {
    super(props);
    const { tabType } = this.props;
    this.multipleOperationMenu = this.getMultipleOperationMenu(tabType);
  }

  onClickMultipleOperationMenu = ({ key: value }) => {
    const operation = TrackMultipleOperationItems.find(
      it => it.value === value,
    );
    const { tabType, selectedRowKeys, onMultipleOperation } = this.props;
    if (selectedRowKeys.length > 0) {
      if (operation === TrackMultipleOperationItems[2]) {
        const contentMsg = tabType === AppTabTypes.appTab
          ? '该操作会永久删除选中应用，以及应用下属所有广告位，确定删除吗？'
          : '该操作会永久删除选中广告位，以及广告位下属所有样式，确定删除吗？';
        // 批量删除
        Modal.confirm({
          iconType: 'exclamation-circle',
          title: '提示',
          content: contentMsg,
          okText: '确定',
          cancelText: '取消',
          onOk: () => {
            onMultipleOperation(tabType, selectedRowKeys, operation);
          }
        });
      } else {
        onMultipleOperation(tabType, selectedRowKeys, operation);
      }
    } else {
      message.warning('请先勾选下表中的数据');
    }
  };

  getMultipleOperationMenu = () => {
    const items = TrackMultipleOperationItems;
    return (
      <Menu selectedKeys={[]} onClick={this.onClickMultipleOperationMenu}>
        {items.map(item => <MenuItem key={item.value}>{item.name}</MenuItem>)}
      </Menu>
    );
  };

  render() {
    const disableMultipleOperation = false;
    return (
      <div className={s.select}>
        <Dropdown trigger={['click']} overlay={this.multipleOperationMenu}>
          <Button disabled={disableMultipleOperation}>
            批量操作 <Icon type="down" />
          </Button>
        </Dropdown>
      </div>
    );
  }
}

export default withStyles(s)(MultipleOperationMenu);
