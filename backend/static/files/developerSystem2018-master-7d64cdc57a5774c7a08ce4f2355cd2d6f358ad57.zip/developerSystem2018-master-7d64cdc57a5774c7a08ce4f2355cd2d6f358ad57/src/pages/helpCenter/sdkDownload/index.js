import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Button } from 'antd';
import s from '../index.css';
import Link from '../../../components/Link';
import iosIcon from '../../../static/images/ic_ios.png';
import androidIcon from '../../../static/images/ic_android.png';

const SdkDownload = () => (
  <div className={s.sdkDownloadContainer}>
    <div className={s.contentWrapper}>
      <div className={s.content}>
        <img src={iosIcon} alt="ios icon" />
        <span>iOS SDK</span>
        <Button type="primary">
          <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=sdk&os=0">
            下载 - v1.5.0 （71.8M）
          </a>
        </Button>
      </div>
      <div className={s.desc}>
        <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=doc&os=0">
          DEMO
        </a>
        <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=doc&os=0">
          说明文档
        </a>
        <Link to="/developer/helpCenter/sdkDownload/updateRecord/ios">
          更新记录
        </Link>
      </div>
    </div>
    <div className={s.contentWrapper}>
      <div className={s.content}>
        <img src={androidIcon} alt="android icon" />
        <span>Android SDK</span>
        <Button type="primary">
          <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=sdk&os=1">
            下载 - v1.7.0 （525kb）
          </a>
        </Button>
      </div>
      <div className={s.desc}>
        <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=doc&os=1">
          DEMO
        </a>
        <a href="http://a.youdao.com/sdkdev/downloadSDK.s?type=doc&os=1">
          说明文档
        </a>
        <Link to="/developer/helpCenter/sdkDownload/updateRecord/android">
          更新记录
        </Link>
      </div>
    </div>
  </div>
);

export default withStyles(s)(SdkDownload);
