import React, { Component } from 'react';
import { Table } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import upArrowIcon from '../../../static/images/ic_arrow_up.png';
import { faqLists, faqCategories, commonRatioSizes } from '../tableData';
import { commonRatioSizesColumns } from '../startGuide';
import s from '../index.css';

class Faq extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  handleClick(title) {
    this.setState(prevState => ({
      [title]: !prevState[title]
    }));
  }

  render() {
    const ret = [];
    faqLists.forEach((item, idx, arr) => {
      if (!arr[idx - 1] || item.category !== arr[idx - 1].category) {
        // GROUP_TITLE can be anything else, just to avoid key replication
        ret.push(
          <h2 key={item.title + 'GROUP_TITLE'}>
            {faqCategories[item.category]}
          </h2>,
        );
      }

      ret.push(
        <div
          className={s.wrapper}
          key={item.title}
          style={{
            backgroundColor: this.state[item.title] ? '#f2f2f2' : '#fff'
          }}
        >
          <div
            className={s.questionTitle}
            onClick={() => this.handleClick(item.title)}
          >
            {item.title}
            <img
              src={upArrowIcon}
              alt="arrow"
              style={
                this.state[item.title]
                  ? { transform: 'rotate(0deg)' }
                  : { transform: 'rotate(-180deg)' }
              }
            />
          </div>
          {item.content === 'commonRatioSizes' ? (
            <div
              className={s.questionContent}
              style={
                this.state[item.title]
                  ? { maxHeight: '800px', background: '#fff' }
                  : { maxHeight: '0', background: '#fff' }
              }
            >
              <div className={s.questionContentInner}>
                <Table
                  columns={commonRatioSizesColumns}
                  dataSource={commonRatioSizes}
                  rowKey={(record, index) => index}
                  bordered
                  pagination={{ hideOnSinglePage: true, defaultPageSize: 50 }}
                />
              </div>
            </div>
          ) : (
            <div
              className={s.questionContent}
              style={
                this.state[item.title]
                  ? { maxHeight: '200px' }
                  : { maxHeight: '0' }
              }
            >
              <div
                className={s.questionContentInner}
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{ __html: item.content }}
              />
            </div>
          )}
        </div>,
      );
    });

    return <div className={s.faqContainer}>{ret}</div>;
  }
}

export default withStyles(s)(Faq);
