/* eslint-disable react/no-unescaped-entities */
import React from 'react';
import { Table } from 'antd';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from '../index.css';
import { commonRatioSizes, standardElements } from '../tableData';
import img1 from '../../../static/images/guide-1.png';
import img2 from '../../../static/images/guide-2.png';
import img3 from '../../../static/images/guide-3.png';
import img4 from '../../../static/images/guide-4.png';
import img5 from '../../../static/images/guide-5.png';
import img6 from '../../../static/images/guide-6.png';
import img7 from '../../../static/images/guide-7.png';

const standardElementsColumns = [
  {
    title: 'Key',
    dataIndex: 'key',
    align: 'center'
  },
  {
    title: '名称',
    dataIndex: 'name',
    align: 'center'
  },
  {
    title: '图片/文字',
    dataIndex: 'type',
    align: 'center'
  },
  {
    title: '属性',
    dataIndex: 'attr',
    align: 'center'
  },
  {
    title: '说明',
    dataIndex: 'desc',
    align: 'center',
    render: text => (
      // eslint-disable-next-line react/no-danger
      <div dangerouslySetInnerHTML={{ __html: text }} />
    )
  }
];

export const commonRatioSizesColumns = [
  {
    title: '广告位类型',
    dataIndex: 'type',
    align: 'center',
    render: (value, row, index) => {
      const obj = {
        children: value,
        props: {}
      };
      if (index === 0) {
        obj.props.rowSpan = 4;
      }
      if (index > 0 && index < 4) {
        obj.props.rowSpan = 0;
      }
      if (index === 5) {
        obj.props.rowSpan = 3; 
      }
      if (index > 5 && index < 8) {
        obj.props.rowSpan = 0;
      }
      return obj;
    }
  },
  {
    title: '新比例',
    dataIndex: 'ratio',
    align: 'center'
  },
  {
    title: '新比例尺寸',
    dataIndex: 'size',
    align: 'center'
  },
  {
    title: '比例数',
    dataIndex: 'number',
    align: 'center'
  }
];

const StartGuide = () => (
  <div className={s.startGuideContainer}>
    <h2>一、如何成为开发者</h2>
    <h3>1、移动广告开发者管理系统注册、登录</h3>
    系统地址：<a
      href="https://zhixuan.youdao.com/dsp/website/developer.shtml?sdkdev=login"
      target="__blank"
    >
      https://zhixuan.youdao.com/dsp/website/developer.shtml?sdkdev=login
    </a>。开发者（媒体）首次登录需用163通行证号注册后才可登录系统。
    <div className={s.imgWrapper}>
      <img src={img1} alt="img1"/>
    </div>
    如还没有注册163邮箱，可以点击“去注册”先进行注册再进行；首次登录，记得还要<strong>激活有道开发者账户权限</strong>，否则会提醒没有权限，无法登陆后台。
    <h2>二、如何创建应用和广告位</h2>
    <h3>1、创建应用</h3>
    开发者成功登录系统后界面如下图所示，进入应用管理界面。
    <div className={s.imgWrapper}>
      <img src={img2} alt="img2"/>
    </div>
    点击<strong>新建应用</strong>创建应用信息，跳转至如下图所示页面填写APP相关信息。
    <div className={s.imgWrapper}>
      <img src={img3} alt="img3"/>
    </div>
    （1）应用名称必须用主流应用市场名称填写，同时必须以-安卓或-iOS作为应用名称的后缀，例：有道云笔记-安卓、有道云笔记-iOS；<br/>
    （2）应用类型需根据应用情况如实填写；<br/>
    （3）应用平台目前支持Android和iOS；<br/>
    （4）安卓包名和iTunes URL请填写真实有效的包名及连接，否则审核不通过；（iOS的包名必须为https://的链接，http://的链接填写会显示错误）<br/>
    （5）填写完成后点击保存并继续按钮，保存当前填写全部信息，跳转至编辑广告位步骤。
    <h3>2、新建广告位</h3>
    开发者在此步骤中需要编辑广告位信息，样式信息。
    <h3>（1）填写广告位信息</h3>
    <div className={s.imgWrapper}>
      <img src={img4} alt="img4"/>
    </div>
    广告位名称：请按广告位的<strong>广告位类型+屏数+路径</strong>如实命名，如：信息流一屏首页、信息流一屏搜索页-搜索等能明确定位广告位置的
    名称，应用内广告位名称不可重复；<br/>
    广告位形式：包括信息流、开屏、插屏、焦点图、横幅、激励视频和自定义广告，自定义广告支持开发者根据需要创建新广告形式；
    <h3>（2）填写样式信息</h3>
    <div className={s.imgWrapper}>
      <img src={img5} alt="img5"/>
    </div>
    <p>样式类型：不同广告位类型对应不同的样式模版，选择模版类型后，右下方有广告样式示例，开发者可根据样式示例自行选择接入样式类型</p>
    <p>样式名称：样式名称以<strong>广告位名称+样式类型+推广标的类型</strong>命名。如信息流一屏搜索页-搜索-一键下载类等能让客户简单理解广告
    位样式名称和类型的名称。</p>
    <p>推广标的类型：落地页型包括落地页下载型和落地页型广告，应用下载型指iOS直接跳转到App Store，或Android的一键下载。如既支持落地页下载
    类、落地页型，也支持一键下载类，那就选择不限。</p>
    <p>可兼容的最低版本号：有道智选广告平台会根据媒体填写的可兼容最低版本号来判断媒体app哪个版本支持新建样式，给不同的媒体版本返回他们支持的样
    式，以此保证广告能正常展示。关于版本号的注意事项有以下几点：1、app的版本号格式常见有以下几种：2.1.3V、V2.1.3、2.1.3.4V，V2.1.3.4等；
    2、app版本升级时需要按照由小到大的规律递增（如：2.1.2V版本小于2.1.3V版本；1.1.2V版本小于2.1.3V版本）；如没有版本号，填写“0”，含义是媒
    体app默认所有版本号都支持该广告；3、用英文输入法填写当前app的版本号；<strong>4、请务必在请求广告时，传回您app的版本号，并且格式要和开发
    者系统中填写的一致，否则您的新广告样式将无法被展示出来；</strong></p>
    <p>样式元素：元素有标准元素与自定义元素，建议您使用设置好的标准元素。因为对于标准元素广告商有制作好的物料，而非标准元素无法保证这一点，广
    告位必需的元素才选，不必需元素建议不用选，减少后续广告商投放广告繁琐的工作步骤。</p>
    标准元素说明表如下：
    <div className={s.tableWrapper}>
      <Table
        columns={standardElementsColumns}
        dataSource={standardElements}
        bordered
        pagination={{ hideOnSinglePage: true }}
      />
    </div>
    各类型图片比例以及常用对应尺寸如下（<strong>注意尽量用标准比例，更利于客户填充</strong>）：
    <div className={s.tableWrapper}>
      <Table
        columns={commonRatioSizesColumns}
        dataSource={commonRatioSizes}
        rowKey={(record, index) => index}
        bordered
        pagination={{ hideOnSinglePage: true, defaultPageSize: 50 }}
      />
    </div>
    <br/>
    点击继续添加样式，可以在一个广告位下建多种样式的广告。例如开发者想在信息流中同时采用大图广告与小图广告这两种形式，就可以在信息流广告位下新
    建两种样式，分别对应这两种广告形式。点击保存并继续按钮后系统自动生成该广告位ID，是一串字母和数字的组合，在下一步骤中SDK集成时会用到。
    <h2>三、集成与自测</h2>
    <div className={s.imgWrapper}>
      <img src={img6} alt="img6"/>
    </div>
    <p>在集成与自测页面，开发者需要输入自测设备的设备号，点击保存并继续（或保存）后，即可请求到自测物料。
    设备号查询方法：苹果手机请从App Store上下载IDFA后，获取自己的IDFA号；安卓手机请在本机中“设置--关于手机”页面获取自己的IMIE号；</p>
    <h2>四、提交审核</h2>
    <div className={s.imgWrapper}>
      <img src={img7} alt="img7"/>
    </div>
    <p>开发者需要将上一步骤中自测的广告位效果截图保存后上传至系统（如果某广告位包含多种样式，需要开发者将所有样式的广告效果图都截图后上传），
    将集成了SDK的应用包也上传至系统，走完前面所述整个流程才可以提交审核，否则无法提交。</p>
    <p>1、 效果图将展示给广告商，用于广告商了解广告位形式，页面位置等信息，请务必使用自测时设备截屏图片作为效果图。<br/>2、 上传应用将用于有
    道审核，请务必提交自测完成后的应用包。</p>
    <p>开发者提交审核后，联系我方工作人员进行审核，我方会尽快对开发者提交的信息进行反馈。审核通过后生效，该应用的广告位信息就能够出现在广告发
    布系统中，开发者此时可将集成SDK的应用包发布，当有广告商进行投放时，就会有广告展示在下载安装了新应用的用户设备上，开发者也可以获得收入。</p>
  </div>
);

export default withStyles(s)(StartGuide);
