import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import s from './index.css';
import SelectionBar from '../../components/Common/SelectionBar';
import StartGuide from './startGuide';
import DockingDocs from './dockingDocs';
import Faq from './faq';
import SdkDownload from './sdkDownload';

export const selectionBarList = [
  {
    name: 'startGuide',
    title: '入门指南',
    link: '/developer/helpCenter/startGuide'
  },
  {
    name: 'dockingDocs',
    title: '对接文档',
    link: '/developer/helpCenter/dockingDocs'
  },
  {
    name: 'faq',
    title: '常见问题',
    link: '/developer/helpCenter/faq'
  },
  {
    name: 'sdkDownload',
    title: 'SDK下载',
    link: '/developer/helpCenter/sdkDownload'
  }
];

const HelpCenter = ({ type }) => (
  <div className={s.root}>
    <div className={s.container}>
      <SelectionBar selectedItem={type} itemList={selectionBarList} />
      <div className={s.contentContainer}>
        <IfComp
          expression={type === 'startGuide'}
          trueComp={<StartGuide />}
          falseComp={
            <IfComp
              expression={type === 'dockingDocs'}
              trueComp={<DockingDocs />}
              falseComp={
                <IfComp
                  expression={type === 'faq'}
                  trueComp={<Faq />}
                  falseComp={<SdkDownload />}
                />
              }
            />
          }
        />
      </div>
    </div>
  </div>
);

HelpCenter.propTypes = {
  type: PropTypes.string.isRequired
};

export default withStyles(s)(HelpCenter);
