export const standardElements = [
  {
    key: 'mainimage',
    name: '主图片',
    type: '图片',
    attr: '多种比例',
    desc: '广告的主要图片'
  },
  {
    key: 'iconimage',
    name: '图标',
    type: '图片',
    attr: '1:1',
    desc: '图标，一般不用作广告的主要图片'
  },
  {
    key: 'coverimage',
    name: '视频封面图片',
    type: '图片',
    attr: '多种比例',
    desc: '视频的首帧图片，<strong>视频类广告样式的必填元素</strong>'
  },
  {
    key: 'title',
    name: '标题',
    type: '文字',
    attr: '10/20/30',
    desc: '广告标题，一般用简短的文字来给出广告的主要内容'
  },
  {
    key: 'text',
    name: '描述',
    type: '文字',
    attr: '15/20/35',
    desc: '广告描述，用来详细描述广告产品'
  },
  {
    key: 'appName',
    name: '应用名称',
    type: '文字',
    attr: '5/10',
    desc: '应用名称'
  },
  {
    key: 'companyName',
    name: '公司名称',
    type: '文字',
    attr: '5/10',
    desc: '用来显示广告商的公司名称'
  },
  {
    key: 'ctaText',
    name: '按钮文字',
    type: '文字',
    attr: '4',
    desc: '用来定义按钮上显示的文字，比如下载，打开等'
  },
  {
    key: 'videourl',
    name: '视频网址',
    type: '文字',
    attr: '1000',
    desc: '视频广告物料的网址，<strong>视频类广告样式的必填元素</strong>'
  }
];

export const commonRatioSizes = [
  {
    type: '信息流',
    ratio: '16:9',
    size: '1280:720',
    number: 1.77
  },
  {
    type: '信息流',
    ratio: '4:3',
    size: '640:480',
    number: 1.33
  },
  {
    type: '信息流',
    ratio: '3:2',
    size: '720:480',
    number: 1.5
  },
  {
    type: '信息流',
    ratio: '1:1',
    size: '640:640',
    number: 1
  },
  {
    type: 'banner',
    ratio: '32:5',
    size: '640:100',
    number: 6.4
  },
  {
    type: '开屏',
    ratio: '2:3',
    size: '720:1080',
    number: 0.66
  },
  {
    type: '开屏',
    ratio: '9:16',
    size: '720:1280',
    number: 0.56
  },
  {
    type: '开屏',
    ratio: '1:2',
    size: '640:1280',
    number: 0.5
  },
  {
    type: '焦点图',
    ratio: '16:9',
    size: '1280:720',
    number: 1.77
  },
  {
    type: '插屏',
    ratio: '1:1',
    size: '640:640',
    number: 1
  },
  {
    type: '新加比例',
    ratio: '11:4',
    size: '1320:480',
    number: 2.75
  }
];

export const faqCategories = {
  1: '注册审核',
  2: '收入相关',
  3: '广告样式',
  4: '技术对接',
  5: '数据相关'
};

export const faqLists = [
  {
    title: '提交审核后多久能有客户？',
    content: `提交审核后可通知我们审核人员或者商务，会根据排期尽快安排审核，通过审核和有客户上线会通知您放量。
    最快当天，如有问题根据实际处理时间而定。`,
    category: 1
  },
  {
    title: '是否可以注册多个账号，如何命名？',
    content:
      '不可以。为了保护开发者的收款和账户安全，同一位开发者只能拥有唯一的帐号。命名最好直接用公司名称。',
    category: 1
  },
  {
    title: '智选的收益如何计算？',
    content: '按消费分成结算，具体结算数据可以联系对应负责商务的同事获取。',
    category: 2
  },
  {
    title: '什么状态为能开始有收益？',
    content: '广告位审核通过后，有广告主投放并产生点击消费后即开始结算',
    category: 2
  },
  {
    title: '有道支持哪些广告形式？',
    content:
      '有道支持信息流图文、信息流视频、焦点图、icon、banner、开屏、激励视频等常见广告形式，此外还支持开发者自定义的原生广告形式，开发者可以根据自己应用的实际场景来进行渲染。',
    category: 3
  },
  {
    title: '如何设置多样式广告？',
    content: `有道支持一个广告位配置多个样式的广告，有利于提高广告位的填充率。当开发者想要接入多样式广告的时候，需要进行如下2步操作：<br/>
    1、在开发者系统定义好新加的样式名称、类型、样式元素和支持的版本号；<br/>
    2、保证前端能正确展示相应的多样式。具体接入步骤可查看对接文档。`,
    category: 3
  },
  {
    title: '开屏广告位的全面屏适配怎么做？',
    content:
      '建两个尺寸样式，其中全面屏比例为1：2，这样每次请求都会拿到两个图，客户端判断一下应该展示哪个合适即可。',
    category: 3
  },
  {
    title: '一般常见尺寸有哪些？',
    content: 'commonRatioSizes',
    category: 3
  },
  {
    title: 'SDK版本升级或修改名称，对广告显示是否有影响？',
    content: '无影响，广告也会正常显示。',
    category: 4
  },
  {
    title: '如果有多个包名应该填哪个？',
    content: '填接入有道广告的包名，如均有则填其中一个。',
    category: 4
  },
  {
    title: '自测环节为什么广告位无法展示？',
    content:
      '如请求返回正常，请检查元素名称和图片尺寸是否和获取的一样，不然会导致无法获取图片展示。',
    category: 4
  },
  {
    title: '为什么广告返回为空？',
    content: `(1) 有效的广告位<br />&nbsp;&nbsp;
    一般由于没有客户填充，可以反馈给运营，我们会和客户宣传媒体加快填充<br />
    (2) 待审核的广告位<br />&nbsp;&nbsp;
    a、是否没有提交到上传安装包那一步骤<br />&nbsp;&nbsp;
    b、版本号设置后需要请求上带av=版本号（除0以外）<br />&nbsp;&nbsp;
    c、测试设备是否加上测试手机imei或者idfa，并且请求要带上（如设备号填imei，请求传的是udid则无法展示）<br />&nbsp;&nbsp;
    d、api对接用服务器抓包查看请求链接核对是否有误（详细可查看最新对接文档）`,
    category: 4
  },
  {
    title: '上传监控url时候，如果失败，需要重试几次？',
    content:
      '客户端上报监测url，必须要上报成功，不然记不到，会影响开发者的收入结算。',
    category: 4
  },
  {
    title: '是否支持服务器上报？',
    content: '上报日志不支持服务器端上报，api对接支持客户端上报。',
    category: 4
  },
  {
    title: 'iOS点击广告跳转怎么有一个加载的loding？',
    content: '上这个是sdk里的，只有加载时会出现，属于正常。',
    category: 4
  },
  {
    title: '统计查询的数据为0是什么原因？',
    content:
      '可能是由于数据延迟的原因，请耐心等待；如较长时间仍未看到数据，请及时反馈。',
    category: 5
  },
  {
    title: '对接后是否有超时情况，一般达到多少时间？',
    content: '正常情况不会，我们返回时间90%在150ms以内，70%在40ms以内。',
    category: 5
  }
];

export const iosUpdateRecords = [
  {
    date: '2019-03-15',
    version: 'v2.10.0',
    content: 'deepLink跳转优化和bugfix'
  },
  {
    date: '2018-12-14',
    version: 'v2.9.1',
    content: '激励视频 bug fixes'
  },
  {
    date: '2018-10-24',
    version: 'v2.9.0',
    content: 'iPhoneX的适配'
  },
  {
    date: '2018-09-14',
    version: 'v2.8.0',
    content: '去掉缓存image和video时对size的限制'
  },
  {
    date: '2018-07-05',
    version: 'v2.7.0',
    content: '品牌广告第三方监测上报'
  },
  {
    date: '2018-06-15',
    version: 'v2.6.0',
    content: '增加广告图片预加载功能'
  },
  {
    date: '2018-01-22',
    version: 'v2.5.0',
    content: '对开屏广告获取方式进行了优化'
  },
  {
    date: '2017-12-11',
    version: 'v2.4.0',
    content: '改激励视频后台逻辑和样式'
  },
  {
    date: '2017-10-16',
    version: 'v2.3.0',
    content: '新增信息流视频广告，优化上报逻辑'
  },
  {
    date: '2017-05-23',
    version: 'v2.2.0',
    content: '支持deeplink'
  }
];

export const androidUpdateRecords = [
  {
    date: '2018-12-30',
    version: 'v4.0.1',
    content: 'deepLink跳转优化和bugfix'
  },
  {
    date: '2018-11-14',
    version: 'v3.10.9',
    content: '修复已知bug'
  },
  {
    date: '2018-09-30',
    version: 'v3.10.8',
    content: '修复已知bug'
  },
  {
    date: '2018-09-20',
    version: 'v3.10.7',
    content: 'android 8.0适配'
  },
  {
    date: '2018-06-27',
    version: 'v3.10.5',
    content: '品牌广告第三方监控上报'
  },
  {
    date: '2018-04-27',
    version: 'v3.10.2',
    content: '组件接入信息流视频广告'
  },
  {
    date: '2017-12-11',
    version: 'v3.10.1',
    content: '改激励视频后台逻辑和样式'
  },
  {
    date: '2017-05-26',
    version: 'v3.10.0',
    content: '第三方网络接入标准化'
  },
  {
    date: '2017-01-19',
    version: 'v3.9.12',
    content: 'deeplink和bug修复'
  },
  {
    date: '2017-01-04',
    version: 'v3.9.9',
    content: '修复已知bug'
  },
  {
    date: '2016-12-05',
    version: 'v3.9.8',
    content: '激励视频广告优化'
  },
  {
    date: '2016-08-11',
    version: 'v3.9.7',
    content: '增加激励视频广告'
  },
  {
    date: '2016-07-05',
    version: 'v3.9.6',
    content: 'native展示策略调整'
  },
  {
    date: '2016-05-13',
    version: 'v3.9.5',
    content: 'facebook广告优化'
  },
  {
    date: '2016-04-12',
    version: 'v3.9.4',
    content: '品牌广告支持'
  },
  {
    date: '2016-04-12',
    version: 'v3.9.3',
    content: '落地页数据加密'
  },
  {
    date: '2016-02-16',
    version: 'v3.9.2',
    content: '根据广告体中"ydAdType"字段区分广告类型'
  },
  {
    date: '2016-01-13',
    version: 'v3.9.1',
    content: '自定义落地页优化'
  },
  {
    date: '2016-01-11',
    version: 'v3.8.2',
    content: '优化落地页打开逻辑'
  },
  {
    date: '2015-10-23',
    version: 'v3.7.2',
    content: 'Android分离WebView，开屏和插屏广告增加个性化下载设置'
  },
  {
    date: '2015-10-09',
    version: 'v3.6.3',
    content: '修复已知bug'
  },
  {
    date: '2015-07-20',
    version: 'v3.6.2',
    content: '信息流广告多样式支持，品牌广告支持'
  },
  {
    date: '2015-07-14',
    version: 'v3.6.0',
    content: '透明增加nativeapi的缓存'
  },
  {
    date: '2015-07-06',
    version: 'v3.5.2',
    content: '提供插屏广告API'
  },
  {
    date: '2015-03-17',
    version: 'v3.5.0',
    content: 'landpage转化跟踪和bug修复'
  },
  {
    date: '2015-03-17',
    version: 'v3.3.0',
    content: '提供批量的原生广告API，批量展示，请求去重等功能'
  },
  {
    date: '2015-01-16',
    version: 'v3.2.0',
    content: '下载管理器优化,信息流广告去重'
  },
  {
    date: '2015-01-05',
    version: 'v3.1.0',
    content: '有道SDK的第一个版本'
  }
];
