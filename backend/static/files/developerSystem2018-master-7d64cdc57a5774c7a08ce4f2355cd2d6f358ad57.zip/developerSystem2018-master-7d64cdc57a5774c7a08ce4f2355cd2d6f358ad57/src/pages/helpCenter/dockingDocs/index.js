import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from '../index.css';

const DockingDocs = () => (
  <div className={s.dockingDocsContainer}>
    <h2>产品文档</h2>
    <div className={s.wrapper}>
      <div>
        <a
          href="https://download.ydstatic.com/ead/有道智选广告样式指导文档.pdf"
          target="_blank"
          rel="noopener noreferrer"
        >
          广告位样式指导文档
        </a>
      </div>
    </div>
    <h2>开发文档</h2>
    <div className={s.wrapper}>
      <h3>SDK 对接</h3>
      <div>
        <a href="/developer/helpCenter/sdkDownload" target="_blank">
          iOS SDK
        </a>
        <a href="/developer/helpCenter/sdkDownload" target="_blank">
          Android SDK
        </a>
        <a
          href="http://shared.ydstatic.com/js/yatdk/online_dev_doc/yatdk_development_doc.html"
          target="_blank"
          rel="noopener noreferrer"
        >
          JSSDK
        </a>
      </div>
    </div>
    <div className={s.wrapper}>
      <h3>API 对接</h3>
      <div>
        <a
          href="https://download.ydstatic.com/ead/有道智选广告API对接文档.pdf"
          target="_blank"
          rel="noopener noreferrer"
        >
          API 对接文档
        </a>
      </div>
    </div>
  </div>
);

export default withStyles(s)(DockingDocs);
