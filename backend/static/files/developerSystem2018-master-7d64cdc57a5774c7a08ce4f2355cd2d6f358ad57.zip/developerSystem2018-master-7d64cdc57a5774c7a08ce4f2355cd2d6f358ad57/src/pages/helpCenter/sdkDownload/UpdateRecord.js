import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Breadcrumb, Table } from 'antd';
import SelectionBar from '../../../components/Common/SelectionBar';
import { selectionBarList } from '../index';
import Link from '../../../components/Link';
import { iosUpdateRecords, androidUpdateRecords } from '../tableData';
import { HelpCenterSdkType } from '../../../constants/MenuTypes';
import s from '../index.css';

const { Item } = Breadcrumb;

const columns = [ 
  {
    title: '上线日期',
    dataIndex: 'date',
    key: 'date',
    width: 130
  },
  {
    title: '版本号',
    dataIndex: 'version',
    key: 'version',
    width: 100
  },
  {
    title: '更新内容',
    dataIndex: 'content',
    key: 'content',
    // for lists to show correctly, add \n at the end of every line
    render: text => {
      const arr = text.split('\n');
      if (arr.length < 2) {
        return text;
      }
      return (
        <ul style={{ listStyle: 'none', margin: '0px', padding: '0px' }}>
          {arr.map(item => <li key={item[0]}>{item}</li>)}
        </ul>
      );
    }
  }
];

class UpdateRecord extends Component {
  static propTypes = {
    type: PropTypes.string.isRequired
  };

  render() {
    const { type } = this.props;
    return (
      <div className={s.root}>
        <div className={s.container}>
          <SelectionBar
            selectedItem="sdkDownload"
            itemList={selectionBarList}
          />
          <div className={s.contentContainer}>
            <div className={s.updateRecordContainer}>
              <Breadcrumb separator=">">
                <Item>
                  <Link to="/developer/helpCenter">帮助中心</Link>
                </Item>
                <Item>
                  <Link to="/developer/helpCenter/sdkDownload">SDK下载</Link>
                </Item>
                <Item>
                  {type === HelpCenterSdkType.IOS ? 'iOS' : 'Android'} SDK
                </Item>
                <Item>版本更新记录</Item>
              </Breadcrumb>
              <h2>版本更新记录</h2>
              <div className={s.tableWrapper}>
                <Table
                  rowKey="version"
                  columns={columns}
                  dataSource={
                    type === HelpCenterSdkType.IOS
                      ? iosUpdateRecords
                      : androidUpdateRecords
                  }
                  bordered
                  pagination={{ hideOnSinglePage: true, defaultPageSize: 100 }}
                  rowClassName={(record, index) =>
                    index % 2 === 0 ? '' : 'oddRowColor'
                  }
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(UpdateRecord);
