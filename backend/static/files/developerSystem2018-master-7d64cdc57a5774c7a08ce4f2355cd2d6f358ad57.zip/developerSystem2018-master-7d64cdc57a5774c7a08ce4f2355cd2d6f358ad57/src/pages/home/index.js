import React, { Component, Fragment } from 'react';
// import PropTypes from 'prop-types';
import Summary from './summary';

class Home extends Component {
  
  constructor(props) {
    super(props);
  }
  render() {
    const newSumarry = {
      account: {
        balance: 1055.3,
        todayConsumption: 0
      },
      ad: {
        outOfBudget: 6,
        toBeAudit: 577,
        unpass: 15
      }
    };
    return (   
      <Fragment>
        <Summary ad={newSumarry.ad} account={newSumarry.account} />
      </Fragment>
    );
  }
}

export default Home;
