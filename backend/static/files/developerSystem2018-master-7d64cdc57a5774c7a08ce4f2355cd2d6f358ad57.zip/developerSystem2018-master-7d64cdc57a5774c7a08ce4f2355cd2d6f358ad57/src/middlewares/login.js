import {
  loginPage,
  indexPage
} from './links';
import api from '../api/apiDefOfBE';
import http from '../core/HttpServer';

// 读取cookies
function getCookie(cookie, name) {

  var arr, reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)');
  if (!cookie.match(reg)) {
    return null;
  }
  // eslint-disable-next-line
  if(arr=cookie.match(reg)) {
    return unescape(arr[2]);
  }
  return null;
} 

const login = async (req, res, next) => {
  try {
    const {
      _accessId: accessId,
      headers
    } = req;

    /**
     * 网易URS登录成功会写入对应的一些cookie
     * 其中P_INFO可以获取到用户邮箱
     * 解析出邮箱即视为登录成功
     */
    const P_INFO = getCookie(headers.cookie, 'P_INFO');
    if (!headers.cookie
      || !P_INFO) {
      return res.redirect(loginPage);
    }

    const { cookie } = headers;

    // 从P_INFO里提取出来登录邮箱
    const __login_email__ = P_INFO.substring(0, P_INFO.indexOf('|')).trim();

    const userInfo = await http.post(api.authorization, {
      accessId,
      params: {
        cookie
      },
      query: {
        __email__: __login_email__ 
      }
    });
    const cookieAge = 1 * 60 * 60 * 1000;
    res.setHeader('Set-Cookie',
      [
        `KFZTK=${userInfo.authorization}`,
        `KFZID=${Number(userInfo.developerId)}`,
        `KFZEMAIL=${userInfo.username}`,
        `PERMISSION_LIST=${userInfo.permissions && userInfo.permissions.join(',')}`
      ],
      'Secure',
      `Max-Age=${cookieAge}`
    );

    const currentUser = {
      sponsorId: Number(userInfo.developerId),
      email: userInfo.username || '邮箱未设置',
      token: userInfo.authorization
    };

    console.log('login', currentUser);
    res.redirect(indexPage);
  } catch (e) {
    next(e);
  }
};

export default login;
