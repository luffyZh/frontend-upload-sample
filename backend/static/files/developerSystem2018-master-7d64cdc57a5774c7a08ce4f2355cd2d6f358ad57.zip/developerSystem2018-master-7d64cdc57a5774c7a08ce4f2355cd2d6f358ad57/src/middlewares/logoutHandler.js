import { loginPage } from './links';
/* eslint no-param-reassign: 0 */
export default (req, res) => {
  const accept = (req.headers.accept || '').toLowerCase();
  if ('application/json' === accept) {
    res.status(200).send({
      errcode: 0,
      errmsg: '',
      resData: {
        redirect: loginPage
      }
    });
  } else {
    res.redirect(loginPage);
  }
};