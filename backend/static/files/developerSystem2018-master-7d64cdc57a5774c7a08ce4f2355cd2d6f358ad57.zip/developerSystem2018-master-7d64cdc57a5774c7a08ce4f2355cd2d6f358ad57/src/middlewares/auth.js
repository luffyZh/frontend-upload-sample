/* ensure api request login and has referrer */
import ensureReferer from '../core/refererMatch';
import { loginPage } from './links';
// import config from '../config';

/**
 * ensure server request login
 */
const server = (req, res, next) => {
  if (req.cookies && req.cookies.KFZTK && req.cookies.KFZID) {
    next();
  } else if (req.cookies && process.env.NODE_ENV !== 'production') {
    /* 方便开发，但是影响了测试 */
    // res.setHeader('Set-Cookie', [
    //   `KFZTK=${config.testUser.token}`,
    //   `KFZID=${config.testUser.developerId}`,
    //   `KFZEMAIL=${config.testUser.email}`
    // ]);
    // if (!req.cookies.KFZTK || !req.cookies.KFZID) {
    //   res.redirect(loginPage);
    // }
    next();
  } else {
    res.redirect(loginPage);
  }
};

const api = (req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const cookieAge = 1 * 60 * 60 * 1000;

  if (!req.cookies || !req.cookies.KFZTK || !req.cookies.KFZID) {
    if (req.cookies && process.env.NODE_ENV !== 'production') {
      /* 方便开发，但是影响测试 */
      // res.setHeader('Set-Cookie', [
      //   `KFZTK=${config.testUser.token}`,
      //   `KFZID=${config.testUser.developerId}`,
      //   `KFZEMAIL=${config.testUser.email}`
      // ]);
      return next();
    }
    res.status(403).send({
      errcode: 403,
      errmsg: '未登录或登录超时，请重新登录',
      data: {
        redirect: loginPage
      }
    });
  } else if (!ensureReferer(req)) {
    // prevent csrf
    res.status(403).send({
      errcode: 403,
      errmsg: 'Referer 错误，请确保浏览器使用的是非隐身模式浏览本站点。'
    });
  } else {
    if (!req.cookies.USERIP || req.cookies.USERIP !== ip) {
      res.setHeader(
        'Set-Cookie',
        [`USERIP=${ip}`],
        'Secure',
        `Max-Age=${cookieAge}`,
      );
    }
    next();
  }
  return true;
};

export default {
  server,
  api
};
