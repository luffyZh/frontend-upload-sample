import api from '../api/apiDefOfBE';
import http from '../core/HttpServer';
import { fetchUserInfo } from '../core/utils';

const downloadFile = async (req, res, next) => {
  try {
    const {
      _accessId: accessId,
      params: {
        slotUdid
      },
      query: {
        packageName
      }
    } = req;
    const user = fetchUserInfo(req);
    const ret = await http.get(api.downloadAdSlotAppPackage, {
      accessId,
      params: {
        ...user,
        slotUdid
      },
      timeout: 30000
    });
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': 'attachment; filename=' + encodeURIComponent(packageName)
    });
    ret.pipe(res);
  } catch (e) {
    next(e);
  }
};

export default downloadFile;
