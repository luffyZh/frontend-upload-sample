import {
  loginPage,
  indexPage
} from './links';
import api from '../api/apiDefOfBE';
import http from '../core/HttpServer';
import { isPositiveInteger } from '../core/utils';

const specialLogin = async (req, res, next) => {
  try {
    const {
      _accessId: accessId,
      query: {
        developerId,
        verify = ''
      }
    } = req;

    const validDeveloperId = isPositiveInteger(parseInt(developerId, 10));
    const validPw = verify.length === 32;

    if (!validDeveloperId || !validPw) {
      return res.redirect(loginPage);
    }
    // 登录接口
    const userInfo = await http.post(api.specialLogin, {
      accessId,
      params: {
        developerId: parseInt(developerId, 10)
      },
      query: {
        verify
      }
    });
    console.log(userInfo);
    const cookieAge = 1 * 60 * 60 * 1000;
    res.setHeader('Set-Cookie',
      [
        `KFZTK=${userInfo.authorization}`,
        `KFZID=${Number(developerId)}`,
        `KFZEMAIL=${userInfo.username}`,
        `PERMISSION_LIST=${userInfo.permissions && userInfo.permissions.join(',')}`
      ],
      'Secure',
      `Max-Age=${cookieAge}`
    );

    const currentUser = {
      developerId: Number(developerId),
      email: userInfo.username || '邮箱未设置',
      pw: verify,
      token: userInfo.authorization
    };

    console.log('special login', currentUser);
    res.redirect(indexPage);
  } catch (e) {
    next(e);
  }
};

export default specialLogin;
