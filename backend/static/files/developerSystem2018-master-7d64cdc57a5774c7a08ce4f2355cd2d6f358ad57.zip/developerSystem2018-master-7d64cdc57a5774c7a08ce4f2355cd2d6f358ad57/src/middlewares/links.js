// 开发者系统未登录首页地址
export const loginPage = 'http://zhixuan.youdao.com/dsp/website/developer.shtml';

// 开发者系统首页
// export const indexPage = '/developer/home';
export const indexPage = '/developer/appManagement/app';
