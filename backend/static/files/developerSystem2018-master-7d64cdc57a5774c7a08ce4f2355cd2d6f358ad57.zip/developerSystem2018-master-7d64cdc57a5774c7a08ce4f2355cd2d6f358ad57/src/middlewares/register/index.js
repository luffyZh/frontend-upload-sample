import { Router } from 'express';
import { notFoundRes } from '../../api/helper';
import api from '../../api/apiDefOfBE';
import http from '../../core/HttpServer';
import NodeError from '../../core/fetch/node-error';

const router = new Router();

// 提交注册信息
router.post('/postRegisterInfo', async (req, res) => {
  try {
    const {
      _accessId: accessId,
      params,
      body
    } = req;
    const ret = await http.post(api.postRegisterInfo, {
      accessId,
      params,
      timeout: 15000,
      data: JSON.stringify(body)
    });
    res.json({
      error_code: 0,
      error_message: '',
      data: ret
    });
  } catch (e) {
    const errResData = {
      error_code: e.code,
      error_message: e.message,
      data: {}
    };
    res.json(errResData);
  }
});
// 激活账户信息
router.get('/getActivation', async (req, res) => {
  try {
    const {
      _accessId: accessId,
      params,
      query: {
        validateCode
      }
    } = req;
    const ret = await http.get(api.getActivation, {
      accessId,
      params,
      timeout: 15000,
      query: {
        validateCode
      }
    });
    res.json({
      error_code: 0,
      error_message: '',
      data: ret
    });
  } catch (e) {
    const errResData = {
      error_code: e.code,
      error_message: e.message,
      data: e.data
    };
    res.json(errResData);
  }
});
// 激活账户信息
router.get('/getActiveEmail', async (req, res) => {
  try {
    const {
      _accessId: accessId,
      params,
      query: {
        userName
      }
    } = req;
    const ret = await http.post(api.getActiveEmail, {
      accessId,
      params,
      timeout: 15000,
      query: {
        userName
      }
    });
    res.json({
      error_code: 0,
      error_message: '',
      data: ret
    });
  } catch (e) {
    const errResData = {
      error_code: e.code,
      error_message: e.message,
      data: {}
    };
    res.json(errResData);
  }
});
router.use('*', (req, res, next) => {
  const { errmsg, errcode } = notFoundRes.content;
  next(new NodeError(errmsg, 'RequestError', 'not-found', 'frontend', errcode));
});

export default router;
