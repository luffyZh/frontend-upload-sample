const errorHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Error Page</title>
  <style>
    * {
      margin: 0;
      padding: 0
    }
    html,body {
      position: absolute;
      width: 100%;
      height: 100%;
    }
    button {
      cursor: pointer;
    }
    .container {
      display: flex;
      flex-direction: column;
      height: 100%;
      justify-content: center;
      align-items: center
    }
    .error-img {
      width: 200px;
      height: 200px;
    }
    .text-container {
      display: flex;
      flex-direction: column;
      margin: 20px 0;
      max-width: 600px;
    }
    .button-container {
      margin: 20px 0;
      display: flex;
      justify-content: space-around;
    }
    .ant-btn::before {
      position: absolute;
      top: -1px;
      left: -1px;
      bottom: -1px;
      right: -1px;
      background: #fff;
      opacity: 0.35;
      content: '';
      border-radius: inherit;
      z-index: 1;
      -webkit-transition: opacity .2s;
      transition: opacity .2s;
      pointer-events: none;
      display: none;
    }
    .ant-btn {
      padding: 10px 20px;
      background: #1090ff;
      color: #fff;
      border-radius: 4px; 
      border: none;
    }
    .ant-btn:hover {
      color: #fff;
      background-color: #40a9ff;
      border-color: #40a9ff;
    }
    .ant-btn-default {
      padding: 10px 20px;
      background: #dd4142;
      color: #fff;
      border-radius: 4px; 
      border: none;
    }
    .ant-btn-default:hover {
      color: #fff;
      background-color: #D15A37;
      border-color: #D15A37;
    }
  </style>
</head>
<body>
  <div class="container">
    <img class="error-img" src="https://shared.ydstatic.com/dsp_website/NewZhiXuan/empty.png">
    <div class="text-container">
      你访问的页面出现了问题，程序员正在加紧修复，请您稍后刷新重试～
      <div class="button-container">
        <button onclick="history.go(-1)" class="ant-btn">返回上一页</button>
        <button class="ant-btn-default" onclick="location.href='https://zhixuan.youdao.com/'">重新登录</button>
      </div>
    </div>
  </div>
</body>
</html>`;

export default errorHtml;
