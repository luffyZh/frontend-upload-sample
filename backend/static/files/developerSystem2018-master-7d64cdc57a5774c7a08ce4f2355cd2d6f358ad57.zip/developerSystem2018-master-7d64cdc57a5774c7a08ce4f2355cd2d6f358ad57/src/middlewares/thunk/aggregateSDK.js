import { message } from 'antd';
import {
  ADD_SLOT_LIST_SUCCESS,
  EDIT_SLOT_NAME_SUCCESS,
  ADD_SLOT_LIST_FAIL,
  EDIT_SLOT_NAME_FAIL,
  ADD_PLATFORM_PRIORITY_SUCCESS,
  ADD_PLATFORM_PRIORITY_FAIL,
  EDIT_PLATFORM_PRIORITY_SUCCESS,
  EDIT_PLATFORM_PRIORITY_FAIL,
  DELETE_PLATFORM_PRIORITY_SUCCESS,
  GET_PRIORITY_LIST_SUCCESS,
  CHANGE_EDITMODAL_VALUE_SUCCESS,
  EDIT_PRIORITY_CONFIG_SUCCESS,
  ADD_PRIORITY_CONFIG_SUCCESS,
  EDIT_PRIORITY_CONFIG_FAIL,
  ADD_PRIORITY_CONFIG_FAIL
} from '../../constants/ActionTypes';
import {
  getPlatformList,
  getCountryList,
  getLanguageList,
  getOptionList
} from '../../actions/AggregateSDK';
import history from '../../history';

message.config({
  top: 130
});

export default ({ getState, dispatch }) => next => action => {
  const ret = next(action);
  switch (action.type) {
    case ADD_SLOT_LIST_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('广告位名称重复');
      } else {
        message.error('新建广告位失败，请稍后重试');
      }
      break;
    }
    case ADD_SLOT_LIST_SUCCESS: {
      const { mediationSdkSlotUid } = action.payload;
      message.success('新增广告位成功！');
      history.push(`/developer/aggregateSDK/adManagement/${mediationSdkSlotUid}`);
      break;
    }
    case EDIT_SLOT_NAME_SUCCESS: {
      message.success('编辑广告位成功！');
      break;
    }
    case EDIT_SLOT_NAME_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('广告位名称重复');
      } else {
        message.error('编辑广告位失败，请稍后重试');
      }
      break;
    }
    case CHANGE_EDITMODAL_VALUE_SUCCESS: {
      dispatch(getOptionList(getState().aggregateSDK.editPriority.priority.optionType));
      break;
    } 
    case GET_PRIORITY_LIST_SUCCESS: {
      const { priorityList } = getState().aggregateSDK.editPriority.priority;
      priorityList.sysLanguageSettingMode === 1 ? dispatch(getLanguageList()) : '';
      priorityList.countrySettingMode === 1 ? dispatch(getCountryList()) : '';
      priorityList.osVersionSettingMode === 1 ? dispatch(getOptionList(1)) : '';
      priorityList.appVersionSettingMode === 1 ? dispatch(getOptionList(2)) : '';
      priorityList.channelNoSettingMode === 1 ? dispatch(getOptionList(3)) : '';
      break;
    }
    case ADD_PLATFORM_PRIORITY_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('平台优先级配置名称重复');
      } else {
        message.error('新建平台优先级配置失败，请稍后重试');
      }
      break;
    }
    case ADD_PLATFORM_PRIORITY_SUCCESS: {
      const { mediationSdkSlotUid } = getState().aggregateSDK.editPriority.priorityConfig;
      message.success('新增平台优先级配置成功！');
      dispatch(getPlatformList(mediationSdkSlotUid));
      break;
    }
    case EDIT_PLATFORM_PRIORITY_SUCCESS: {
      message.success('编辑平台优先级配置成功！');
      break;
    }
    case DELETE_PLATFORM_PRIORITY_SUCCESS: {
      message.success('删除平台优先级配置成功！');
      break;
    }
    case EDIT_PLATFORM_PRIORITY_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('平台优先级配置名称重复');
      } else {
        message.error('编辑平台优先级配置失败，请稍后重试');
      }
      break;
    }
    case ADD_PRIORITY_CONFIG_SUCCESS: {
      message.success('已保存');
      history.push(`/developer/aggregateSDK/adManagement/${action.infoObj}`);
      break;
    }
    case EDIT_PRIORITY_CONFIG_SUCCESS: {
      const { mediationSdkSlotUid } = getState().aggregateSDK.editPriority.priority;
      message.success('已保存');
      history.push(`/developer/aggregateSDK/adManagement/${mediationSdkSlotUid}`);
      break;
    }
    case ADD_PRIORITY_CONFIG_FAIL: 
    case EDIT_PRIORITY_CONFIG_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('优先级配置名称重复');
      } else {
        message.error('保存失败！');
      }
      break;
    }
    default:
      break;
  }
  return ret;
};
