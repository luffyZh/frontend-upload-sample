import React from 'react';
import { message, Modal, Checkbox } from 'antd';
import {
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  SAVE_SELF_TEST,
  CREATE_TO_AUDIT_SUCCESS,
  CREATE_TO_AUDIT_FAIL,
  GO_TO_APP_LIST,
  GET_ADSLOT_INFO_FAIL,
  UPDATE_ADPOS_STATUS_SUCCESS,
  UPDATE_APP_STATUS_SUCCESS,
  GENERATE_SELF_TEST_MATERIAL_FAIL
} from '../../constants/ActionTypes';
import {
  adPosDataChange,
  selfTestDataChange,
  editAdPos,
  editSelfTest,
  editToAudit,
  toAuditDataChange
} from '../../actions/AppManagement/new';
import { getAppEntityListPath } from '../../core/utils';
import history from '../../history';

const { info } = Modal;

const checkBoxStyle = {
  position: 'absolute',
  right: '120px',
  bottom: '28px'
};

const timeout = 32;

export default ({ getState }) => next => action => {
  const ret = next(action);
  switch (action.type) {
    case CREATE_APP_SUCCESS: {
      const { saveType } = action;
      if (saveType) {
        setTimeout(() => {
          // 点击保存按钮的跳转
          history.push(getAppEntityListPath('app'));
        }, timeout);
      } else {
        next(adPosDataChange('appTag', 'appTag', true));
        next(editAdPos());
      }
      break;
    }
    case CREATE_APP_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('应用名称重复');
      } else {
        message.error('新建应用失败，请稍后重试');
      }
      break;
    }
    case CREATE_AD_POS_SUCCESS: {
      const { saveType } = action;
      if (saveType) {
        const { appId, adPosId, appName } = getState().appManagement.entity.adPos.adPosInfo;
        const neverHint = window.localStorage.getItem('developer_never_hint');
        if (neverHint) {
          history.push(getAppEntityListPath('adPos', appId));
        }
        !neverHint && info({
          title: '恭喜您已成功创建广告位及样式，请在集成与自测页面添加自测设备和获取自测物料:',
          width: 600,
          content: (
            <div>
              <p>1. 请使用该广告位ID进行接入:  <strong>{adPosId}</strong></p>
              <p>2. 接入完成之后，进入集成与自测阶段，SDK与API接入需要添加自测设备的设备号，JSSDK对接则无需再添加设备号</p>
              <p>3. 在集成与自测页面点击保存(或保存并继续)之后，等待15分钟左右，即可请求到自测广告，如有疑问，请参考 帮助中心-自测 查看详细指导</p>
              <div style={checkBoxStyle}>
                <Checkbox
                  onChange={
                    ({ target: { checked } }) => {
                      if (checked) {
                        window.localStorage.setItem('developer_never_hint', 'true');
                      }
                    }
                  }
                >不再提示</Checkbox>
              </div>
            </div>
          ),
          okText: '已了解',
          onOk() {
            // 点击保存按钮的跳转
            history.push(getAppEntityListPath('adPos', appId, appName));
          }
        });
      } else {
        const { adPosId } = getState().appManagement.entity.adPos.adPosInfo;
        const neverHint = window.localStorage.getItem('developer_never_hint');
        if (neverHint) {
          next(selfTestDataChange('appTag', 'appTag', true));
          next(selfTestDataChange('adPosTag', 'adPosTag', true));
          next(editSelfTest());
        }
        !neverHint && info({
          title: '恭喜您已成功创建广告位及样式，请在集成与自测页面添加自测设备和获取自测物料:',
          width: 600,
          content: (
            <div>
              <p>1. 请使用该广告位ID进行接入:  <strong>{adPosId}</strong></p>
              <p>2. 接入完成之后，进入集成与自测阶段，SDK与API接入需要添加自测设备的设备号，JSSDK对接则无需再添加设备号</p>
              <p>3. 在集成与自测页面点击保存(或保存并继续)之后，等待15分钟左右，即可请求到自测广告，如有疑问，请参考 帮助中心-自测 查看详细指导</p>
              <div style={checkBoxStyle}>
                <Checkbox
                  onChange={
                    ({ target: { checked } }) => {
                      if (checked) {
                        window.localStorage.setItem('developer_never_hint', 'true');
                      }
                    }
                  }
                >不再提示</Checkbox>
              </div>
            </div>
          ),
          okText: '已了解',
          onOk() {
            next(selfTestDataChange('appTag', 'appTag', true));
            next(selfTestDataChange('adPosTag', 'adPosTag', true));
            next(editSelfTest());
          }
        });
      }
      break;
    }
    case CREATE_AD_POS_FAIL: {
      const { error } = action;
      if (error.code === 409) {
        message.error('广告位名称重复');
        next(adPosDataChange('adPosSetting', 'nameConflict', true));
      } else {
        message.error('新建广告位失败，请稍后重试');
        setTimeout(() => {
          const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
          // 点击保存按钮的跳转
          history.push(getAppEntityListPath('adPos', appId, appName));
        }, 800);
      }
      break;
    }
    case SAVE_SELF_TEST: {
      const { saveType } = action;
      if (!saveType) {
        setTimeout(() => {
          next(toAuditDataChange('appTag', 'appTag', true));
          next(toAuditDataChange('adPosTag', 'adPosTag', true));
          next(toAuditDataChange('selfTestTag', 'selfTestTag', true));
          next(editToAudit());
        }, timeout);
      } else {
        setTimeout(() => {
          const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
          // 点击保存按钮的跳转
          history.push(getAppEntityListPath('adPos', appId, appName));
        }, timeout);
      }
      break;
    }
    case CREATE_TO_AUDIT_SUCCESS: {
      const { payload } = action;
      const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
      !payload.success ? message.error('提交审核失败') : message.success('提交审核成功');
      setTimeout(() => {
        // 成功后的跳转
        history.push(getAppEntityListPath('adPos', appId, appName));
      }, timeout);
      break;
    }
    case CREATE_TO_AUDIT_FAIL: {
      const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
      message.error('提交审核失败');
      setTimeout(() => {
        // 成功后的跳转
        history.push(getAppEntityListPath('adPos', appId, appName));
      }, timeout);
      break;
    }
    case GO_TO_APP_LIST: {
      const { tabType, appId } = action.payload;
      const { appName } = getState().appManagement.entity.adPos.adPosInfo;
      history.push(getAppEntityListPath(tabType, appId, appName));
      break;
    }
    case GET_ADSLOT_INFO_FAIL: {
      const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
      message.error('广告位获取失败，请稍后重试');
      history.push(getAppEntityListPath('adPos', appId, appName));
      break;
    }
    case UPDATE_ADPOS_STATUS_SUCCESS: {
      const { params, currentUrlPath } = action;
      const { status } = params;
      if (status === 'delete') {
        history.push(currentUrlPath);
      }
      break;
    }
    case UPDATE_APP_STATUS_SUCCESS: {
      const { params, currentUrlPath } = action;
      const { status } = params;
      if (status === 'delete') {
        history.push(currentUrlPath);
      }
      break;
    }
    case GENERATE_SELF_TEST_MATERIAL_FAIL: {
      message.error('生成自测物料失败，请稍后重试！');
      setTimeout(() => {
        const { appId, appName } = getState().appManagement.entity.adPos.adPosInfo;
        // 成功后的跳转
        history.push(getAppEntityListPath('adPos', appId, appName));
      }, timeout);
      break;
    }
    default:
  }
  return ret;
};
