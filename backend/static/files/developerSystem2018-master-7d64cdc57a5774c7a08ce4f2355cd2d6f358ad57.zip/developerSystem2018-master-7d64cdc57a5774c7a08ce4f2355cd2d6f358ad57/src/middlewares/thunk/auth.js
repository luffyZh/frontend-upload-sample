import { message } from 'antd';
import Cookies from 'js-cookie';
import {
  GO_TO_LOGIN_PAGE,
  LOGOUT_SUCCESS
} from '../../constants/ActionTypes';
import {
  removeCookies
} from '../../core/utils';

let hasRedirect = false;

export default () => next => action => {
  switch (action.type) {
    case LOGOUT_SUCCESS:
      removeCookies(Cookies, ['KFZTK', 'KFZID', 'KFZEMAIL']);
      message.success('您已安全登出当前帐号，即将跳转 ...', 1, () => {
        window.location.href = action.payload.redirect;
      });
      break;
    case GO_TO_LOGIN_PAGE: {
      console.log(action.payload);
      const { errorMessage, redirect } = action.payload;

      if (!hasRedirect) {
        hasRedirect = true;
        message.error(errorMessage, 1, () => {
          window.location.href = redirect;
        });
      }
      break;
    }
    default:
      return next(action);
  }
};
