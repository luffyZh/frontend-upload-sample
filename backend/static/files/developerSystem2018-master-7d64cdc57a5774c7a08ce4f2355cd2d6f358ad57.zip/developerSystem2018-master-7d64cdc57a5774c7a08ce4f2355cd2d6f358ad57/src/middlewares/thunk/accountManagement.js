import { message } from 'antd';
import {
  CHANGE_SELF_TEST_DEVICE_STATUS_FAIL,
  ADD_SELF_TEST_DEVICE_FAIL,
  ADD_SELF_TEST_DEVICE_SUCCESS,
  UPDATE_ACCOUNT_INFO_SUCCESS,
  UPDATE_ACCOUNT_INFO_FAIL,
  UPDATE_SELF_TEST_DEVICE_INFO_SUCCESS,
  UPDATE_SELF_TEST_DEVICE_INFO_FAIL
} from '../../constants/ActionTypes';
import history from '../../history';

export default () => next => action => {
  const ret = next(action);
  switch (action.type) {
    case CHANGE_SELF_TEST_DEVICE_STATUS_FAIL: {
      const { devicesObj: { status } } = action;
      status === 2
        ? message.error('删除设备失败，请稍后重试！')
        : message.error('设备状态更新失败，请稍后重试！');
      break;
    }
    case ADD_SELF_TEST_DEVICE_FAIL: {
      message.error('设备添加失败，请稍后重试！');
      break;
    }
    case ADD_SELF_TEST_DEVICE_SUCCESS: {
      message.success('设备添加成功！');
      break;
    }
    case UPDATE_ACCOUNT_INFO_SUCCESS: {
      message.success('账户信息更新成功！');
      break;
    }
    case UPDATE_ACCOUNT_INFO_FAIL: {
      message.error('账户信息更新失败，请稍后重试！');
      setTimeout(() => history.push('/developer/accountManagement/accountInfo'), 500);
      break;
    }
    case UPDATE_SELF_TEST_DEVICE_INFO_SUCCESS: {
      message.success('设备信息更新成功！');
      break;
    }
    case UPDATE_SELF_TEST_DEVICE_INFO_FAIL: {
      message.error('设备信息更新失败，请稍后重试!');
      setTimeout(() => history.push('/developer/accountManagement/deviceInfo'), 500);
      break;
    }
    default:
      break;
  }
  return ret;
};
