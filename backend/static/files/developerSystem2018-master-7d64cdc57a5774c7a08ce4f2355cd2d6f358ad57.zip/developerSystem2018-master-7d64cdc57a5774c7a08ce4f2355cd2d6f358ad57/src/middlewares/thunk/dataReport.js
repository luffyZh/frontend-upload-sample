// import _ from 'lodash';
import {
  DOWNLOAD_DATA_REPORT_DATA
} from '../../constants/ActionTypes';
import { generateDataReportDownloadUrl } from '../../core/utils';
import { download } from '../../DOMUtils';

export default () => next => action => {
  const ret = next(action);
  switch (action.type) {
    case DOWNLOAD_DATA_REPORT_DATA: {
      const { payload } = action;
      const reqUrl = generateDataReportDownloadUrl(payload);
      download(reqUrl);
      break;
    }
    default:
      break;
  }
  return ret;
};
