/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import Link from '../Link';
import { systemWhiteFuncs } from '../../constants/MenuTypes';
import s from './Navigation.less';

const tabs = [
  // {
  //   key: 'home'
  //   name: '首页',
  //   path: '/developer/home'
  // },
  {
    key: 'appManagement',
    name: '应用管理',
    path: '/developer/appManagement'
  },
  {
    key: 'dataReport',
    name: '数据报表',
    path: '/developer/dataReport'
  },
  {
    key: 'helpCenter',
    name: '帮助中心',
    path: '/developer/helpCenter'
  },
  {
    key: 'accountManagement',
    name: '账户管理',
    path: '/developer/accountManagement'
  },
  {
    key: 'meditationSdk',
    name:'智选聚合SDK',
    path:'/developer/aggregateSDK'
  }
];

function Navigation({ path, permissionList }) {
  return (
    <section className={`${s.root} root`} role="navigation">
      <div className={s.container}>
        <div className={s.tabs}>
          {tabs.map(tab => (
            <IfComp
              key={tab.path}
              expression={!systemWhiteFuncs.includes(tab.key)}
              trueComp={
                <Link
                  className={
                    path.startsWith(tab.path) ? `${s.tab} ${s.active}` : s.tab
                  }
                  to={tab.path}
                >
                  {tab.name}
                </Link>
              }
              falseComp={
                <Link
                  className={
                    path.startsWith(tab.path) ? `${s.tab} ${s.active}` : s.tab
                  }
                  to={tab.path}
                  style={{
                    display: !permissionList.split(',').includes(tab.key)
                      ? 'none'
                      : 'flex'
                  }}
                >
                  {tab.name}
                </Link>
              }
            />
          ))}
        </div>
      </div>
    </section>
  );
}

Navigation.propTypes = {
  path: PropTypes.string.isRequired,
  permissionList: PropTypes.string.isRequired
};

export default withStyles(s)(Navigation);
