import React, { Component } from 'react';
import PropTypes from 'prop-types';
import history from '../../history';

function isLeftClickEvent(event) {
  return event.button === 0;
}

function isModifiedEvent(event) {
  return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
}

class Link extends Component {
  static propTypes = {
    to: PropTypes.string.isRequired,
    children: PropTypes.node.isRequired,
    onClick: PropTypes.func,
    target: PropTypes.string
  };

  static defaultProps = {
    onClick: null,
    target: '_self'
  };

  handleClick = event => {
    if (this.props.onClick) {
      this.props.onClick(event);
    }

    if (isModifiedEvent(event) || !isLeftClickEvent(event)) {
      return;
    }

    if (event.defaultPrevented === true) {
      return;
    }
    event.preventDefault();
    // 改造Link增加新标签页打开功能
    this.props.target === '_blank'
      ? window.open(this.props.to, this.props.target)
      : history.push(this.props.to);
  };

  render() {
    const { to, children, target, ...props } = this.props;
    return (
      <a target={target} href={to} {...props} onClick={this.handleClick}>
        {children}
      </a>
    );
  }
}

export default Link;
