import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import Link from '../../Link';
import s from './index.less';

class SelectionBar extends Component {
  static propTypes = {
    selectedItem: PropTypes.string.isRequired,
    itemList: PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        link: PropTypes.string.isRequired
      }),
    ).isRequired
  };

  render() {
    return (
      <div className={s.barContainer}>
        {this.props.itemList.map(item => (
          <Link to={item.link} key={item.title}>
            <div
              className={cx({
                [s.itemStyle]: true,
                [s.itemActive]: this.props.selectedItem === item.name
              })}
            >
              {item.title}
            </div>
          </Link>
        ))}
      </div>
    );
  }
}

export default withStyles(s)(SelectionBar);
