import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import IfComp from 'if-comp';
import { Menu, Spin, Icon } from 'antd';
import {
  OperationStatus
} from '../../../constants/MenuTypes';
import {
  classnames,
  componentUpdateByState
} from '../../../core/utils';
import s from './index.less';

const {
  SubMenu,
  Item: MenuItem
} = Menu;

const originMenuShape = PropTypes.shape({
  status: PropTypes.oneOf(Object.keys(OperationStatus)).isRequired,
  list: PropTypes.arrayOf(PropTypes.shape({
    sortKey: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    id: PropTypes.any.isRequired,
    name: PropTypes.string.isRequired,
    value: PropTypes.any,
    children: PropTypes.array.isRequired
  })).isRequired
});

const insertMenu = (selectedMenuList, menu, sort = 'asc') => {
  const pos = selectedMenuList.findIndex(p => (sort === 'asc' ? p.sortKey > menu.sortKey : p.sortKey < menu.sortKey));
  if (pos === -1) {
    selectedMenuList.push(menu);
  } else {
    selectedMenuList.splice(pos, 0, menu);
  }
};

const defaultMenuTextFormatter = t => t.name;

const getActionBarMarginHeight = style => {
  switch (typeof style.margin) {
    case 'number':
      return style.margin * 2;
    case 'string': {
      const mArr = style.margin.split(/\s+/);
      if (mArr.length === 1 || mArr.length === 2) {
        const m = parseInt(mArr[0], 10);
        if (!isNaN(m)) {
          return m * 2;
        }
      }
      if (mArr.length === 3 || mArr.length === 4) {
        const m1 = parseInt(mArr[0], 10);
        const m2 = parseInt(mArr[2], 10);
        if (!isNaN(m1) && !isNaN(m2)) {
          return m1 + m2;
        }
      }
      // eslint-disable-next-line no-console
      console.error('无效的 actionBar style', style);
      return 0;
    }
    case 'undefined': {
      const mb = style.marginBottom ? parseInt(style.marginBottom, 10) : 0;
      const mt = style.marginTop ? parseInt(style.marginTop, 10) : 0;
      return mt + mb;
    }
    default:
      // eslint-disable-next-line no-console
      console.error('无效的 actionBar style', style);
      return 0;
  }
};

const parseInfiniteLoadProps = infiniteLoadConfig => {
  const props = {};
  const invalidError = new Error('infiniteLoadConfig 参数格式错误!');

  if (typeof infiniteLoadConfig !== 'object') {
    throw invalidError;
  }
  const {
    threshold,
    fetchOriginMenuList
  } = infiniteLoadConfig;
  if (typeof threshold === 'number') {
    props.threshold = {
      type: 'number',
      value: threshold
    };
  } else if (typeof threshold === 'string' && threshold.endsWith('%')) {
    const n = Number(threshold.slice(0, -1));
    if (Number.isNaN(n)) {
      throw invalidError;
    }
    props.threshold = {
      type: 'percentage',
      value: n
    };
  } else {
    throw invalidError;
  }
  props.fetchOriginMenuList = fetchOriginMenuList;
  return props;
};

/* eslint-disable react/no-unused-prop-types */
class CascadingMenuPicker4 extends Component {
  static propTypes = {
    originHeader: PropTypes.oneOfType([PropTypes.element, PropTypes.string]).isRequired,
    selectedHeader: PropTypes.oneOfType([PropTypes.element, PropTypes.string]).isRequired,
    originMenu: originMenuShape.isRequired,
    infiniteLoadOriginMenu: PropTypes.bool,
    allResultSelected: PropTypes.oneOfType([PropTypes.element, PropTypes.string]),
    infiniteLoadConfig: PropTypes.shape({
      threshold: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string
      ]),
      fetchOriginMenuList: PropTypes.func
    }),
    selectedMenuList: PropTypes.array.isRequired,
    originMenuListOpenKeys: PropTypes.array.isRequired,
    selectedMenuListOpenKeys: PropTypes.array.isRequired,
    actionBar: PropTypes.element,
    selectedMenuListSort: PropTypes.oneOf(['asc', 'desc']),
    style: PropTypes.shape({
      originMenuWidth: PropTypes.number.isRequired,
      selectedMenuWidth: PropTypes.number.isRequired,
      totalHeight: PropTypes.number.isRequired
    }).isRequired,
    originMenuTextFormatter: PropTypes.func,
    originSubMenuTextFormatter: PropTypes.func,
    onSelectedMenuListChange: PropTypes.func,
    onOriginMenuListOpenKeysChange: PropTypes.func.isRequired,
    onSelectedMenuListOpenKeysChange: PropTypes.func.isRequired,
    onSelectedAllMenuListChange: PropTypes.func
  };

  static defaultProps = {
    actionBar: null,
    infiniteLoadOriginMenu: false,
    infiniteLoadConfig: null,
    selectedMenuListSort: 'asc',
    originMenuTextFormatter: defaultMenuTextFormatter,
    originSubMenuTextFormatter: defaultMenuTextFormatter,
    onSelectedMenuListChange: () => {},
    allResultSelected: null,
    onSelectedAllMenuListChange: null
  };

  constructor(props) {
    super(props);

    this.infiniteLoad = props.infiniteLoadOriginMenu
      ? parseInfiniteLoadProps(props.infiniteLoadConfig)
      : null;
    const stateKeys = [
      'originHeader',
      'selectedHeader',
      'originMenu',
      'selectedMenuList',
      'originMenuListOpenKeys',
      'selectedMenuListOpenKeys'
    ];
    this.state = {};
    stateKeys.forEach(key => {
      this.state[key] = props[key];
    });
    this.state = {
      ...this.state,
      isAll: true
    };
    // this.componentWillReceiveProps = updateComponentStateByKeys(stateKeys);
    this.shouldComponentUpdate = componentUpdateByState;
  }

  componentWillReceiveProps(nextProps) {
    // 首次加载或者搜索值为空时，‘全选’字样显示为已选择，也就是为灰色
    if (nextProps.originMenu.list.length === 0) {
      this.setState({
        isAll: true
      });
    } else if (JSON.stringify(this.state.originMenu.list) !== JSON.stringify(nextProps.originMenu.list)) {
      // 当关键词输入后，原列表刷新，‘全选’字样是否显示灰色
      nextProps.originMenu.list.forEach(item => {
        if (JSON.stringify(this.state.selectedMenuList).indexOf(JSON.stringify(item)) === -1) {
          this.setState({
            isAll: false
          }, () => (true));
        }
      });
    }
    this.setState({
      originMenu: nextProps.originMenu,
      selectedMenuList: nextProps.selectedMenuList,
      originMenuListOpenKeys: nextProps.originMenuListOpenKeys,
      selectedMenuListOpenKeys: nextProps.selectedMenuListOpenKeys
    });
  }

  onMenuListOpenChange = originMenuListOpenKeys => {
    this.setState({
      originMenuListOpenKeys
    }, () => {
      this.props.onOriginMenuListOpenKeysChange(originMenuListOpenKeys);
    });
  }

  onSelectedMenuListOpenChange = selectedMenuListOpenKeys => {
    this.setState({
      selectedMenuListOpenKeys
    }, () => {
      this.props.onSelectedMenuListOpenKeysChange(selectedMenuListOpenKeys);
    });
  }

  // 全选列表中所有Menu
  onSelectAllMenu = menu => {
    this.setState({
      isAll: true
    }, () => {
      const { selectedMenuList } = this.state;
      const originMenuList = menu.list;
      const nextSelectedMenuList = [...selectedMenuList];
      let deNextSelectedMenuList = [];
      nextSelectedMenuList.forEach(item => {
        if (JSON.stringify(originMenuList).indexOf(JSON.stringify(item)) === -1) {
          deNextSelectedMenuList = [...deNextSelectedMenuList, item];
        }
      });
      this.setState({
        selectedMenuList: deNextSelectedMenuList.concat(originMenuList)
      }, () => {
        this.props.onSelectedAllMenuListChange(this.state.selectedMenuList);
      });
    });
  }

  // 选择某个 Menu，即相当于全选其下的全部 subMenu
  onSelectMenu = menu => {
    const { selectedMenuList, originMenu } = this.state;
    const findSelectedMenu = selectedMenuList.find(m => m.id === menu.id);
    if (findSelectedMenu && findSelectedMenu.children.length === menu.children) return;

    const nextSelectedMenuList = [...selectedMenuList];
    const selectedMenu = {
      ...menu,
      children: [
        ...menu.children
      ]
    };
    if (findSelectedMenu) {
      nextSelectedMenuList.splice(nextSelectedMenuList.indexOf(findSelectedMenu), 1, selectedMenu);
    } else {
      insertMenu(nextSelectedMenuList, selectedMenu, this.props.selectedMenuListSort);
    }

    this.setState({
      selectedMenuList: nextSelectedMenuList
    }, () => {
      if (originMenu.list.every(item => JSON.stringify(selectedMenuList).indexOf(JSON.stringify(item)) !== -1)) {
        this.setState({
          isAll: true
        });
      } else {
        this.setState({
          isAll: false
        });
      }
      this.props.onSelectedMenuListChange(nextSelectedMenuList);
    });
  }

  // 选择某个 subMenu
  onSelectSubMenu = ({ keyPath }) => {
    const { selectedMenuListSort } = this.props;
    const {
      selectedMenuList,
      originMenu,
      selectedMenuListOpenKeys
    } = this.state;
    const menuValue = keyPath[1];
    const subMenuValue = keyPath[0];
    const findOriginMenu = originMenu.list.find(m => m.value === menuValue);
    const nextSelectedMenuList = [...selectedMenuList];
    if (findOriginMenu) {
      const selectedMenuIndex = nextSelectedMenuList.findIndex(m => m.value === menuValue);
      let findSelectedMenu;
      if (selectedMenuIndex < 0) {
        findSelectedMenu = {
          ...findOriginMenu,
          children: []
        };
        insertMenu(nextSelectedMenuList, findSelectedMenu, selectedMenuListSort);
      } else {
        findSelectedMenu = {
          ...nextSelectedMenuList[selectedMenuIndex]
        };
        findSelectedMenu.children = [
          ...findSelectedMenu.children
        ];
        nextSelectedMenuList[selectedMenuIndex] = findSelectedMenu;
      }
      const subMenu = findOriginMenu.children.find(sm => `${sm.id}` === subMenuValue);
      if (subMenu && findSelectedMenu.children.every(sm => sm.id !== subMenu.id)) {
        insertMenu(findSelectedMenu.children, subMenu, selectedMenuListSort);
        if (!selectedMenuListOpenKeys.includes(menuValue)) {
          selectedMenuListOpenKeys.push(menuValue);
        }
        this.setState({
          selectedMenuList: nextSelectedMenuList
        }, () => {
          this.props.onSelectedMenuListChange(nextSelectedMenuList);
        });
      }
    }
  }

  // 删除全部 Menu
  onDeselectAllMenu = () => {
    const selectedMenuList = [];
    const selectedMenuListOpenKeys = [];
    this.setState({
      selectedMenuList,
      selectedMenuListOpenKeys,
      isAll: false
    }, () => {
      this.props.onSelectedMenuListOpenKeysChange(selectedMenuListOpenKeys);
      this.props.onSelectedMenuListChange(selectedMenuList);
    });
  }

  // 选择全部 Menu
  onChooseAllMenu = () => {
    const selectedMenuList = this.state.originMenu.list.slice(0);
    const selectedMenuListOpenKeys = [];
    this.setState({
      selectedMenuList,
      selectedMenuListOpenKeys,
      isAll: true
    }, () => {
      this.props.onSelectedMenuListOpenKeysChange(selectedMenuListOpenKeys);
      this.props.onSelectedMenuListChange(selectedMenuList);
    });
  }

  // 删除一项 Menu
  onDeselectMenu = menu => {
    const { selectedMenuList, selectedMenuListOpenKeys } = this.state;
    const findMenuIndex = selectedMenuList.findIndex(m => m.value === menu.value);
    if (findMenuIndex >= 0) {
      const nextselectedMenuList = [...selectedMenuList];
      nextselectedMenuList.splice(findMenuIndex, 1);
      const nextState = {
        selectedMenuList: nextselectedMenuList
      };
      const selectedMenuOpenKeyIndex = selectedMenuListOpenKeys.findIndex(v => v === menu.value);
      if (selectedMenuOpenKeyIndex >= 0) {
        selectedMenuListOpenKeys.splice(selectedMenuOpenKeyIndex, 1);
        nextState.selectedMenuListOpenKeys = [...selectedMenuListOpenKeys];
      }
      this.setState(nextState, () => {
        this.setState({
          isAll: false
        });
        if (nextState.selectedMenuListOpenKeys) {
          this.props.onSelectedMenuListOpenKeysChange(nextState.selectedMenuListOpenKeys);
        }
        this.props.onSelectedMenuListChange(nextState.selectedMenuList);
      });
    }
  }

  // 删除子 Menu
  onDeselectSubMenu = (menu, subMenu) => {
    const { selectedMenuList, selectedMenuListOpenKeys } = this.state;
    const menuIndex = selectedMenuList.findIndex(m => m.id === menu.id);
    if (menuIndex >= 0) {
      const nextselectedMenuList = [...selectedMenuList];
      selectedMenuList.map((item, index) => {
        nextselectedMenuList[index] = { ...item };
        nextselectedMenuList[index].children = [...item.children];
        return nextselectedMenuList;
      });

      const subMenus = nextselectedMenuList[menuIndex].children;
      const subMenuIndex = subMenus.findIndex(sm => sm === subMenu);
      if (subMenuIndex >= 0) {
        const nextState = {};
        subMenus.splice(subMenuIndex, 1);
        if (subMenus.length === 0) {
          // remove 空壳 Menu
          nextselectedMenuList.splice(menuIndex, 1);
          const findKeyIndex = selectedMenuListOpenKeys.indexOf(menu.value);
          if (findKeyIndex >= 0) {
            selectedMenuListOpenKeys.splice(findKeyIndex, 1);
            nextState.selectedMenuListOpenKeys = [...selectedMenuListOpenKeys];
          }
        }
        nextState.selectedMenuList = [...nextselectedMenuList];
        this.setState(nextState, () => {
          if (nextState.selectedMenuListOpenKeys) {
            this.props.onSelectedMenuListOpenKeysChange(nextState.selectedMenuListOpenKeys);
          }
          this.props.onSelectedMenuListChange(nextState.selectedMenuList);
        });
      }
    }
  }

  onOriginMenuScroll = e => {
    e.preventDefault();
    e.stopPropagation();
    if (this.infiniteLoad) {
      const {
        status,
        total,
        list
      } = this.state.originMenu;
      const {
        lastestLoadTimeStamp = 0,
        threshold: {
          type,
          value
        },
        fetchOriginMenuList
      } = this.infiniteLoad;
      if (status === OperationStatus.loading
        || total === list.length
        || Date.now() - lastestLoadTimeStamp < 2000 // 2秒内不加载
      ) {
        return;
      }
      const {
        offsetHeight,
        scrollHeight,
        scrollTop
      } = e.target;
      const emitThreshold = type === 'number'
        ? value
        // eslint-disable-next-line no-mixed-operators
        : value * offsetHeight / 100; // percentage

      const shouldEmit = scrollHeight > offsetHeight
        && scrollHeight - scrollTop - offsetHeight <= emitThreshold;

      if (shouldEmit) {
        this.infiniteLoad.lastestLoadTimeStamp = Date.now();
        fetchOriginMenuList();
      }
    }
  };

  getActionBarOuterHeight = () => {
    if (typeof this.actionBarOuterHeight !== 'number') {
      const { actionBar } = this.props;
      const actionBarStyle = actionBar && actionBar.props.style;
      // eslint-disable-next-line no-mixed-operators
      const actionBarHeight = actionBarStyle && actionBarStyle.height || 0;
      const actionBarMarginHeight = actionBarStyle ? getActionBarMarginHeight(actionBarStyle) : 0;
      this.actionBarOuterHeight = actionBarStyle ? actionBarHeight + actionBarMarginHeight : 0;
    }
    return this.actionBarOuterHeight;
  }

  allResultSelectedBar = () => {
    if (this.props.allResultSelected) {
      return (
        <div className={s.allResultSelected}>
          <div className={s['search-result-tips']}>
            <span>{this.props.allResultSelected}</span>
            <span
              className={classnames({
                [s['select-all-menu']]: true,
                [s['select-all-menu-disabled']]: this.state.isAll
              })}
              onClick={e => {
                e.stopPropagation();
                this.onSelectAllMenu(this.props.originMenu);
              }}
            >
              全选
            </span>
          </div>
        </div>
      );
    }
  }

  render() {
    const {
      originHeader,
      selectedHeader,
      originMenu: {
        status,
        list
      },
      selectedMenuList,
      originMenuListOpenKeys,
      selectedMenuListOpenKeys
    } = this.state;

    const {
      infiniteLoadOriginMenu,
      originMenuTextFormatter,
      originSubMenuTextFormatter,
      style: {
        originMenuWidth,
        selectedMenuWidth,
        totalHeight
      }
    } = this.props;

    const totalWidth = originMenuWidth + selectedMenuWidth;
    const contentHeight = totalHeight - 40; // header's height is 40px
    const actionBarOuterHeight = this.getActionBarOuterHeight();
    const allSelectHeight = this.props.allResultSelected ? 42 : 0;
    // eslint-disable-next-line no-mixed-operators
    const menuHeight = contentHeight - 16 * 2 - actionBarOuterHeight - allSelectHeight;
    const showNoResult = status !== OperationStatus.loading && list.length === 0;
    const infiniteLoadProps = {};
    if (infiniteLoadOriginMenu) {
      infiniteLoadProps.onScroll = this.onOriginMenuScroll;
    }

    return (
      <div
        className={s['menu-picker-wrapper']}
        style={{
          width: totalWidth,
          height: totalHeight
        }}
      >
        <div
          className={s['origin-menu-wrapper']}
          style={{
            width: originMenuWidth
          }}
        >
          <header className={s.header}>
            {originHeader}
            <span
              className={classnames({
                [s['deselect-all-menu']]: true,
                [s.hide]: selectedMenuList.length === list.length
              })}
              onClick={this.onChooseAllMenu}
            >
              全部选择
            </span>
          </header>
          <div
            className={s.content}
            style={{
              height: contentHeight
            }}
          >
            {this.props.actionBar}
            <div>
              {this.allResultSelectedBar()}
            </div>
            <div
              className={s['origin-menu-list-wrapper']}
              style={{
                height: menuHeight
              }}
              {...infiniteLoadProps}
            >
              <IfComp
                expression={showNoResult}
                trueComp={
                  <div className={s['no-search-result']}>无搜索结果</div>
                }
              />
              <Menu
                openKeys={originMenuListOpenKeys}
                mode='inline'
                selectable={false}
                onOpenChange={this.onMenuListOpenChange}
                onClick={this.onSelectSubMenu}
                style={showNoResult ? {
                  height: menuHeight
                } : {}}
              >
                {list.map(menu => {
                  const selectedMenu = selectedMenuList.find(m => m.id === menu.id);
                  const selectAllMenu = selectedMenu
                    && selectedMenu.children.length === menu.children.length;
                  const hasChildren = menu.children.length > 0;
                  return (
                    !hasChildren
                      ? <MenuItem
                        key={menu.id}
                        onClick={() => this.onSelectMenu(menu)}
                      >
                        <IfComp
                          expression={selectedMenuList.some(m => m.id === menu.id)}
                          trueComp={
                            <Icon className={s.selected} type='check' />
                          }
                        />
                        <div className={s['submenu-title-text']}>{originSubMenuTextFormatter(menu)}</div>
                      </MenuItem>
                      : <SubMenu
                        key={menu.value}
                        title={
                          <div
                            className={s['submenu-title']}
                            onClick={e => {
                              if (!hasChildren) {
                                e.stopPropagation();
                                this.onSelectMenu(menu);
                              }
                            }}
                          >
                            <IfComp
                              expression={hasChildren}
                              trueComp={
                                <span
                                  className={classnames({
                                    [s['select-menu']]: true,
                                    [s.hide]: selectAllMenu
                                  })}
                                  onClick={e => {
                                    e.stopPropagation();
                                    this.onSelectMenu(menu);
                                  }}
                                >
                                  全选
                                </span>
                              }
                            />
                            <IfComp
                              expression={selectAllMenu}
                              trueComp={
                                <Icon className={s.selected} type='check' />
                              }
                            />
                            <IfComp
                              expression={hasChildren}
                              trueComp={
                                <Icon
                                  className={classnames({
                                    [s['submenu-title-icon']]: true,
                                    [s.open]: originMenuListOpenKeys.includes(menu.value)
                                  })}
                                  type='right'
                                />
                              }
                            />
                            <div className={s['submenu-title-text']}>
                              {originMenuTextFormatter(menu)}
                            </div>
                          </div>
                        }
                      >
                        {menu.children.map(subMenu =>
                          <MenuItem key={subMenu.id}>
                            <IfComp
                              expression={
                                selectedMenuList.some(m =>
                                  m.children.some(sm => sm.id === subMenu.id)
                                )
                              }
                              trueComp={
                                <Icon className={s.selected} type='check' />
                              }
                            />
                            <div className={s['menu-item-text']}>
                              {originSubMenuTextFormatter(subMenu)}
                            </div>
                          </MenuItem>
                        )}
                      </SubMenu>
                  );
                })}
              </Menu>
              <Spin
                spinning={status === OperationStatus.loading}
                style={{ padding: '20px 0' }}
              />
            </div>
          </div>
        </div>
        <div
          className={s['selected-menu-wrapper']}
          style={{
            width: selectedMenuWidth
          }}
        >
          <header className={s.header}>
            {selectedHeader}
            <span
              className={classnames({
                [s['deselect-all-menu']]: true,
                [s.hide]: selectedMenuList.length === 0
              })}
              onClick={this.onDeselectAllMenu}
            >
              全部删除
            </span>
          </header>
          <div
            className={s.content}
            style={{
              height: contentHeight
            }}
          >
            <div className={s['selected-menu-list-wrapper']}>
              <Menu
                openKeys={selectedMenuListOpenKeys}
                mode='inline'
                selectable={false}
                onOpenChange={this.onSelectedMenuListOpenChange}
              >
                {selectedMenuList.map(menu => {
                  const hasChildren = menu.children.length > 0;
                  return !hasChildren ? (
                    <MenuItem
                      key={menu.id}
                      onClick={() => this.onDeselectMenu(menu)}
                    >
                      <IfComp
                        expression={selectedMenuList.some(m => m.id === menu.id)}
                        trueComp={
                          <Icon className={s.selected} type='close' />
                        }
                      />
                      <div className={s['submenu-title-text']}>
                        {originSubMenuTextFormatter(menu)}
                      </div>
                    </MenuItem>
                  ) : (
                    <SubMenu
                      key={menu.value}
                      title={
                        <div className={s['submenu-title']}>
                          <IfComp
                            expression={hasChildren}
                            trueComp={
                              <Icon
                                className={classnames({
                                  [s['submenu-title-icon']]: true,
                                  [s.open]: selectedMenuListOpenKeys.includes(menu.value)
                                })}
                                type='right'
                              />
                            }
                          />
                          <Icon
                            className={s['deselect-menu']}
                            type='close'
                            onClick={e => {
                              e.stopPropagation();
                              this.onDeselectMenu(menu);
                            }}
                          />
                          <span className={s['submenu-title-text']}>{menu.name}</span>
                        </div>
                      }
                    >
                      {menu.children.map(subMenu =>
                        <MenuItem key={subMenu.value}>
                          <IfComp
                            expression={
                              selectedMenuList.some(m =>
                                m.children.some(sm => sm === subMenu)
                              )
                            }
                            trueComp={
                              <Icon
                                className={s['deselect-menu']}
                                type='close'
                                onClick={e => {
                                  e.stopPropagation();
                                  this.onDeselectSubMenu(menu, subMenu);
                                }}
                              />
                            }
                          />
                          <span className={s['menu-item-text']}>{subMenu.name}</span>
                        </MenuItem>
                      )}
                    </SubMenu>
                  );
                })}
              </Menu>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(CascadingMenuPicker4);
