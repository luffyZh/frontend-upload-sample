import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { Select, Checkbox } from 'antd';
import withViewport from '../../../core/withViewPort';
import {
  screenMinWidth,
  paddingLR
} from './variables';
import DataChart from './DataChart';
import s from './index.less';

const { Option } = Select;

const numberTickFormatter = val => {
  if (val >= 1000) {
    return `${Math.round(val / 10) / 100}k`;
  }
  return val;
};

const percentTickFormatter = val => `${val}%`;

const XRateArr = ['clickRate', 'imprRate', 'bidRate'];

const getProperTickFormatter = x => (x && XRateArr.includes(x))
  ? percentTickFormatter
  : numberTickFormatter
;

class StatisticsGraph extends Component {
  static propTypes = {
    data: PropTypes.array.isRequired,
    viewport: PropTypes.object.isRequired,
    vsIndicator: PropTypes.array.isRequired,
    moduleType: PropTypes.string,
    type: PropTypes.string
  };
  static defaultProps = {
    moduleType: null,
    type: ''
  }

  constructor(props) {
    super(props);
    const {
      data,
      viewport,
      vsIndicator
    } = props;
    this.state = {
      vs: false,
      selectValues: [vsIndicator[0].value, vsIndicator[1].value],
      selectLabels: [vsIndicator[0].name, vsIndicator[1].name],
      selectUnits: [vsIndicator[0].unit || '', vsIndicator[1].unit || ''],
      data,
      width: viewport.width
    };
  }

  componentWillReceiveProps(nextProps) {
    const {
      data,
      viewport: {
        width
      },
      type,
      vsIndicator
    } = nextProps;

    const { vs } = this.state;

    this.setState({
      data,
      width: width > screenMinWidth ? width : screenMinWidth,
      vs: (this.props.moduleType === 'dataReport' && type !== this.props.type) ? false : vs,
      selectValues: [vsIndicator[0].value, vsIndicator[1].value],
      selectLabels: [vsIndicator[0].name, vsIndicator[1].name],
      selectUnits: [vsIndicator[0].unit || '', vsIndicator[1].unit || '']
    });
  }

  shouldComponentUpdate(nextProps, nextState) {
    const {
      vs,
      selectValues,
      data,
      width,
      vsIndicator
    } = this.state;

    const {
      vs: nVs,
      selectValues: nSelectValues,
      data: nData,
      width: nWidth,
      vsIndicator: nVsIndicator
    } = nextState;

    return vs !== nVs
      || selectValues !== nSelectValues
      || data !== nData
      || width !== nWidth
      || vsIndicator !== nVsIndicator;
  }

  getController() {
    const { vsIndicator } = this.props;
    const {
      vs,
      selectValues
    } = this.state;

    return (
      <div className={s.controller}>
        <Select
          className={s.select}
          value={selectValues[0]}
          onChange={this.selectChangeHandler(0)}
        >
          {
            vsIndicator.map(item => (
              <Option
                key={item.value}
                value={item.value}
              >
                {item.name}
              </Option>
            ))
          }
        </Select>
        <div className={s.vsLabel}>
          <span>对比 </span>
          <Checkbox
            checked={vs}
            onChange={this.vsChangeHandler}
          />
        </div>
        <Select
          className={s.select}
          value={selectValues[1]}
          onChange={this.selectChangeHandler(1)}
        >
          {
            vsIndicator.map(item => (
              <Option
                key={item.value}
                value={item.value}
              >
                {item.name}
              </Option>
            ))
          }
        </Select>
      </div>
    );
  }

  vsChangeHandler = evt => {
    this.setState({
      vs: evt.target.checked
    });
  }

  selectChangeHandler = index => value => {
    const { vsIndicator } = this.props;
    const {
      selectValues: preValues,
      selectLabels: preLabels,
      selectUnits: preUnits
    } = this.state;
    const selectValues = [...preValues];
    const selectLabels = [...preLabels];
    const selectUnits = [...preUnits];
    const item = vsIndicator.find(x => x.value === value);

    selectValues[index] = value;
    selectLabels[index] = item.name;
    selectUnits[index] = item.unit || '';

    this.setState({
      selectValues,
      selectLabels,
      selectUnits
    });
  };

  render() {
    const { moduleType } = this.props;
    const {
      vs,
      selectValues,
      selectLabels,
      selectUnits,
      data,
      width
    } = this.state;
    // eslint-disable-next-line no-mixed-operators
    const chartWidth = width - paddingLR * 2;

    return (
      <section className={s.container}>
        { this.getController() }
        <DataChart
          lineType='linear'
          data={data}
          xKey='date'
          yKeys={vs ? selectValues : [selectValues[0]]}
          yLabels={vs ? selectLabels : [selectLabels[0]]}
          yUnits={selectUnits}
          tickFormatters={{
            left: getProperTickFormatter(selectValues[0]),
            right: vs ? getProperTickFormatter(selectValues[1]) : null
          }}
          width={
            moduleType === 'dataReport' ? (chartWidth - 300) : (chartWidth - 32 * 2)
          }
          height={300}
        />
      </section>
    );
  }

}

export default withStyles(s)(withViewport(StatisticsGraph));
