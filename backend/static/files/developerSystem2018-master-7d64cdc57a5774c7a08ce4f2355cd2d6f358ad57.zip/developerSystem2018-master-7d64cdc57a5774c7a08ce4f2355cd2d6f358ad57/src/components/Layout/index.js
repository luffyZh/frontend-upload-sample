import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
// external-global styles must be imported in your JS.
import normalizeCss from 'normalize.css';
import Header from '../Header';
import Navigation from '../Navigation';
import s from './Layout.less';

class Layout extends Component {

  static propTypes = {
    children: PropTypes.node.isRequired,
    onLogout: PropTypes.func.isRequired,
    fetchUnreadMessage: PropTypes.func.isRequired,
    username: PropTypes.string,
    unReadCount: PropTypes.number,
    permissionList: PropTypes.string
  };

  static defaultProps = {
    username: '',
    unReadCount: 0,
    permissionList: ''
  }

  render() {
    const { onLogout, fetchUnreadMessage, unReadCount, username, permissionList } = this.props;
    const { pathname } = this.context;

    return (
      <div>
        <Header
          onLogout={onLogout}
          fetchUnreadMessage={fetchUnreadMessage}
          username={username}
          unReadCount={unReadCount}
        />
        <Navigation path={pathname} permissionList={permissionList} />
        {this.props.children}
      </div>
    );
  }
}

Layout.contextTypes = {
  pathname: PropTypes.string
};

export default withStyles(normalizeCss, s)(Layout);
