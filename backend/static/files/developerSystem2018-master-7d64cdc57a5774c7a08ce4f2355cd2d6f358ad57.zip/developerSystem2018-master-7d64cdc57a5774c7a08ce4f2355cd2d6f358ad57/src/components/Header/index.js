import React, { Component } from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../Link';
import s from './Header.less';

class Header extends Component {
  static propTypes = {
    onLogout: PropTypes.func.isRequired,
    fetchUnreadMessage: PropTypes.func.isRequired,
    username: PropTypes.string,
    unReadCount: PropTypes.number
  };

  static defaultProps = {
    username: '',
    unReadCount: 0
  }

  componentDidMount() {
    this.props.fetchUnreadMessage();
  }

  render() {
    const { onLogout, unReadCount, username } = this.props;
    return (
      <header className={`${s.root} root`}>
        <div className={s.container}>
          <Link className={s.brand} to="/">
            <span className={s.brand__logo} />
            <span className={s.brand__txt}>有道智选开发者平台</span>
          </Link>
          <section className={s.links}>
            <Link className={s.link} to='/developer/accountManagement/systemInfo'>
              <span className={`${s.link} ${s.noclick}`}>
                消息
                <span className={s.badge} style={{ display: unReadCount <= 0 ? 'none' : 'flex' }}>
                  <span className={s.smallFont}>{unReadCount > 99 ? '99+' : unReadCount}</span>
                </span>
              </span>
            </Link>
            <span className={s.splitter}>|</span>
            <span className={`${s.link} ${s.noclick}`}>{username || ''}</span>
            <span className={s.splitter}>|</span>
            {/* https://github.com/evcohen/eslint-plugin-jsx-a11y/issues/270 */}
            <span className={s.link} onClick={onLogout} role="presentation">
              退出
            </span>
          </section>
        </div>
      </header>
    );
  }
}

export default withStyles(s)(Header);
