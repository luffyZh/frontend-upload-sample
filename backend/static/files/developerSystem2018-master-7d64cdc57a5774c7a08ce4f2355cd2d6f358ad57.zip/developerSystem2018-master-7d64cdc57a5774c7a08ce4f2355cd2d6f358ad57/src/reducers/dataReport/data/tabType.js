import { DataReportTabs } from '../../../constants/MenuTypes';
import { DATA_REPORT_TAB_CHANGE } from '../../../constants/ActionTypes';

const initialState = {
  activeTab: DataReportTabs.账户报表
};

export default function tabType(state = initialState, { type, payload }) {
  switch (type) {
    case DATA_REPORT_TAB_CHANGE:
      return {
        ...state,
        activeTab: payload
      };
    default:
      return state;
  }
}
