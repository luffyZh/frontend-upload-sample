import _ from 'lodash';
import {
  OperationStatus,
  DataReportTabs
} from '../../../constants/MenuTypes';
import {
  GET_DEVELOPER_REPORT_DATA,
  GET_DEVELOPER_REPORT_DATA_SUCCESS,
  GET_DEVELOPER_REPORT_DATA_FAIL,
  QUERY_CONDITION_CHANGE
} from '../../../constants/ActionTypes';

const getSingleInitialState = () => ({
  status: OperationStatus.initial,
  total: 0,
  chartList: [],
  tableList: [],
  totalObj: {}
});

const initialState = {};
_.values(DataReportTabs).forEach(k => {
  initialState[k] = getSingleInitialState();
});

export default function list(state = initialState, { type, tabType, payload }) {
  switch (type) {
    case QUERY_CONDITION_CHANGE: {
      return {
        ...state,
        [tabType]: {
          ...state[tabType],
          status: OperationStatus.initial
        }
      };
    }
    case GET_DEVELOPER_REPORT_DATA:
      return {
        ...state,
        [tabType]: {
          ...state[tabType],
          status: OperationStatus.loading
        }
      };
    case GET_DEVELOPER_REPORT_DATA_SUCCESS: {
      const totalObj = {
        requestAdNum: payload.totalRequestAdNum,
        bid: payload.totalBid,
        impr: payload.totalImpr,
        click: payload.totalClick,
        bidRate: payload.totalBidRate,
        imprRate: payload.totalImprRate,
        clickRate: payload.totalClickRate,
        appId: '--',
        slotUdid: '--',
        appName: '--',
        slotName: '--',
        schemaName: '--'
      };
      const { total, summaryList, resultList } = payload;
      return {
        ...state,
        [tabType]: {
          status: OperationStatus.load_success,
          total,
          chartList: summaryList.sort((a, b) => (a.date < b.date) ? -1 : 1),
          tableList: resultList.sort((a, b) => (a.date > b.date) ? -1 : 1),
          totalObj
        }
      };
    }
    case GET_DEVELOPER_REPORT_DATA_FAIL:
      return {
        ...state,
        [tabType]: {
          total: 0,
          chartList: [],
          tableList: [],
          status: OperationStatus.load_fail,
          totalObj: {}
        }
      };
    default:
      return state;
  }
}
