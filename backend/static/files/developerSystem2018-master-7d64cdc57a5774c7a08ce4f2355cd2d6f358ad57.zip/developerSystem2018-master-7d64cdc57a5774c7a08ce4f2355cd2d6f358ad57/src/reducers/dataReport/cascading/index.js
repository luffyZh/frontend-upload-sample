import { combineReducers } from 'redux';
import queryCondition from './queryCondition';
import list from './list';

export default combineReducers({
  queryCondition,
  list
});
