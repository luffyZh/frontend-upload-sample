import moment from 'moment';
import {
  QUERY_CONDITION_CHANGE,
  RESET_QUERY_CONDITION,
  DATA_REPORT_TAB_CHANGE
} from '../../constants/ActionTypes';
import {
  DataReportTabs,
  DataReportAggregateType
} from '../../constants/MenuTypes';

moment.locale('zh-cn');

const getSingleInitialState = tabType => {
  const initialState = {
    pageNo: 1,
    pageSize: 10,
    dateRange: {
      startDate: moment().subtract(7, 'days'),
      endDate: moment().subtract(1, 'days')
    },
    aggregate: tabType !== DataReportTabs.账户报表
      ? DataReportAggregateType.汇总 : DataReportAggregateType.按天,
    id: '',
    ids: ''
  };
  return initialState;
};

const queryCondition = (state = getSingleInitialState(), { type, payload, targetId }) => {
  if (type === QUERY_CONDITION_CHANGE) {
    switch(payload.type) {
      case 'pageNo': {
        return {
          ...state,
          pageNo: payload.pageNo
        };
      }
      case 'aggregate':
      case 'pageSize':
      case 'dateRange': {
        return {
          ...state,
          [payload.type]: payload[payload.type],
          pageNo: 1
        };
      }
      case 'id': {
        return {
          ...state,
          id: payload.id,
          ids: '',
          pageNo: 1
        };
      }
      case 'ids': {
        return {
          ...state,
          ids: payload.ids,
          id: '',
          pageNo: 1
        };
      }
      default:
        return state;
    }
  } else if (type === RESET_QUERY_CONDITION) {
    return getSingleInitialState(payload);
  } else if (type === DATA_REPORT_TAB_CHANGE) {
    return !targetId ? {
      ...state,
      id: '',
      ids: '',
      aggregate: payload === DataReportTabs.账户报表
        ? DataReportAggregateType.按天 : DataReportAggregateType.汇总
    } : {
      ...state,
      id: '',
      ids: ''
    };
  }
  return state;
};

export default queryCondition;
