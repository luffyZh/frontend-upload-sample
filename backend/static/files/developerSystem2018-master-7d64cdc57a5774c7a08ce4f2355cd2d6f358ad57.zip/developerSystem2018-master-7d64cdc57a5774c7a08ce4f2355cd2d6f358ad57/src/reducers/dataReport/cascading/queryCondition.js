import _ from 'lodash';
import {
  CASCADING_QUERY_CONDITION_CHANGE,
  RESET_CASCADING_QUERY_CONDITION
} from '../../../constants/ActionTypes';


const initialState = {
  pageNo: 1,
  pageSize: 10,
  keyword: ''
};

const queryCondition = (state = _.assign({}, initialState), { type, payload }) => {
  if (type === CASCADING_QUERY_CONDITION_CHANGE) {
    switch(payload.type) {
      case 'pageSize':
      case 'keyword': {
        return {
          ...state,
          [payload.type]: payload[payload.type],
          pageNo: 1
        };
      }
      default:
        return state;
    }
  } else if (type === RESET_CASCADING_QUERY_CONDITION) {
    return initialState;
  }
  return state;
};

export default queryCondition;
