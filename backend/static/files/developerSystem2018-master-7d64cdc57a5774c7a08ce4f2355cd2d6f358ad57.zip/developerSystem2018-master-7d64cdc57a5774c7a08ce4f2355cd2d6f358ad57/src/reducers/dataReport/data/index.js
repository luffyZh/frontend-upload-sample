import { combineReducers } from 'redux';
import tabType from './tabType';
import list from './list';

export default combineReducers({
  list,
  tabType
});
