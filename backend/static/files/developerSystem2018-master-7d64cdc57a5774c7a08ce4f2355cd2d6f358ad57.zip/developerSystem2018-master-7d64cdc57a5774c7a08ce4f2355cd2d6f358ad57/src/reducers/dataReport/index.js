import { combineReducers } from 'redux';
import queryCondition from './queryCondition';
import data from './data';
import cascading from './cascading';

export default combineReducers({
  queryCondition,
  data,
  cascading
});
