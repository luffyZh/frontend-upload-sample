import {
  OperationStatus, DataReportTabs
} from '../../../constants/MenuTypes';
import {
  GET_DATAREPORT_CASCADING_LIST,
  GET_DATAREPORT_CASCADING_LIST_SUCCESS,
  GET_DATAREPORT_CASCADING_LIST_FAIL,
  CASCADING_QUERY_CONDITION_CHANGE,
  GET_SELECTED_MENU_LIST,
  GET_SELECTED_MENU_LIST_SUCCESS,
  GET_SELECTED_MENU_LIST_FAIL,
  SELECTED_MENU_LIST_CHANGE
} from '../../../constants/ActionTypes';
import {
  generateOriginMenuList,
  generateSelectedMenuList,
  generateSelectedCount
} from '../../../core/utils';

const getSingleInitialState = () => ({
  status: OperationStatus.initial,
  originMenuList: [],
  total: 0,
  selectedMenuList: [],
  selectedCount: 0
});

export default function list(state = getSingleInitialState(), { type, tabType, payload, slotUdid }) {
  switch (type) {
    case CASCADING_QUERY_CONDITION_CHANGE: {
      return {
        ...state,
        status: OperationStatus.initial
      };
    }
    case GET_DATAREPORT_CASCADING_LIST:
    case GET_SELECTED_MENU_LIST:
      return {
        ...state,
        status: OperationStatus.loading
      };
    case GET_DATAREPORT_CASCADING_LIST_SUCCESS: {
      return {
        ...state,
        status: OperationStatus.load_success,
        originMenuList: generateOriginMenuList(payload.resultList, tabType),
        total: payload.total
      };
    }
    case GET_SELECTED_MENU_LIST_SUCCESS: {
      return {
        ...state,
        status: OperationStatus.load_success,
        selectedMenuList: generateSelectedMenuList(tabType, payload, slotUdid),
        selectedCount: tabType === DataReportTabs.样式 ? 1 : payload[0].slots.length
      };
    }
    case GET_DATAREPORT_CASCADING_LIST_FAIL:
    case GET_SELECTED_MENU_LIST_FAIL:
      return {
        ...state,
        status: OperationStatus.load_fail,
        originMenuList: [],
        selectedMenuList: [],
        selectedCount: 0
      };
    case SELECTED_MENU_LIST_CHANGE:
      return {
        ...state,
        selectedMenuList: payload,
        selectedCount: generateSelectedCount(tabType, payload)
      };
    default:
      return state;
  }
}
