import { combineReducers } from 'redux';
import deviceInfo from './deviceInfo';
import accountInfo from './accountInfo';
import systemInfo from './systemInfo';

export default combineReducers({
  accountInfo,
  deviceInfo,
  systemInfo
});
