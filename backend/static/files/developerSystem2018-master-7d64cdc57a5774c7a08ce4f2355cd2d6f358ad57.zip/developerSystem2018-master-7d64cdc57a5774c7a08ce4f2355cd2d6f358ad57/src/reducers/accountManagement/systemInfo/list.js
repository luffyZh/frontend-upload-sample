import {
  GET_SYSTEM_INFO,
  GET_SYSTEM_INFO_SUCCESS,
  GET_SYSTEM_INFO_FAIL,
  QUERY_CONDITION_CHANGE,
  UPDATE_SYSTEM_INFO_STATUS_SUCCESS,
  UPDATE_SYSTEM_INFO_STATUS_FAIL,
  FETCH_UNREAD_MESSAGE_FAIL,
  FETCH_UNREAD_MESSAGE_SUCCESS,
  FETCH_UNREAD_MESSAGE
} from '../../../constants/ActionTypes';
import { OperationStatus } from '../../../constants/MenuTypes';

const getSingleInitialState = () => ({
  total: 0,
  unReadCount: 0,
  list: [],
  status: OperationStatus.initial
});

const initialState = getSingleInitialState();

export default function systemInfo(state = initialState, { type, payload }) {
  switch (type) {
    case QUERY_CONDITION_CHANGE:
      return {
        ...state,
        status: OperationStatus.initial
      };
    case FETCH_UNREAD_MESSAGE:
    case GET_SYSTEM_INFO:
      return {
        ...state,
        status: OperationStatus.loading
      };
    case GET_SYSTEM_INFO_FAIL:
    case UPDATE_SYSTEM_INFO_STATUS_FAIL:
    case FETCH_UNREAD_MESSAGE_FAIL:
      return {
        ...state,
        status: OperationStatus.load_fail
      };
    case GET_SYSTEM_INFO_SUCCESS:
      return {
        ...state,
        list: payload.list,
        total: payload.total,
        status: OperationStatus.load_success
      };
    case UPDATE_SYSTEM_INFO_STATUS_SUCCESS: {
      return {
        ...state,
        list: state.list.map(item => {
          if (item.messageId === payload.result) {
            item.status = 2;
          }
          return item;
        }),
        unReadCount: state.unReadCount  - 1
      };
    }
    case FETCH_UNREAD_MESSAGE_SUCCESS: {
      return {
        ...state,
        unReadCount: payload.result
      };
    }
    default:
      return state;
  }
}
