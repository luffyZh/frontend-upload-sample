import {
  GET_SELF_TEST_DEVICE_LIST,
  GET_SELF_TEST_DEVICE_LIST_SUCCESS,
  GET_SELF_TEST_DEVICE_LIST_FAIL,
  CHANGE_SELF_TEST_DEVICE_STATUS,
  CHANGE_SELF_TEST_DEVICE_STATUS_SUCCESS,
  CHANGE_SELF_TEST_DEVICE_STATUS_FAIL,
  ADD_SELF_TEST_DEVICE,
  ADD_SELF_TEST_DEVICE_FAIL,
  ADD_SELF_TEST_DEVICE_SUCCESS
} from '../../../constants/ActionTypes';
import { OperationStatus } from '../../../constants/MenuTypes';
import { changeDeviceListStatus } from '../../../core/utils';

const getSingleInitialState = () => ({
  status: OperationStatus.initial,
  operationStatus: OperationStatus.initial,
  total: 0,
  list: []
});
const initialState = getSingleInitialState();

export default function deviceInfo(state = initialState, action) {
  const { type, payload, devicesObj, addDevice } = action;
  switch (type) {
    case GET_SELF_TEST_DEVICE_LIST:
    case CHANGE_SELF_TEST_DEVICE_STATUS:
    case ADD_SELF_TEST_DEVICE:
      return {
        ...state,
        status: OperationStatus.loading
      };
    case GET_SELF_TEST_DEVICE_LIST_SUCCESS:
      return {
        ...state,
        total: payload.total,
        list: payload.list,
        status: OperationStatus.load_success
      };
    case CHANGE_SELF_TEST_DEVICE_STATUS_SUCCESS: {
      const { ids, status } = devicesObj;
      return {
        ...state,
        list: changeDeviceListStatus(state.list, ids, status).filter(item => item.status !== 2),
        operationStatus: OperationStatus.load_success
      };
    }
    case ADD_SELF_TEST_DEVICE_SUCCESS: {
      const addItem = {
        id: payload.id,
        deviceId: addDevice.deviceId,
        comment: addDevice.comment
      };
      return {
        ...state,
        list: [addItem].concat(state.list),
        status: OperationStatus.load_success
      };
    }
    case GET_SELF_TEST_DEVICE_LIST_FAIL:
    case CHANGE_SELF_TEST_DEVICE_STATUS_FAIL:
    case ADD_SELF_TEST_DEVICE_FAIL:
      return {
        ...state,
        operationStatus: OperationStatus.load_fail
      };
    default:
      return state;
  }
}
