import {
  QUERY_CONDITION_CHANGE,
  RESET_QUERY_CONDITION
} from '../../../constants/ActionTypes';

const getSingleInitialState = () => {
  const initialState = {
    pageNo: 1,
    pageSize: 10
  };
  return initialState;
};

const queryCondition = (state = getSingleInitialState(), { type, payload }) => {
  if (type === QUERY_CONDITION_CHANGE) {
    switch(payload.type) {
      case 'pageNo': {
        return {
          ...state,
          pageNo: payload.pageNo
        };
      }
      case 'pageSize': {
        return {
          ...state,
          pageSize: payload.pageSize,
          pageNo: 1
        };
      }
      default:
        return state;
    }
  } else if (type === RESET_QUERY_CONDITION) {
    return getSingleInitialState();
  }
  return state;
};

export default queryCondition;
