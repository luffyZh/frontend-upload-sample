import _ from 'lodash';
import {
  GET_ACCOUNT_INFO,
  GET_ACCOUNT_INFO_FAIL,
  GET_ACCOUNT_INFO_SUCCESS,
  CHANGE_USER_INFO,
  UPDATE_ACCOUNT_INFO,
  UPDATE_ACCOUNT_INFO_SUCCESS
} from '../../../constants/ActionTypes';

const initialState = {
  user: {
    type: 0,
    name: '有道开发者',
    cidType: 0,
    cid: '',
    phone: '13000000000',
    email: 'yodao_kevin@163.com',
    company: '网易有道',
    address: '北京市海淀区西北旺东路10号院网易北京研发中心'
  },
  originalUser: {
    type: 0,
    name: '有道开发者',
    cidType: 0,
    cid: '',
    phone: '13000000000',
    email: 'yodao_kevin@163.com',
    company: '网易有道',
    address: '北京市海淀区西北旺东路10号院网易北京研发中心'
  }
};

export default function accountInfo(state = _.assign({}, initialState), { type, payload }) {
  switch (type) {
    case GET_ACCOUNT_INFO:
    case UPDATE_ACCOUNT_INFO:
    case GET_ACCOUNT_INFO_FAIL:
      return state;
    case GET_ACCOUNT_INFO_SUCCESS:
      return {
        ...state,
        user: payload,
        originalUser: _.assign({}, payload)
      };
    case UPDATE_ACCOUNT_INFO_SUCCESS: 
      return {
        ...state,
        originalUser: _.assign({}, state.user)
      };
    case CHANGE_USER_INFO:
      return {
        ...state,
        user: payload
      };
    default:
      return state;
  }
}
