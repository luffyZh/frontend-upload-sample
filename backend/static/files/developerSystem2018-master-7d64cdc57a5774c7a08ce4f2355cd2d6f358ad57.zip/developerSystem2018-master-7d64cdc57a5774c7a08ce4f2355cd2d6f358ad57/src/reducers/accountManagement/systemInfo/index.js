import { combineReducers } from 'redux';
import list from './list';
import queryCondition from './queryCondition';

export default combineReducers({
  list,
  queryCondition
});
