import { combineReducers } from 'redux';
import adList from './adList';
import editPriority from './editPriority';

export default combineReducers({
  adList,
  editPriority
});
