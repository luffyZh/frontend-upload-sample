import {
  GET_PLATFORM_LIST,
  GET_PLATFORM_LIST_FAIL,
  GET_PLATFORM_LIST_SUCCESS,
  ADD_PLATFORM_PRIORITY,
  ADD_PLATFORM_PRIORITY_FAIL,
  ADD_PLATFORM_PRIORITY_SUCCESS,
  PLATFORM_EDITING_NOW,
  EDIT_PLATFORM_PRIORITY,
  EDIT_PLATFORM_PRIORITY_FAIL,
  EDIT_PLATFORM_PRIORITY_SUCCESS,
  DELETE_PLATFORM_PRIORITY,
  DELETE_PLATFORM_PRIORITY_FAIL,
  DELETE_PLATFORM_PRIORITY_SUCCESS,
  PLATFORM_ADDING_NOW,
  PLATFORM_DELETE,
  PLATFORM_VALUE_CHANGE,
  PLATFORM_ADD_ROW,
  PLATFORM_ROW_SAVE,
  PLATFORM_DELETE_ROW,
  PLATFORM_ROW_EDIT
} from '../../../constants/ActionTypes';
import { 
  dataSourceIndex,
  dataSourceMap,
  changeRowEdit
} from '../../../constants/MenuTypes';
        
const initialState = {
  platformPriorities: [],
  mediationSdkSlotName: '',
  mediationSdkSlotUid: '',
  source: {
    editStatus: true,
    newAdd: true,
    platformPriorityId: 'Facebook' + 1,
    configs: [{
      priority: 1,
      ad_source: 'Facebook',
      ad_type: '原生广告',
      placement_id: '',
      timeout: 1,
      isRowEdit: true
    }]
  }
};
      
export default function priorityConfig(state = initialState, { type, payload, infoObj }) {
  switch (type) {
    case PLATFORM_EDITING_NOW:
      return {
        ...state,
        platformPriorities: dataSourceIndex(
          state.platformPriorities, 
          payload.index, 
          {editStatus: payload.editStatus},
          {newAdd: false},
          {configs: payload.dataSource}
        )
      };
    case PLATFORM_ADDING_NOW:
      return {
        ...state,
        platformPriorities: [state.source, ...changeRowEdit(state.platformPriorities)]
      };
    case PLATFORM_VALUE_CHANGE:
      return {
        ...state,
        platformPriorities: dataSourceIndex(
          state.platformPriorities, 
          payload.index,
          payload.dataSource
        )
      };
    case PLATFORM_DELETE:
      return {
        ...state,
        platformPriorities: state.platformPriorities.filter((item, index) => payload.index !== index)
      };
    case PLATFORM_ADD_ROW:
      return {
        ...state,
        platformPriorities: dataSourceIndex(state.platformPriorities, payload.index, {configs: payload.dataSource})
      };
    case PLATFORM_DELETE_ROW:
      return {
        ...state,
        platformPriorities: dataSourceIndex(state.platformPriorities, payload.index, {configs: payload.dataSource})
      };
    case PLATFORM_ROW_SAVE:
      return {
        ...state,
        platformPriorities: dataSourceIndex(state.platformPriorities, payload.index, {configs: payload.dataSource})
      };
    case PLATFORM_ROW_EDIT:
      return {
        ...state,
        platformPriorities: dataSourceIndex(state.platformPriorities, payload.index, {configs: payload.dataSource})
      };
    case GET_PLATFORM_LIST:
    case EDIT_PLATFORM_PRIORITY:
    case ADD_PLATFORM_PRIORITY:
    case DELETE_PLATFORM_PRIORITY:
      return {
        ...state
      };
    case GET_PLATFORM_LIST_SUCCESS:
      return {
        ...state,
        platformPriorities: changeRowEdit(payload.platformPriorities),
        mediationSdkSlotName: payload.mediationSdkSlotName
      };
    case ADD_PLATFORM_PRIORITY_SUCCESS:
      return {
        ...state,
        mediationSdkSlotUid: infoObj.mediationSdkSlotUid,
        platformPriorities: dataSourceMap(state.platformPriorities, {editStatus: false}, {newAdd: false})
      };
    case EDIT_PLATFORM_PRIORITY_SUCCESS:
      return {
        ...state,
        platformPriorities: dataSourceIndex(
          state.platformPriorities, 
          infoObj.index, 
          {editStatus: infoObj.editStatus}, 
          {newAdd: false},
          {configs: infoObj.platformInfo}
        )
      };
    case DELETE_PLATFORM_PRIORITY_SUCCESS:
      return {
        ...state,
        platformPriorities: state.platformPriorities.filter((item, index) => index !== infoObj.index)
      };
    case GET_PLATFORM_LIST_FAIL:
    case ADD_PLATFORM_PRIORITY_FAIL:
    case EDIT_PLATFORM_PRIORITY_FAIL:
    case DELETE_PLATFORM_PRIORITY_FAIL:
      return {
        ...state
      };
    default:
      return state;
  }
}