import {
  GET_COUNTRY_LIST,
  GET_COUNTRY_LIST_FAIL,
  GET_COUNTRY_LIST_SUCCESS,
  GET_LANGUAGE_LIST,
  GET_LANGUAGE_LIST_FAIL,
  GET_LANGUAGE_LIST_SUCCESS,
  ENTER_CREATE_PRIORITY,
  GET_PRIORITY_LIST,
  GET_PRIORITY_LIST_FAIL,
  GET_PRIORITY_LIST_SUCCESS,
  GET_DETAILS_INFO,
  GET_DETAILS_INFO_FAIL,
  GET_DETAILS_INFO_SUCCESS,
  GET_OPTION_LIST,
  GET_OPTION_LIST_SUCCESS,
  GET_OPTION_LIST_FAIL,
  CHANGE_RADIO_VALUE,
  EMIT_EDIT_MODAL,
  DELETE_OR_ADD,
  CHANGE_EDITMODAL_VALUE,
  CHANGE_EDITMODAL_VALUE_FAIL,
  CHANGE_EDITMODAL_VALUE_SUCCESS,
  EDIT_PRIORITY_CONFIG,
  EDIT_PRIORITY_CONFIG_FAIL,
  EDIT_PRIORITY_CONFIG_SUCCESS,
  ADD_PRIORITY_CONFIG,
  ADD_PRIORITY_CONFIG_FAIL,
  ADD_PRIORITY_CONFIG_SUCCESS,
  CHANGE_SELECTED_LIST,
  CHANGE_KEYWORD
} from '../../../constants/ActionTypes';
import { 
  OperationStatus,
  priorityList,
  getNameByIds,
  dateAndTime,
  getIdByKeyword,
  checkPlatformPriorityId,
  listType,
  modeValue,
  disabledValue,
  reverseModeValue,
  optionTypeValue,
  optionTypeStyle
} from '../../../constants/MenuTypes';
import {
  checkForm,
  generateOriginMenuListSDK
} from '../../../core/utils';
        
const initialState = {
  status: OperationStatus.initial,
  countryList: [],
  originCountryList: [],
  originLanguageList: [],
  keyWord: '',
  languageList: [],
  optionType: 0,
  toDeleteIds: [],
  toAddValues: [],
  osVersionIds: [],
  appVersionIds: [],
  channelNoIds: [],
  countryIds: [],
  sysLanguageIds: [],
  osList: [],
  appList: [],
  channelList: [],
  priorityList: priorityList,
  detailsInfo: [],
  changeInfo: false,
  disabledValue: disabledValue,
  _disabledValue: disabledValue
};
      
export default function priority(state = initialState, { type, payload, infoObj }) {
  switch (type) {
    case ENTER_CREATE_PRIORITY:
      return {
        ...state,
        priorityList: Object.assign(
          {}, 
          priorityList, 
          {mediationSdkSlotName: payload.priorityName},
          {startTime: dateAndTime()}
        ),
        changeInfo: false,
        disabledValue: Object.assign({}, state._disabledValue, {settingName: false})
      };
    case GET_OPTION_LIST:
    case GET_COUNTRY_LIST:
    case GET_LANGUAGE_LIST:
    case GET_PRIORITY_LIST:
    case GET_DETAILS_INFO:
    case CHANGE_EDITMODAL_VALUE:
    case EDIT_PRIORITY_CONFIG:
    case ADD_PRIORITY_CONFIG:
      return {
        ...state,
        status: OperationStatus.loading
      };
    case GET_COUNTRY_LIST_SUCCESS:
      return {
        ...state,
        status: OperationStatus.load_success,
        countryList: generateOriginMenuListSDK(payload, 'countryIds'),
        originCountryList: generateOriginMenuListSDK(payload, 'countryIds'),
        countryIds: state.priorityList.countryIds === '' ? [] : 
          generateOriginMenuListSDK(getNameByIds(state.priorityList.countryIds, payload), 'countryIds')
      };
    case GET_LANGUAGE_LIST_SUCCESS:
      return {
        ...state,
        status: OperationStatus.load_success,
        languageList: generateOriginMenuListSDK(payload, 'sysLanguageIds'),
        originLanguageList: generateOriginMenuListSDK(payload, 'sysLanguageIds'),
        sysLanguageIds: state.priorityList.sysLanguageIds === '' ? [] : 
          generateOriginMenuListSDK(getNameByIds(state.priorityList.sysLanguageIds, payload), 'sysLanguageIds')
      };
    case GET_PRIORITY_LIST_SUCCESS:
      return {
        ...state,
        priorityList: checkPlatformPriorityId(payload.priorityList, state.detailsInfo),
        mediationSdkSlotUid: payload.mediationSdkSlotUid,
        changeInfo: false,
        disabledValue: Object.assign({}, state.disabledValue, 
          checkForm(
            {platformPriorityId: payload.priorityList.platformPriorityId},
          ))
      };
    case CHANGE_RADIO_VALUE: 
      return {
        ...state,
        priorityList: payload.option[payload.keys] === 0 ? 
          Object.assign({}, state.priorityList, payload.option, {[modeValue[payload.keys]]: []})
          : Object.assign({}, state.priorityList, payload.option),
        changeInfo: payload.changeInfo,
        disabledValue: Object.assign({}, state.disabledValue, checkForm(payload.option))
      };
    case EMIT_EDIT_MODAL: 
      return {
        ...state,
        optionType: payload,
        toAddValues: [],
        toDeleteIds: []
      };
    case CHANGE_SELECTED_LIST: 
      return {
        ...state,
        priorityList: Object.assign({}, state.priorityList, payload.option),
        [payload.text]: payload.text === listType[payload.text] ? payload.selectedMenuList : state[payload.text],
        changeInfo: payload.changeInfo,
        disabledValue: payload.selectedMenuList.length === 0 ? 
          Object.assign({}, state.disabledValue, {[reverseModeValue[payload.text]]: false})
          : Object.assign({}, state.disabledValue, {[reverseModeValue[payload.text]]: true})
      };
    case DELETE_OR_ADD: 
      return {
        ...state,
        toDeleteIds: payload.toDeleteIds,
        toAddValues: payload.toAddValues
      };
    case CHANGE_EDITMODAL_VALUE_SUCCESS: 
      return {
        ...state,
        optionType: infoObj.optionType,
        toDeleteIds: [],
        toAddValues: [],
        changeInfo: infoObj.changeInfo,
        osVersionIds: infoObj.optionType === 1 ? 
          generateOriginMenuListSDK(getNameByIds(state.osVersionIds, state.osList), 'osVersionIds') : state.osVersionIds,
        appVersionIds: infoObj.optionType === 2 ? 
          generateOriginMenuListSDK(getNameByIds(state.appVersionIds, state.appList), 'appVersionIds')
          : state.appVersionIds,
        channelNoIds: infoObj.optionType === 3 ? 
          generateOriginMenuListSDK(getNameByIds(state.channelNoIds, state.channelList), 'channelNoIds') : state.channelNoIds
      };
    case CHANGE_KEYWORD:
      return {
        ...state,
        countryList: payload.name !== undefined ? getIdByKeyword(payload.name, state.originCountryList) : state.countryList,
        languageList: payload.sysName !== undefined ? getIdByKeyword(payload.sysName, state.originLanguageList) : 
          state.languageList
      };
    case GET_OPTION_LIST_SUCCESS:
      if(infoObj === 1) {
        state.osVersionIds = state.priorityList.osVersionIds === '' ?
          [] : generateOriginMenuListSDK(getNameByIds(state.priorityList.osVersionIds, payload), 'osVersionIds');
      }
      if(infoObj === 2) {
        state.appVersionIds = state.priorityList.appVersionIds === '' ?
          [] : generateOriginMenuListSDK(getNameByIds(state.priorityList.appVersionIds, payload), 'appVersionIds');
      }
      if(infoObj === 3) {
        state.channelNoIds = state.priorityList.channelNoIds === '' ?
          [] : generateOriginMenuListSDK(getNameByIds(state.priorityList.channelNoIds, payload), 'channelNoIds');
      }
      return {
        ...state,
        status: OperationStatus.load_success,
        optionType: infoObj,
        osList: infoObj === 1 ? generateOriginMenuListSDK(payload, 'osVersionIds') : state.osList,
        appList: infoObj === 2 ? generateOriginMenuListSDK(payload, 'appVersionIds') : state.appList,
        channelList: infoObj === 3 ? generateOriginMenuListSDK(payload, 'channelNoIds') : state.channelList,
        disabledValue: getNameByIds(state.priorityList[optionTypeValue[infoObj]], payload).length === 0 ? 
          Object.assign({}, state.disabledValue, {[optionTypeStyle[infoObj]]: false}) : state.disabledValue
      };
    case GET_DETAILS_INFO_SUCCESS:
      return {
        ...state,
        detailsInfo: payload
      };
    case EDIT_PRIORITY_CONFIG_SUCCESS:
      return {
        ...state,
        changeInfo: false,
        disabledValue: state._disabledValue
      };
    case ADD_PRIORITY_CONFIG_SUCCESS:
      return {
        ...state,
        changeInfo: false,
        disabledValue: state._disabledValue
      };
    case GET_OPTION_LIST_FAIL:
      return {
        ...state,
        status: OperationStatus.load_fail,
        osList: [],
        channelList: [],
        appList: []
      };
    case GET_PRIORITY_LIST_FAIL:
    case GET_LANGUAGE_LIST_FAIL:
    case GET_COUNTRY_LIST_FAIL:
    case GET_DETAILS_INFO_FAIL:
    case CHANGE_EDITMODAL_VALUE_FAIL:
    case EDIT_PRIORITY_CONFIG_FAIL:
    case ADD_PRIORITY_CONFIG_FAIL:
      return {
        ...state,
        status: OperationStatus.load_fail
      };
    default:
      return state;
  }
}