import { combineReducers } from 'redux';
import priority from './priority';
import priorityConfig from './priorityConfig';
    
const editPriority = combineReducers({
  priority,
  priorityConfig
});

export default editPriority;