import {
  GET_ADSLOT_LIST,
  GET_ADSLOT_LIST_FAIL,
  GET_ADSLOT_LIST_SUCCESS,
  DELETE_SLOT_LIST,
  DELETE_SLOT_LIST_FAIL,
  DELETE_SLOT_LIST_SUCCESS,
  ENTER_ADD_SLOT_LIST,
  ADD_SLOT_LIST,
  ADD_SLOT_LIST_FAIL,
  ADD_SLOT_LIST_SUCCESS,
  ENTER_EDIT_SLOT_NAME,
  EDIT_SLOT_NAME,
  EDIT_SLOT_NAME_FAIL,
  EDIT_SLOT_NAME_SUCCESS,
  GET_ADVERTISING_LIST,
  GET_ADVERTISING_LIST_SUCCESS,
  GET_ADVERTISING_LIST_FAIL,
  UP_SET_PRIORITY,
  UP_SET_PRIORITY_SUCCESS,
  UP_SET_PRIORITY_FAIL,
  DELETE_ADVERTISING_LIST,
  DELETE_ADVERTISING_LIST_SUCCESS,
  DELETE_ADVERTISING_LIST_FAIL
} from '../../../constants/ActionTypes';
import { OperationStatus } from '../../../constants/MenuTypes';

const initialState = {
  total: 0,
  list: [],
  status: OperationStatus.initial,
  advertisingList: [],
  mediationSdkSlotName: ''
};

export default function adList(state = initialState, { type, payload, infoObj }) {
  switch (type) {
    case ENTER_ADD_SLOT_LIST:
      return {
        ...state,
        advertisingList: [],
        mediationSdkSlotName: ''
      };
    case ENTER_EDIT_SLOT_NAME:
      return {
        ...state, 
        status: OperationStatus.editing
      };
    case GET_ADSLOT_LIST:
    case ADD_SLOT_LIST:
    case EDIT_SLOT_NAME:
    case GET_ADVERTISING_LIST:
    case DELETE_SLOT_LIST:
    case UP_SET_PRIORITY:
    case DELETE_ADVERTISING_LIST:
      return {
        ...state,
        status: OperationStatus.loading
      };
    case GET_ADSLOT_LIST_SUCCESS:
      return {
        ...state,
        list: payload.list,
        total: payload.total
      };
    case EDIT_SLOT_NAME_SUCCESS:
    case ADD_SLOT_LIST_SUCCESS:
      return {
        ...state
      };
    case DELETE_SLOT_LIST_SUCCESS:
      return {
        ...state,
        list: state.list.filter((item, index) => infoObj !== index)
      };
    case DELETE_ADVERTISING_LIST_SUCCESS:
    case UP_SET_PRIORITY_SUCCESS:
      return {
        ...state,
        status: OperationStatus.load_success
      };
    case GET_ADVERTISING_LIST_SUCCESS:
      return {
        ...state,
        advertisingList: payload.advertisingList,
        mediationSdkSlotName: payload.mediationSdkSlotName
      };
    case GET_ADSLOT_LIST_FAIL:
    case DELETE_SLOT_LIST_FAIL:
    case ADD_SLOT_LIST_FAIL:
    case EDIT_SLOT_NAME_FAIL:
    case GET_ADVERTISING_LIST_FAIL:
    case UP_SET_PRIORITY_FAIL:
    case DELETE_ADVERTISING_LIST_FAIL:
      return {
        ...state,
        status: OperationStatus.load_fail
      };
    default:
      return state;
  }
}