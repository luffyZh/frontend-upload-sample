import { combineReducers } from 'redux';
import auth from './auth';
import runtime from './runtime';
import appManagement from './appManagement';
import accountManagement from './accountManagement';
import dataReport from './dataReport';
import aggregateSDK from './aggregateSDK';

export default combineReducers({
  auth,
  appManagement,
  runtime,
  accountManagement,
  dataReport,
  aggregateSDK
});
