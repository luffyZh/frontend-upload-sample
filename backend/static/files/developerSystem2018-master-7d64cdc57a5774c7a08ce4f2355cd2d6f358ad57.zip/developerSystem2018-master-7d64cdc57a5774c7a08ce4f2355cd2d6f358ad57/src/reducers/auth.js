import Cookies from 'js-cookie';
import { message } from 'antd';
import { removeCookies } from '../core/utils';
import {
  LOGIN_SUCCESS,
  LOGOUT,
  LOGOUT_SUCCESS,
  LOGOUT_FAIL
} from '../constants/ActionTypes';

const initialState = {
  status: 'initial',
  user: null
};

const auth = (state = initialState, action) => {
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        user: action.payload.user,
        status: 'login_success'
      };
    case LOGOUT:
      return state;
    case LOGOUT_SUCCESS:
      removeCookies(Cookies, ['KFZTK', 'KFZID', 'KFZEMAIL', 'PERMISSION_LIST']);
      message.success('您已安全登出当前帐号，即将跳转 ...', 1, () => {
        window.location.href = action.payload.redirect;
      });
      return {
        user: null,
        status: 'logout_success'
      };
    case LOGOUT_FAIL:
      return {
        ...state,
        status: 'logout_fail'
      };
    default:
      return state;
  }
};

export default auth;
