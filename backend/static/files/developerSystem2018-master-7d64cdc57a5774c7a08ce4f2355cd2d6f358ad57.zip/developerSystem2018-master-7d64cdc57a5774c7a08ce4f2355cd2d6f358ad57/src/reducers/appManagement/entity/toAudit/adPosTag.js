import { TO_AUDIT_DATA_CHANGE, RESET_ADPOS_ITEM } from '../../../../constants/ActionTypes';

const adPosTag = (state = false, { type, payload }) => {
  switch (type) {
    case TO_AUDIT_DATA_CHANGE: {
      const { type: subType } = payload;
      if (subType === 'adPosTag') {
        return payload.adPosTag;
      }
      return state;
    }
    case RESET_ADPOS_ITEM:
      return false;
    default:
      return state;
  }
};

export default adPosTag;
