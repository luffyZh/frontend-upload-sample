import {
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  RESET_ADPOS_ITEM
} from '../../../../constants/ActionTypes';

const adPosTag = (state = false, { type }) => {
  switch (type) {
    case CREATE_AD_POS_SUCCESS:
      return true;
    case CREATE_AD_POS_FAIL:
      return true;
    case RESET_ADPOS_ITEM:
      return false;
    default:
      return state;
  }
};

export default adPosTag;
