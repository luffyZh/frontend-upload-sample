import {
  CHANGE_SLOT_AUDIT_SOURCE,
  RESET_AUDIT_DATA,
  GET_ADSLOT_AUDIT_INFO_SUCCESS
} from '../../../../constants/ActionTypes';

const initialState = {
  installPackage: {
    packageType: 0,
    name: 'app-package',
    id: 0,
    value: '',
    valid: false
  }
};

const UploadInstallPackage = (state = initialState, { type, payload }) => {
  if (type === RESET_AUDIT_DATA) {
    return {
      installPackage: {
        packageType: 0,
        name: 'app-package',
        id: 0,
        value: '',
        valid: false
      }
    };
  }
  if (type === CHANGE_SLOT_AUDIT_SOURCE && payload.type === 'package') {
    const { list } = payload;
    return {
      ...state,
      installPackage: list[0]
    };
  }
  if (type === GET_ADSLOT_AUDIT_INFO_SUCCESS) {
    const { installPackage } = state;
    const { packageName, osType, appPackage } = payload;
    installPackage.name = packageName || '';
    installPackage.valid = packageName !== null;
    installPackage.packageType = osType;
    installPackage.value = appPackage;
    return {
      ...state
    };
  }
  return state;
};

export default UploadInstallPackage;
