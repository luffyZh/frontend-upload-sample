import _ from 'lodash';
import {
  AppTabTypes,
  OperationStatus,
  AppStatusForBE,
  SlotOpStatusForBE
} from '../../../constants/MenuTypes';
import {
  GET_APP_AND_ADPOS_LIST,
  GET_APP_AND_ADPOS_LIST_SUCCESS,
  GET_APP_AND_ADPOS_LIST_FAIL,
  GET_APP_AND_ADPOS_STATISTIC_LIST,
  GET_APP_AND_ADPOS_STATISTIC_LIST_SUCCESS,
  GET_APP_AND_ADPOS_STATISTIC_LIST_FAIL,
  UPDATE_APP_STATUS,
  UPDATE_APP_STATUS_SUCCESS,
  UPDATE_APP_STATUS_FAIL,
  UPDATE_ADPOS_STATUS,
  UPDATE_ADPOS_STATUS_SUCCESS,
  UPDATE_ADPOS_STATUS_FAIL,
  UPDATE_ADPOS_STYLE_STATUS,
  UPDATE_ADPOS_STYLE_STATUS_SUCCESS,
  UPDATE_ADPOS_STYLE_STATUS_FAIL
} from '../../../constants/ActionTypes';

const getSingleInitialState = () => ({
  status: OperationStatus.initial,
  total: 0,
  list: [],
  statisticList: [],
  statisticStatus: false
});

const initialState = {};
_.keys(AppTabTypes).forEach(k => {
  initialState[k] = getSingleInitialState();
});

export default function queryLists(
  state = initialState,
  { type, subType, payload, params },
) {
  switch (type) {
    case GET_APP_AND_ADPOS_LIST:
      return {
        ...state,
        [subType]: {
          ...state[subType],
          status: OperationStatus.loading,
          statisticStatus: false
        }
      };
    case GET_APP_AND_ADPOS_LIST_SUCCESS:
      return {
        ...state,
        [subType]: {
          status: OperationStatus.load_success,
          total: payload.total,
          list: payload.list,
          statisticList: [],
          statisticStatus: true
        }
      };
    case GET_APP_AND_ADPOS_LIST_FAIL:
      return {
        ...state,
        [subType]: {
          total: 0,
          list: [],
          status: OperationStatus.load_fail,
          statisticList: [],
          statisticStatus: false
        }
      };
    case GET_APP_AND_ADPOS_STATISTIC_LIST:
      return state;
    case GET_APP_AND_ADPOS_STATISTIC_LIST_SUCCESS:
      return {
        ...state,
        [subType]: {
          ...state[subType],
          status: OperationStatus.load_success,
          statisticList: payload.list
        }
      };
    case GET_APP_AND_ADPOS_STATISTIC_LIST_FAIL:
      return {
        ...state,
        [subType]: {
          ...state[subType],
          statisticList: [],
          status: OperationStatus.load_fail
        }
      };
    case UPDATE_APP_STATUS:
    case UPDATE_ADPOS_STATUS:
    case UPDATE_ADPOS_STYLE_STATUS: {
      const { tabType: tableType } = params;
      return {
        ...state,
        [tableType]: {
          ...state[tableType],
          status: OperationStatus.saving
        }
      };
    }
    case UPDATE_APP_STATUS_SUCCESS:
    case UPDATE_ADPOS_STATUS_SUCCESS: {
      const { tabType: tableType, idList, status } = params;
      const { list: tableList } = state[tableType];
      if (tableType === AppTabTypes.appTab) {
        tableList.forEach(item => {
          if (_.includes(idList, item.appId)) {
            item.appStatus = AppStatusForBE[status];
          }
        });
      } else {
        tableList.forEach(item => {
          if (_.includes(idList, item.slotUdid)) {
            item.slotOpStatus = SlotOpStatusForBE[status];
          }
        });
      }
      return {
        ...state,
        [tableType]: {
          ...state[tableType],
          list: tableList,
          status: OperationStatus.save_success
        }
      };
    }
    case UPDATE_APP_STATUS_FAIL:
    case UPDATE_ADPOS_STATUS_FAIL: {
      const { tabType: tableType } = params;
      const { list: tableList } = state[tableType];
      return {
        ...state,
        [tableType]: {
          ...state[tableType],
          list: tableList,
          status: OperationStatus.save_fail // 这里最后调试时要修改为false
        }
      };
    }
    case UPDATE_ADPOS_STYLE_STATUS_SUCCESS: {
      const { tabType: tableType, adPosUdid, styleId, status } = params;
      const { list: tableList } = state[tableType];
      tableList.forEach(ad => {
        if (ad.slotUdid == adPosUdid) {
          ad.styleList.forEach(s => {
            if (s.styleId === styleId) {
              s.styleOpStatus = SlotOpStatusForBE[status];
            }
          });
        }
      });
      return {
        ...state,
        [tableType]: {
          ...state[tableType],
          list: tableList,
          status: OperationStatus.save_success
        }
      };
    }
    case UPDATE_ADPOS_STYLE_STATUS_FAIL: {
      const { tabType: tableType, adPosUdid, styleId, status } = params;
      const { list: tableList } = state[tableType];
      tableList.forEach(ad => {
        if (ad.adPos.udid == adPosUdid) {
          ad.style.forEach(s => {
            if (s.id === styleId) {
              s.switch = status;
            }
          });
        }
      });
      return {
        ...state,
        [tableType]: {
          ...state[tableType],
          list: tableList,
          status: OperationStatus.save_success
        }
      };
    }
    default:
      return state;
  }
}
