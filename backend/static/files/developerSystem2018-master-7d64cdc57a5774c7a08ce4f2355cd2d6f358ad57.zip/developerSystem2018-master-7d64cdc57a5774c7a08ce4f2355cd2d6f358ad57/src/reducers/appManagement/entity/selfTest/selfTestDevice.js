import {
  RESET_APP_ITEM,
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  GET_SELF_TEST_DEVICE_LIST_SUCCESS
} from '../../../../constants/ActionTypes';

const initialState = {
  deviceList: []
};

const selfTestDevice = (state = initialState, { type, payload }) => {
  if (type === GET_SELF_TEST_DEVICE_LIST_SUCCESS) {
    return {
      ...state,
      deviceList: payload.list
    };
  }
  if (type === RESET_APP_ITEM) {
    return initialState;
  }
  if (type === CREATE_AD_POS_SUCCESS) {
    return initialState;
  }
  if (type === CREATE_AD_POS_FAIL) {
    return initialState;
  }
  return state;
};

export default selfTestDevice;
