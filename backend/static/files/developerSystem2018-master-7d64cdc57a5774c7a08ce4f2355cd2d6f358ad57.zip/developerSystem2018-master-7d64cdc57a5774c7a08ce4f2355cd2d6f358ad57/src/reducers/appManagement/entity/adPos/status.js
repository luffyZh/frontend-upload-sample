import { OperationStatus } from '../../../../constants/MenuTypes';
import {
  EDITING_ADPOS,
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  CREATE_AD_POS,
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  RESET_APP_ITEM,
  RESET_ADPOS_ITEM
} from '../../../../constants/ActionTypes';

const status = (state = OperationStatus.initial, { type }) => {
  switch (type) {
    case EDITING_ADPOS:
      return OperationStatus.editing;
    case CREATE_APP_SUCCESS:
      return OperationStatus.editing;
    // 创建APP失败的时候保持广告位页面不动
    case CREATE_APP_FAIL:
      return OperationStatus.initial;
    case CREATE_AD_POS:
      return OperationStatus.saving;
    case CREATE_AD_POS_SUCCESS:
      return OperationStatus.save_success;
    case CREATE_AD_POS_FAIL:
      return OperationStatus.save_fail;
    case RESET_APP_ITEM:
      return OperationStatus.initial;
    case RESET_ADPOS_ITEM:
      return OperationStatus.editing;
    default:
      return state;
  }
};

export default status;
