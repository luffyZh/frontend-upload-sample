import { OperationStatus } from '../../../../constants/MenuTypes';
import {
  EDITING_TO_AUDIT,
  SAVE_SELF_TEST,
  CREATE_TO_AUDIT,
  CREATE_TO_AUDIT_SUCCESS,
  CREATE_TO_AUDIT_FAIL,
  RESET_APP_ITEM,
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  CREATE_AD_POS_SUCCESS,
  CREATE_AD_POS_FAIL,
  RESET_ADPOS_ITEM
} from '../../../../constants/ActionTypes';

const status = (state = OperationStatus.initial, { type }) => {
  switch (type) {
    case EDITING_TO_AUDIT:
      return OperationStatus.editing;
    case SAVE_SELF_TEST:
      return OperationStatus.initial;
    case CREATE_TO_AUDIT:
      return OperationStatus.saving;
    case CREATE_TO_AUDIT_SUCCESS:
      return OperationStatus.save_success;
    case CREATE_TO_AUDIT_FAIL:
      return OperationStatus.save_fail;
    case RESET_APP_ITEM:
      return OperationStatus.initial;
    case CREATE_APP_SUCCESS:
      return OperationStatus.initial;
    case CREATE_APP_FAIL:
      return OperationStatus.initial;
    case CREATE_AD_POS_SUCCESS:
      return OperationStatus.initial;
    case CREATE_AD_POS_FAIL:
      return OperationStatus.initial;
    case RESET_ADPOS_ITEM:
      return OperationStatus.initial;
    default:
      return state;
  }
};

export default status;
