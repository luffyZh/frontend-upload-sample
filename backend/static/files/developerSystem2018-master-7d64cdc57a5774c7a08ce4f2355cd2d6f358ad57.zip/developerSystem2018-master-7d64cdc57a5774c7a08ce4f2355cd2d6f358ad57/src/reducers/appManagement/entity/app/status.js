import {
  EDITING_APP,
  RESET_APP_ITEM,
  CREATE_APP,
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  RESET_ADPOS_ITEM
} from '../../../../constants/ActionTypes';
import { OperationStatus } from '../../../../constants/MenuTypes';

const status = (state = OperationStatus.initial, { type }) => {
  switch (type) {
    case EDITING_APP:
      return OperationStatus.editing;
    case CREATE_APP:
      return OperationStatus.saving;
    case CREATE_APP_SUCCESS:
      return OperationStatus.save_success;
    case CREATE_APP_FAIL:
      return OperationStatus.save_fail;
    case RESET_APP_ITEM:
      return OperationStatus.initial;
    case RESET_ADPOS_ITEM:
      return OperationStatus.initial;
    default:
      return state;
  }
};

export default status;
