import {
  AppOsTypeZH,
  NewAppSettingItems
} from '../../../../constants/MenuTypes';
import {
  APP_ITEM_CHANGE,
  RESET_APP_ITEM,
  GET_APP_CATEGORY,
  GET_APP_CATEGORY_SUCCESS,
  GET_APP_CATEGORY_FAIL,
  CHANGE_SAVE_TYPE
} from '../../../../constants/ActionTypes';

const initialState = {
  saveType: false,
  appName: '', // 应用名称
  osType: AppOsTypeZH[0].value, // 平台
  nameConflict: false,
  appType: ['一级分类', '二级分类'], // 应用类型
  categories: [], // 一、二级分类
  androidOrItunes: '' // Android包名
};

const newApp = (state = initialState, { type, payload }) => {
  if (type === APP_ITEM_CHANGE) {
    const { type: sectionType, itemType } = payload;
    if (sectionType === NewAppSettingItems[0].value) {
      switch (itemType) {
        case 'osType':
        case 'appType':
        case 'androidOrItunes':
          return {
            ...state,
            [itemType]: payload[itemType]
          };
        case 'appName':
          return {
            ...state,
            nameConflict: false,
            appName: payload.appName
          };
        default:
      }
    }
  }
  if (type === RESET_APP_ITEM || type === GET_APP_CATEGORY || type === GET_APP_CATEGORY_FAIL) {
    return initialState;
  }
  if (type === GET_APP_CATEGORY_SUCCESS) {
    return {
      ...state,
      categories: payload.categories
    };
  }
  if (type === CHANGE_SAVE_TYPE) {
    return {
      ...state,
      saveType: payload
    };
  }
  return state;
};

export default newApp;
