import {
  SELF_TEST_DATA_CHANGE,
  SAVE_SELF_TEST,
  RESET_ADPOS_ITEM
} from '../../../../constants/ActionTypes';

const selfTestTag = (state = false, { type, payload }) => {
  switch (type) {
    case SELF_TEST_DATA_CHANGE: {
      const { type: subType } = payload;
      if (subType === 'selfTestTag') {
        return payload.selfTestTag;
      }
      return state;
    }
    case SAVE_SELF_TEST:
      return true;
    case RESET_ADPOS_ITEM:
      return false;
    default:
      return state;
  }
};

export default selfTestTag;
