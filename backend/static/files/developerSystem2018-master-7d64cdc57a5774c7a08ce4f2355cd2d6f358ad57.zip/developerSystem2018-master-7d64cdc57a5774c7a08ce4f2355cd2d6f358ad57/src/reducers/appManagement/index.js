import { combineReducers } from 'redux';
import list from './list';
import entity from './entity';

export default combineReducers({
  list,
  entity
});
