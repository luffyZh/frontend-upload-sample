import {
  CREATE_AD_POS_SUCCESS,
  GET_ADSLOT_AUDIT_INFO_SUCCESS,
  CHANGE_SLOT_AUDIT_SOURCE
} from '../../../../constants/ActionTypes';

const initialState = {
  adPosName: '', // 广告位名称
  adPosId: '', // 广告位id
  styleInfo: [
    {
      styleName: '样式1',
      styleStatus: '草稿',
      styleScreenshot: [
        {
          key: 0,
          name: '图片1',
          id: 0,
          value: '',
          valid: false
        }
      ]
    }
  ]
};

const uploadScreenShot = (state = initialState, { type, payload }) => {
  if (type === CREATE_AD_POS_SUCCESS) {
    return {
      ...state,
      adPosId: payload.slotUdid
    };
  }
  if (type === GET_ADSLOT_AUDIT_INFO_SUCCESS) {
    return {
      ...state,
      adPosName: payload.slotName,
      styleInfo: payload.styleList
    };
  }
  if (type === CHANGE_SLOT_AUDIT_SOURCE && payload.type === 'image') {
    const { index, list } = payload;
    let newStyleInfo = [];
    state.styleInfo.map((item, key) => {
      if (key === index) {
        item.styleScreenshot = list;
      }
      newStyleInfo.push(item);
    });
    return {
      ...state,
      styleInfo: newStyleInfo
    };
  }
  return state;
};

export default uploadScreenShot;
