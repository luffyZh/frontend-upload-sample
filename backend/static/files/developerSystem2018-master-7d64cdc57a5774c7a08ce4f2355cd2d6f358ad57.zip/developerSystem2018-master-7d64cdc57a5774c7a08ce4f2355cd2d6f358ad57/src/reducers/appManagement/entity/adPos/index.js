import { combineReducers } from 'redux';
import status from './status';
import appTag from './appTag';
import adPosTag from './adPosTag';
import adPosInfo from './adPosInfo';
import styleObj from './styleInfo';
import isEdit from './isEdit';

const adPos = combineReducers({
  status,
  appTag,
  adPosTag,
  adPosInfo,
  styleObj,
  isEdit
});

export default adPos;
