import { RESET_ADPOS_ITEM } from '../../../../constants/ActionTypes';

const appTag = (state = false, { type }) => {
  switch (type) {
    case RESET_ADPOS_ITEM:
      return false;
    default:
      return state;
  }
};

export default appTag;
