import {
  AdPosObject,
  NewAdPosSettingItems,
  SlotStyleForFE,
  SlotStyleBE2FE
} from '../../../../constants/MenuTypes';
import {
  ADPOS_ITEM_CHANGE,
  CREATE_AD_POS_SUCCESS,
  CREATE_APP_SUCCESS,
  CREATE_APP_FAIL,
  RESET_ADPOS_ITEM,
  GET_APP_NAME_BY_ID,
  GET_APP_NAME_BY_ID_FAIL,
  GET_APP_NAME_BY_ID_SUCCESS,
  GET_ADSLOT_INFO_SUCCESS,
  CHANGE_SAVE_TYPE
} from '../../../../constants/ActionTypes';
import { getRealSlotAuditStatus } from '../../../../core/utils';


const initialState = {
  saveType: false,
  appName: '', // 应用名称 默认应该为‘’，最后需要修改
  appId: -1,
  appPackageName: '',
  adPosId: '',
  adPosName: '', // 广告位名称
  adPosType: AdPosObject[1].value, // 广告位类型，默认：信息流
  slotCallbackUrl: '', // 回调地址
  nameConflict: false,
  slotOpStatus: 0,
  adAuditStatus: -1,
  slotNameList: [],
  appOs: -1
};

const adPosInfo = (state = initialState, { type, payload }) => {
  if (type === ADPOS_ITEM_CHANGE) {
    const { type: sectionType, itemType } = payload;
    if (sectionType === NewAdPosSettingItems[0].value) {
      switch (itemType) {
        case 'adPosType':
        case 'slotCallbackUrl':
        case 'appId':
        case 'adPosId':
        case 'slotOpStatus':
        case 'nameConflict':
          return {
            ...state,
            [itemType]: payload[itemType]
          };
        case 'adPosName': {
          const { slotNameList } = state;
          return {
            ...state,
            adPosName: payload.adPosName,
            nameConflict: slotNameList.some(item => item === payload.adPosName)
          };
        }
        default:
          return state;
      }
    } else {
      return state;
    }
  } else if (type === CREATE_AD_POS_SUCCESS) {
    return {
      ...state,
      adPosId: payload.slotUdid
    };
  } else if (type === CREATE_APP_SUCCESS) {
    return {
      ...state,
      appId: payload.appId
    };
  } else if (type === GET_APP_NAME_BY_ID_SUCCESS) {
    return {
      ...state,
      appName: payload.appName,
      appOs: payload.appOs,
      slotNameList: payload.slotNameList,
      appPackageName: payload.appPackageName
    };
  } else if (type === GET_ADSLOT_INFO_SUCCESS) {
    return {
      ...state,
      appName: payload.appName,
      appPackageName: payload.appPackageName || '',
      adPosName: payload.slotName,
      slotCallbackUrl: payload.slotCallbackUrl || '',
      adPosType: SlotStyleBE2FE[SlotStyleForFE[payload.slotStyle]] || SlotStyleBE2FE.自定义,
      adAuditStatus: getRealSlotAuditStatus(payload.styleList)
    };
  } else if (type === CHANGE_SAVE_TYPE) {
    return {
      ...state,
      saveType: payload
    };
  } else if (type === GET_APP_NAME_BY_ID
  || type === GET_APP_NAME_BY_ID_FAIL) {
    return state;
  } else if (type === CREATE_APP_FAIL
    || type === RESET_ADPOS_ITEM) {
    return initialState;
  } else {
    return state;
  }
};

export default adPosInfo;
