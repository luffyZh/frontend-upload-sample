import {
  styleElemName,
  defaultElemsInfo,
  defaultStyleInfo,
  defaultElemsItems,
  NewAdPosSettingItems,
  AdPosTypeForBE,
  elemTypeMap2State,
  elemTypeMap2List,
  elemTypeMap2SelectList
} from '../../../../constants/MenuTypes';
import {
  ADPOS_ADD_ELEM,
  ADD_OR_DEL_STYLE,
  ADPOS_ITEM_CHANGE,
  RESET_ADPOS_ITEM,
  GET_STANDARD_TEMPLATES_SUCCESS,
  GET_STANDARD_ELEMENTS_SUCCESS,
  GET_ADSLOT_INFO_SUCCESS
} from '../../../../constants/ActionTypes';
import {
  generateDetailInfo,
  initialEditAdSlotStyleInfo,
  resetStyleElemsList,
  checkStyleInfoNameIsRepeat
} from '../../../../core/utils';

const defaultStyle = defaultElemsInfo.小图;

const initialState = {
  presetStandardData: {
    standardTemplates: [],
    standardElements: {}
  },
  styleInfo: [defaultStyleInfo(defaultStyle, defaultElemsItems.小图)]
};

const styleObj = (state = initialState, { type, payload }) => {
  if (type === ADPOS_ADD_ELEM) {
    const { elemType, elemValue, index } = payload;
    const elemTypeIndex = styleElemName.findIndex(t => t === elemType);
    const elemTypeInState = elemTypeMap2State[elemTypeIndex];
    const elemLists = elemTypeMap2List[elemTypeIndex];
    const originSelectList = elemTypeMap2SelectList[elemTypeIndex];
    const { styleInfo } = state;
    const newStyleInfo = styleInfo.map((t, i) => {
      if (i === index) {
        return {
          ...t,
          [elemLists]: resetStyleElemsList(originSelectList, elemValue),
          [elemTypeInState]: [...elemValue]
        };
      }
      return t;
    });
    return {
      ...state,
      styleInfo: newStyleInfo
    };
  }
  if (type === ADD_OR_DEL_STYLE) {
    return {
      ...state,
      styleInfo: payload.styleInfo
    };
  }
  if (type === ADPOS_ITEM_CHANGE) {
    const {
      type: sectionType,
      itemType,
      itemIndex,
      styleStandardTemplateId
    } = payload;
    const newStyleInfo = [...state.styleInfo];
    if (sectionType === NewAdPosSettingItems[0].value) {
      if (itemType === 'adPosType') {
        return {
          ...state,
          styleInfo: [generateDetailInfo(state.presetStandardData, AdPosTypeForBE[payload[itemType]])]
        };
      }
    } else if (sectionType === NewAdPosSettingItems[1].value) {
      switch (itemType) {
        case 'styleName':
        case 'schemaStandardTemplateName':
        case 'styleType':
        case 'minSupportVersion':
        case 'imageElements':
        case 'textElements':
        case 'video':
        case 'ratio':
        case 'attr':
        case 'styleNameValid':
        case 'styleNameRepeat':
        case 'versionValid':
          newStyleInfo[itemIndex][itemType] = payload[itemType];
          return {
            ...state,
            styleInfo: newStyleInfo
          };
        case 'styleStandardTemplateId': {
          newStyleInfo[itemIndex] = generateDetailInfo(state.presetStandardData, styleStandardTemplateId);
          if (newStyleInfo.length > 1) {
            newStyleInfo[itemIndex].styleNameRepeat =
              checkStyleInfoNameIsRepeat(
                newStyleInfo.filter((item, index) => index !== itemIndex),
                newStyleInfo[itemIndex].schemaStandardTemplateName
              );
          }
          return {
            ...state,
            styleInfo: newStyleInfo
          };
        }
        default:
      }
    }
  }
  if (type === GET_ADSLOT_INFO_SUCCESS) {
    return {
      ...state,
      styleInfo: initialEditAdSlotStyleInfo(payload.styleList)
    };
  }
  if (type === RESET_ADPOS_ITEM) {
    return initialState;
  }
  if (type === GET_STANDARD_ELEMENTS_SUCCESS) {
    return {
      ...state,
      presetStandardData: {
        ...state.presetStandardData,
        ...payload
      }
    };
  }
  if (type === GET_STANDARD_TEMPLATES_SUCCESS) {
    return {
      ...state,
      presetStandardData: {
        ...state.presetStandardData,
        ...payload
      },
      styleInfo: [generateDetailInfo(payload, AdPosTypeForBE.smallImage)]
    };
  }
  return state;
};

export default styleObj;
