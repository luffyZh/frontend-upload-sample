import { SELF_TEST_DATA_CHANGE, RESET_ADPOS_ITEM } from '../../../../constants/ActionTypes';

const appTag = (state = false, { type, payload }) => {
  switch (type) {
    case SELF_TEST_DATA_CHANGE: {
      const { type: subType } = payload;
      if (subType === 'appTag') {
        return payload.appTag;
      }
      return state;
    }
    case RESET_ADPOS_ITEM:
      return false;
    default:
      return state;
  }
};

export default appTag;
