import { SET_ADPOS_ISEDIT } from '../../../../constants/ActionTypes';

const isEdit = (state = false, { type, isEdit }) => {
  switch (type) {
    case SET_ADPOS_ISEDIT:
      return isEdit;
    default:
      return state;
  }
};

export default isEdit;
