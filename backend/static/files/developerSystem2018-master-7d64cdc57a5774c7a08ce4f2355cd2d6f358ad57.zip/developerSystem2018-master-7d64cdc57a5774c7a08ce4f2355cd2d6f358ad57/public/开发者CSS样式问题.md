## 开发者系统 CSS 样式问题

### 尽量采用 less 文件书写，按照 less 语法格式编写

### 与新智选耦和的部分陆续进行分割

与新智选耦和的部分，例如很多继承过来的样式，都是 css 文件编写，里面是 less 语法混用，然后通过 webpack 进行打包，所以 stylelint 经常报错，就忽略不计了。

### 除去耦合部分后可以加入代码检测

```
// lint-staged下面增加下面语句
"*.css": ["stylelint --fix", "git add --force"]
```
